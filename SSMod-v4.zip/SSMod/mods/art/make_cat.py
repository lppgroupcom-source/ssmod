"""Draws the pet cat for mods/pet_cat.ssmod: an original ginger cat in the game's flat style (no outlines).
Frames are drawn at 8x and shrunk to 2x for smooth edges; the mod shows them at 1x world size.
  ~/ssvenv/bin/python3 mods/art/make_cat.py
"""
import math
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
S = 8                                   # drawing scale
W, H = 80, 64                           # frame size in world units (the cat is about 52 tall sitting)
FUR = (232, 150, 74)
FUR_DARK = (196, 110, 48)
FUR_LIGHT = (244, 186, 120)
WHITE = (248, 241, 230)
PINK = (238, 150, 160)
EYE = (40, 34, 30)
SHADOW = (0, 0, 0, 60)


def canvas():
    im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)


def P(x, y):
    """World units (origin bottom-centre, +y up) -> pixels."""
    return ((x + W / 2) * S, (H - y) * S)


def ell(d, cx, cy, rx, ry, col):
    x0, y0 = P(cx - rx, cy + ry)
    x1, y1 = P(cx + rx, cy - ry)
    d.ellipse([x0, y0, x1, y1], fill=col)


def poly(d, pts, col):
    d.polygon([P(x, y) for x, y in pts], fill=col)


def limb(d, x0, y0, x1, y1, w, col):
    """A rounded leg/tail segment from (x0, y0) to (x1, y1)."""
    d.line([P(x0, y0), P(x1, y1)], fill=col, width=int(w * S))
    for x, y in ((x0, y0), (x1, y1)):
        ell(d, x, y, w / 2, w / 2, col)


def tail(d, base, angle0, bend, col=FUR, w=5.5, n=8, length=24):
    """A tail made of short segments that curve by `bend` degrees in total."""
    x, y = base
    a = math.radians(angle0)
    pts = [(x, y)]
    for i in range(n):
        a += math.radians(bend) / n
        x += math.cos(a) * length / n
        y += math.sin(a) * length / n
        pts.append((x, y))
    for (ax, ay), (bx, by) in zip(pts, pts[1:]):
        limb(d, ax, ay, bx, by, w, col)
    tip = pts[-1]
    ell(d, tip[0], tip[1], w * 0.55, w * 0.55, FUR_DARK)


def happy_eyes(d, cx, cy, look):
    for ex in (-4, 5):
        x = cx + ex + look * 2
        limb(d, x - 2, cy + 0.5, x, cy + 2.4, 1.2, EYE)
        limb(d, x, cy + 2.4, x + 2, cy + 0.5, 1.2, EYE)


def head(d, cx, cy, look=1, blink=False, happy=False):
    """The head, facing right (look=1)."""
    # ears
    for ex in (-6, 6):
        poly(d, [(cx + ex - 5, cy + 6), (cx + ex - 1 + look * 1.5, cy + 17), (cx + ex + 4, cy + 7)], FUR)
        poly(d, [(cx + ex - 3, cy + 7.5), (cx + ex - 0.5 + look * 1.2, cy + 14), (cx + ex + 2.2, cy + 8)], PINK)
    ell(d, cx, cy, 11.5, 10, FUR)
    # stripes on the forehead
    for sx in (-3.5, 0, 3.5):
        limb(d, cx + sx, cy + 9, cx + sx * 0.8, cy + 5.5, 1.6, FUR_DARK)
    # muzzle and cheeks
    ell(d, cx + look * 3.5, cy - 4, 6.5, 4.5, WHITE)
    # eyes
    for ex in (-4, 5) if not happy else ():
        x = cx + ex + look * 2
        if blink:
            limb(d, x - 1.8, cy + 1, x + 1.8, cy + 1, 1.2, EYE)
        else:
            ell(d, x, cy + 1, 1.9, 2.4, EYE)
            ell(d, x + 0.6, cy + 1.8, 0.6, 0.6, (255, 255, 255))
    if happy:
        happy_eyes(d, cx, cy, look)
    # nose
    poly(d, [(cx + look * 3.5 - 1.6, cy - 1.5), (cx + look * 3.5 + 1.6, cy - 1.5), (cx + look * 3.5, cy - 3.2)], PINK)


def shadow(d, cx, w):
    x0, y0 = P(cx - w, 2.5)
    x1, y1 = P(cx + w, -1.5)
    d.ellipse([x0, y0, x1, y1], fill=SHADOW)


def walking(phase):
    """A walking cat facing right. phase 0..3 moves the legs."""
    im, d = canvas()
    shadow(d, 0, 22)
    swing = [(-1, 1), (-0.3, 0.3), (1, -1), (0.3, -0.3)][phase]
    lift = [0, 1.5, 0, 1.5][phase]
    tail(d, (-15, 22), 150, -100 + swing[0] * 12)
    # far legs (darker), then body, then near legs
    for x, s in ((-11, swing[1]), (11, swing[0])):
        limb(d, x, 16, x + s * 7, 1.5 + lift * abs(s), 4.6, FUR_DARK)
    ell(d, 0, 20, 19, 9.5, FUR)
    ell(d, 2, 16.5, 13, 5, FUR_LIGHT)
    for sx in (-10, -5, 0):
        limb(d, sx, 28.5, sx + 2, 22, 2.2, FUR_DARK)
    for x, s in ((-12, swing[0]), (12, swing[1])):
        limb(d, x, 15, x + s * 7, 1.5, 5, FUR)
        ell(d, x + s * 7, 1.8, 3, 2, WHITE)
    head(d, 21, 30 + (lift * 0.4), 1)
    return im


def sitting(tail_up, blink=False, happy=False):
    """A sitting cat facing right; tail_up swishes the tail."""
    im, d = canvas()
    shadow(d, 0, 17)
    if happy:
        tail(d, (-11, 10), 110, -40, w=5.5, length=26)          # tail straight up: a happy cat
    else:
        tail(d, (-9, 6), 180, -60 if tail_up else -20, w=5.5, length=22)
    ell(d, -2, 15, 13, 14, FUR)                     # body
    ell(d, 3, 15, 7.5, 11, WHITE)                   # chest
    ell(d, -6, 6, 9, 6, FUR)                        # back leg
    for x in (1, 7):                                # front paws
        limb(d, x, 14, x, 2.5, 4.4, FUR)
        ell(d, x, 2.4, 2.8, 1.9, WHITE)
    for sy in (20, 15):
        limb(d, -13, sy, -8, sy + 1, 2, FUR_DARK)
    head(d, 4, 33, 1, blink, happy)
    return im


def sleeping(breath):
    """Curled up in a ball, tail wrapped round, breathing (breath 0 or 1)."""
    im, d = canvas()
    shadow(d, 0, 22)
    b = 1.0 + 0.04 * breath
    ell(d, -1, 11 * b, 21, 11 * b, FUR)
    for sx in (-12, -6, 0):
        limb(d, sx, 20 * b, sx + 2, 14 * b, 2.2, FUR_DARK)
    tail(d, (-15, 4), 5, 20, col=FUR_DARK, w=5, length=26)   # wrapped round the front, along the ground
    # head tucked in on the right, eyes shut, an ear up
    ell(d, 13, 9, 9.5, 8, FUR)
    poly(d, [(9, 14), (12, 21), (15, 14.5)], FUR)
    poly(d, [(10.5, 14.5), (12, 18.5), (13.6, 14.8)], PINK)
    ell(d, 16, 6, 5, 3.5, WHITE)
    for ex in (10, 16):
        limb(d, ex - 1.8, 10, ex + 1.8, 10, 1.1, EYE)
    return im


def zzz(frame):
    im = Image.new("RGBA", (30 * S, 34 * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    col = (255, 255, 255)
    for i, (x, y, k) in enumerate([(2, 22, 7), (12, 12, 9), (20, 1, 10)][: frame + 1]):
        k *= S / 1.4
        x, y = x * S, y * S
        d.line([(x, y), (x + k, y)], fill=col, width=int(1.6 * S))
        d.line([(x + k, y), (x, y + k)], fill=col, width=int(1.6 * S))
        d.line([(x, y + k), (x + k, y + k)], fill=col, width=int(1.6 * S))
    return im


def box(with_cat=True):
    """A cardboard box with the cat peeking out (the adoption spot)."""
    im, d = canvas()
    shadow(d, 0, 26)
    if with_cat:
        head(d, -2, 27, 1)
        limb(d, -9, 20, -9, 17, 4.4, FUR)
        limb(d, 5, 20, 5, 17, 4.4, FUR)
    poly(d, [(-24, 0), (24, 0), (24, 20), (-24, 20)], (196, 150, 98))
    poly(d, [(-24, 20), (24, 20), (30, 25), (-30, 25)], (218, 176, 122))
    poly(d, [(-24, 0), (-24, 20), (-30, 25), (-30, 5)], (170, 128, 82))
    poly(d, [(-6, 6), (6, 6), (6, 14), (-6, 14)], (170, 128, 82))     # a label patch
    return im


def heart():
    im = Image.new("RGBA", (24 * S, 22 * S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    r = 6 * S
    d.ellipse([1 * S, 1 * S, 1 * S + 2 * r, 1 * S + 2 * r], fill=(235, 70, 110))
    d.ellipse([11 * S, 1 * S, 11 * S + 2 * r, 1 * S + 2 * r], fill=(235, 70, 110))
    d.polygon([(1.5 * S, 9 * S), (22.5 * S, 9 * S), (12 * S, 21 * S)], fill=(235, 70, 110))
    return im


def save(im, name):
    w, h = im.size
    im.resize((w * 2 // S, h * 2 // S), Image.LANCZOS).save(os.path.join(HERE, name))


def main():
    for i in range(4):
        save(walking(i), f"cat_walk{i + 1}.png")
    save(sitting(False), "cat_sit1.png")
    save(sitting(True), "cat_sit2.png")
    save(sitting(False, blink=True), "cat_blink.png")
    save(sitting(False, happy=True), "cat_happy.png")
    save(sleeping(0), "cat_sleep1.png")
    save(sleeping(1), "cat_sleep2.png")
    for i in range(3):
        save(zzz(i), f"cat_zzz{i + 1}.png")
    save(box(), "cat_box.png")
    save(box(False), "cat_box_empty.png")
    save(heart(), "cat_heart.png")
    # a sheet to look at
    names = ["cat_walk1", "cat_walk3", "cat_sit1", "cat_blink", "cat_happy", "cat_sleep1", "cat_sleep2", "cat_zzz3", "cat_box", "cat_heart"]
    sheet = Image.new("RGBA", (len(names) * 170, 140), (120, 170, 110, 255))      # the campground's grass
    for i, n in enumerate(names):
        f = Image.open(os.path.join(HERE, n + ".png"))
        sheet.alpha_composite(f, (i * 170 + 5, 5))
    sheet.save(os.path.join(HERE, "..", "..", "..", "SSMod_dev", "cat_sheet.png"))


if __name__ == "__main__":
    main()

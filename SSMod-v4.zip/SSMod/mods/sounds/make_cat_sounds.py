"""Meow and purr for mods/pet_cat.ssmod, synthesized (no recordings).
  ~/ssvenv/bin/python3 mods/sounds/make_cat_sounds.py
"""
import math
import os
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SR = 44100
rng = np.random.default_rng(3)


def sweep(x, kind, f0s, q):
    """A resonant filter whose frequency moves over time (one value per sample)."""
    y = np.zeros_like(x)
    x1 = x2 = y1 = y2 = 0.0
    for k in range(0, len(x), 32):
        w = 2 * math.pi * float(f0s[k]) / SR
        al, c = math.sin(w) / (2 * q), math.cos(w)
        b = [(1 - c) / 2, 1 - c, (1 - c) / 2] if kind == "low" else [al, 0, -al]
        a0, a1, a2 = 1 + al, -2 * c, 1 - al
        b0, b1, b2, a1, a2 = b[0] / a0, b[1] / a0, b[2] / a0, a1 / a0, a2 / a0
        for i in range(k, min(len(x), k + 32)):
            xi = x[i]
            yi = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2, x1, y2, y1 = x1, xi, y1, yi
            y[i] = yi
    return y


def meow(sec=0.62, pitch=1.0):
    n = int(sec * SR)
    t = np.linspace(0, 1, n)
    # pitch: up, then a long fall (me-OW-w)
    f0 = pitch * np.interp(t, [0, .25, .55, 1], [520, 760, 700, 430]) * (1 + 0.01 * np.sin(2 * np.pi * 7 * t * sec))
    ph = 2 * np.pi * np.cumsum(f0) / SR
    src = sum(np.sin(ph * k) / k ** 1.1 for k in range(1, 14)) + 0.05 * rng.standard_normal(n)
    # the mouth: closed "m" opening to "ee", then rounding to "ow"
    f1 = np.interp(t, [0, .15, .5, 1], [300, 900, 1000, 650])
    f2 = np.interp(t, [0, .15, .45, 1], [1200, 2300, 1900, 1100])
    v = sweep(src, "band", f1, 4) * 1.0 + sweep(src, "band", f2, 6) * 0.7 + sweep(src, "band", f2 * 1.6, 8) * 0.25
    env = np.interp(t, [0, .08, .7, 1], [0, 1, .8, 0]) ** 1.2
    return v * env


def purr(sec=1.6):
    n = int(sec * SR)
    t = np.arange(n) / SR
    pulses = (np.sin(2 * np.pi * 26 * t) > 0.2).astype(float) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.9 * t) ** 2)
    noise = rng.standard_normal(n) * pulses
    v = sweep(noise, "low", np.full(n, 420.0), 0.8) + 0.4 * sweep(noise, "band", np.full(n, 160.0), 2)
    env = np.minimum(1, np.minimum(t / 0.15, (sec - t) / 0.3))
    return v * env


def save(name, x):
    x = x / (np.max(np.abs(x)) + 1e-9) * 0.8
    with wave.open(os.path.join(HERE, name), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype("<i2").tobytes())


if __name__ == "__main__":
    save("meow.wav", meow())
    save("meow2.wav", meow(0.45, 1.25))
    save("purr.wav", purr())

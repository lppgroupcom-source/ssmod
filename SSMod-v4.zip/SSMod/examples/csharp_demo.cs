// A whole mod written in C#. SSMod translates it into the game's own scripts (the game can't run new code, so
// this is C# syntax for what SSMod can do: no new classes of your own, no libraries). Errors point at these lines.
//   ./ssmod check examples/csharp_demo.cs
using SSMod;
using UnityEngine;

[Mod("C# Demo", Author = "LPP Entertainment", Version = "1.0")]
public class CSharpDemo : Mod
{
    bool MetCoach;                                              // a bool field is a flag: saved with your game
    [Sound("../mods/sounds/whistle.wav")] Sound Whistle;
    [Hud("Town", 0, -215, Color = "#FFD166")] Text Steps = "";

    // a character: where it stands, how it looks, what it says, what it does on its own
    [Npc("Town", "Bus Stop - Townhall", 160, -60)]
    class Coach : Npc
    {
        Look Look = new Look { Shirt = "#E63946", Pants = "#1D3557", Hair = "#3A2E39" };

        void Dialogue()
        {
            if (MetCoach)
            {
                Say("Back for more laps? Check the counter at the bottom of the screen.");
            }
            else
            {
                Say("Hi! I'm the coach. This whole mod is written in C#.");
                switch (Choice("Want to hear my whistle?", "Yes!", "No thanks"))
                {
                    case "Yes!":
                        Whistle.Play();
                        Say("TWEEEET! Now go walk some laps. Press J to jump.");
                        MetCoach = true;
                        break;
                    case "No thanks":
                        Say("Suit yourself.");
                        break;
                }
            }
        }

        void Behavior()
        {
            while (true)
            {
                Wander(150);
                WaitRandom(1, 3);
            }
        }
    }

    // a script: real maths on positions, every half second, while you're in Town
    [Script("Town")]
    void StepCounter()
    {
        float walked = 0f;
        Transform me = Player.transform;
        Vector2 last = me.position;
        while (true)
        {
            Vector2 now = me.position;
            walked += Vector2.Distance(now, last) / 50;         // about 50 world units a step
            last = now;
            if (MetCoach)
            {
                Steps.text = "Steps: " + Mathf.Round(walked);
            }
            Wait(0.5f);
        }
    }

    // a new control
    [OnKey("j", "Town")]
    void Jump()
    {
        var body = Player.body;
        body.velocity = new Vector2(0, 3000);
        Debug.Log("the coach would be proud");
    }
}

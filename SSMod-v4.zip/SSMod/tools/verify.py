"""Check built files for broken pointers: every local (fileID 0) pointer must hit an object in the same file,
every external fileID must be inside the file's externals list.  usage: python3 tools/verify.py DIR [level ...]"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ssmodlang.game import load
d = sys.argv[1]
names = sys.argv[2:] or sorted(n for n in os.listdir(d) if n.startswith("level"))
bad_total = 0
for n in names:
    env, f = load(n, src=os.path.join(d, n))
    O = f.objects
    ext = len(f.externals)
    bad = []
    unread = 0
    for pid, o in O.items():
        try:
            tree = o.read_typetree()
        except Exception:
            unread += 1
            continue
        def walk(node, path):
            if isinstance(node, dict):
                if set(node) == {"m_FileID", "m_PathID"}:
                    fid, p = node["m_FileID"], node["m_PathID"]
                    if p and fid == 0 and p not in O:
                        bad.append((pid, o.type.name, path, "local", p))
                    elif p and fid > ext:
                        bad.append((pid, o.type.name, path, "external", fid))
                    return
                for k, v in node.items():
                    if k != "m_Script":          # the generated layouts misread it (byte-swapped); checked raw elsewhere
                        walk(v, path + "." + k)
            elif isinstance(node, list):
                for i, v in enumerate(node[:2000]):
                    walk(v, path + f"[{i}]")
        walk(tree, "")
    bad_total += len(bad)
    print(f"{n}: {len(O)} objects, {len(bad)} broken pointers, {unread} objects without a readable layout")
    for b in bad[:15]:
        print("   ", b)
sys.exit(1 if bad_total else 0)

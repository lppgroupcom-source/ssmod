"""Switch every animation in the game off (or back on again). An experiment, fully reversible.

Characters, doors, elevators and props are all driven by Unity Animator / Animation components
(ModelAnimController.animator, SasquatchAnimController, ...). This disables every one of them, so
everything freezes in its default pose while the game itself keeps running.

    python3 tools/noanim.py off      # freeze everything (originals copied to noanim_backup/)
    python3 tools/noanim.py on       # put it all back
    python3 tools/noanim.py status

"off" copies every file it touches into noanim_backup/ first and writes a manifest with the hash of
what it wrote; "on" restores those copies and refuses to overwrite a file that changed since (an
ssmod install, say) unless --force is given. Run it AFTER ./ssmod install, not before: an install
rewrites its own 18 files from base/ and would bring their animation back.
"""
import hashlib
import json
import os
import shutil
import sys

import UnityPy

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from ssmodlang.config import game_data  # noqa: E402

DATA = game_data()
BACKUP = os.path.join(HERE, "noanim_backup")
MANIFEST = os.path.join(BACKUP, "manifest.json")
KINDS = ("Animator", "Animation")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def data_files():
    for n in sorted(os.listdir(DATA)):
        p = os.path.join(DATA, n)
        if os.path.isfile(p) and not n.endswith((".resource", ".resS")) and not n.startswith("."):
            yield n, p


def load_manifest():
    if os.path.exists(MANIFEST):
        with open(MANIFEST) as fh:
            return json.load(fh)
    return {}


def cmd_off():
    man = load_manifest()
    if man:
        print(f"animation is already off for {len(man)} file(s) - run 'on' first to start over.")
        return 1
    os.makedirs(BACKUP, exist_ok=True)
    total, touched = 0, 0
    for name, path in data_files():
        try:
            env = UnityPy.load(path)
        except Exception as e:                       # not an assets file (boot.config, *.dat, ...)
            continue
        n = 0
        for _, f in env.files.items():
            objs = getattr(f, "objects", None)
            if not objs:
                continue
            for _, o in objs.items():
                if o.type.name not in KINDS:
                    continue
                t = o.read_typetree()
                if not t.get("m_Enabled"):
                    continue                          # already off in the original: leave it alone
                t["m_Enabled"] = 0
                o.save_typetree(t)
                n += 1
        if not n:
            continue
        shutil.copy2(path, os.path.join(BACKUP, name))
        data = env.file.save()
        with open(path, "wb") as fh:
            fh.write(data)
        man[name] = {"disabled": n, "sha": sha(path)}
        total += n
        touched += 1
        print(f"  {name}: {n} animator(s) off", flush=True)
    with open(MANIFEST, "w") as fh:
        json.dump(man, fh, indent=1)
    print(f"\nanimation OFF: {total} components in {touched} files. Backups in {BACKUP}")
    return 0


def cmd_on(force=False):
    man = load_manifest()
    if not man:
        print("nothing to restore (no manifest) - animation is already on.")
        return 1
    done, skipped = 0, []
    for name, info in sorted(man.items()):
        src, dst = os.path.join(BACKUP, name), os.path.join(DATA, name)
        if not os.path.exists(src):
            skipped.append(f"{name}: backup missing")
            continue
        if os.path.exists(dst) and sha(dst) != info["sha"] and not force:
            skipped.append(f"{name}: changed since (ssmod install?) - left alone, use --force to overwrite")
            continue
        shutil.copy2(src, dst)
        os.remove(src)
        done += 1
    if skipped:
        print("skipped:")
        for s in skipped:
            print("  " + s)
    if not skipped or force:
        for p in (MANIFEST,):
            if os.path.exists(p):
                os.remove(p)
    else:
        with open(MANIFEST, "w") as fh:
            json.dump({k: v for k, v in man.items() if os.path.exists(os.path.join(BACKUP, k))}, fh, indent=1)
    print(f"animation ON: restored {done} file(s).")
    return 0


def cmd_status():
    man = load_manifest()
    if not man:
        print("animation is ON (no noanim manifest).")
        return 0
    bad = [n for n, i in man.items() if os.path.exists(os.path.join(DATA, n)) and sha(os.path.join(DATA, n)) != i["sha"]]
    print(f"animation is OFF: {sum(i['disabled'] for i in man.values())} components in {len(man)} files.")
    if bad:
        print(f"  {len(bad)} file(s) changed since: {', '.join(bad[:6])}")
    return 0


if __name__ == "__main__":
    args = sys.argv[1:]
    cmd = args[0] if args else "status"
    if cmd == "off":
        sys.exit(cmd_off())
    if cmd == "on":
        sys.exit(cmd_on("--force" in args))
    if cmd == "status":
        sys.exit(cmd_status())
    print(__doc__)
    sys.exit(2)

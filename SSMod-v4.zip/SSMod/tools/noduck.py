"""Silence the title-screen duck that says "PLEASE UPDATE!" (dialogue "Title - Cloud Requires Update").

The duck appears when the cloud copy of a save was last written by a newer build (its "mcv" is 2.2)
and this build is older. The speech is a straight line of statements with a 10 second wait in the
middle and no choices, so it is replaced by a 0.1 second wait: the game carries on exactly as it
does after the speech (you keep playing; that slot is just not uploaded to the cloud).

    python3 tools/noduck.py off      # silence the duck (original file copied to noduck_backup/)
    python3 tools/noduck.py on       # bring the duck back
    python3 tools/noduck.py status

This does not touch the version check itself, iCloud, or the save.
"""
import hashlib
import json
import os
import shutil
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from ssmodlang.game import load  # noqa: E402

from ssmodlang.config import game_data  # noqa: E402

DATA = game_data()
FILE = "sharedassets0.assets"
TREE = "Title - Cloud Requires Update"
BACKUP = os.path.join(HERE, "noduck_backup")
MANIFEST = os.path.join(BACKUP, "manifest.json")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def cmd_off():
    if os.path.exists(MANIFEST):
        print("the duck is already silenced - run 'on' first to start over.")
        return 1
    path = os.path.join(DATA, FILE)
    env, f = load(FILE, src=path)
    hit = None
    for _, o in f.objects.items():
        if o.type.name != "MonoBehaviour" or b"cloud_requires_update" not in o.get_raw_data():
            continue
        t = o.read_typetree()
        if t.get("m_Name") == TREE:
            hit = (o, t)
            break
    if not hit:
        print(f'could not find the dialogue "{TREE}" in {FILE}; nothing changed.')
        return 1
    o, t = hit
    graph = json.loads(t["_serializedGraph"])
    said = sum(1 for n in graph["nodes"] if n["$type"].endswith("StatementNode"))
    graph["nodes"] = [{"_action": {"waitTime": {"_value": 0.1}, "$type": "NodeCanvas.Tasks.Actions.Wait"},
                       "$type": "NodeCanvas.DialogueTrees.ActionNode", "$id": "1"}]
    graph["connections"] = []
    t["_serializedGraph"] = json.dumps(graph)
    o.save_typetree(t)
    os.makedirs(BACKUP, exist_ok=True)
    shutil.copy2(path, os.path.join(BACKUP, FILE))
    data = f.save()
    with open(path, "wb") as fh:
        fh.write(data)
    with open(MANIFEST, "w") as fh:
        json.dump({FILE: {"sha": sha(path), "lines_removed": said}}, fh, indent=1)
    print(f"duck silenced: {said} lines removed from \"{TREE}\". Backup in {BACKUP}")
    return 0


def cmd_on(force=False):
    if not os.path.exists(MANIFEST):
        print("nothing to restore - the duck is already back.")
        return 1
    with open(MANIFEST) as fh:
        man = json.load(fh)
    src, dst = os.path.join(BACKUP, FILE), os.path.join(DATA, FILE)
    if sha(dst) != man[FILE]["sha"] and not force:
        print(f"{FILE} changed since (noanim?) - left alone. Undo that first, or use --force to overwrite.")
        return 1
    shutil.copy2(src, dst)
    os.remove(src)
    os.remove(MANIFEST)
    print("duck restored.")
    return 0


def cmd_status():
    print("the duck is SILENCED." if os.path.exists(MANIFEST) else "the duck is as the game shipped it.")
    return 0


if __name__ == "__main__":
    args = sys.argv[1:]
    cmd = args[0] if args else "status"
    if cmd == "off":
        sys.exit(cmd_off())
    if cmd == "on":
        sys.exit(cmd_on("--force" in args))
    if cmd == "status":
        sys.exit(cmd_status())
    print(__doc__)
    sys.exit(2)

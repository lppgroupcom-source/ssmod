using System; using System.IO; using System.Linq; using System.Reflection; using System.Text;
class P {
  static string N(Type t) {
    if (t == null) return "?";
    if (t.IsGenericType) {
      var b = t.GetGenericTypeDefinition().FullName;
      return b + "[" + string.Join(",", t.GetGenericArguments().Select(N)) + "]";
    }
    return (t.FullName ?? t.Name);
  }
  static void Main(string[] a) {
    var dir = Path.GetDirectoryName(a[0]);
    AppDomain.CurrentDomain.AssemblyResolve += (s, e) => {
      var nm = new AssemblyName(e.Name).Name + ".dll"; var p = Path.Combine(dir, nm); if (!File.Exists(p)) p = Path.Combine(Environment.GetEnvironmentVariable("UNITYMANAGED"), nm);
      return File.Exists(p) ? Assembly.LoadFrom(p) : null;
    };
    var asm = Assembly.LoadFrom(a[0]);
    Type[] types;
    try { types = asm.GetTypes(); }
    catch (ReflectionTypeLoadException ex) {
      // some classes failed to load and the rest come back incomplete: list every class name with Cecil and
      // load each one on its own
      var got = ex.Types.Where(t => t != null).ToList();
      var have = new System.Collections.Generic.HashSet<string>(got.Select(t => t.FullName));
      var md = Mono.Cecil.ModuleDefinition.ReadModule(a[0]);
      foreach (var td in md.GetTypes()) {
        var nm = td.FullName.Replace("/", "+");
        if (have.Contains(nm)) continue;
        try { var t = asm.GetType(nm); if (t != null) { got.Add(t); have.Add(nm); } } catch {}
      }
      types = got.ToArray();
    }
    var sb = new StringBuilder();
    foreach (var t in types.OrderBy(x => x.FullName)) {
      MethodInfo[] ms;
      // instance and static separately: one unloadable signature then only costs its own group
      var found = new System.Collections.Generic.List<MethodInfo>();
      try { found.AddRange(t.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly)); } catch {}
      try { found.AddRange(t.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly)); } catch {}
      ms = found.ToArray();
      string kind = "class";
      try { for (var b = t.BaseType; b != null; b = b.BaseType) { if (b.FullName == "UnityEngine.Component") { kind = "component"; break; } if (b.FullName == "UnityEngine.ScriptableObject") { kind = "asset"; break; } } if (t.IsEnum) kind = "enum"; } catch {}
      try { sb.AppendLine("type\t" + N(t) + "\t" + (t.BaseType == null ? "" : N(t.BaseType)) + "\t" + kind); } catch {}
      try {
        foreach (var fi in t.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly))
          if (!fi.Name.Contains("<")) sb.AppendLine("field\t" + N(t) + "\t" + fi.Name + "\t" + N(fi.FieldType) + "\t" + (fi.IsPublic ? "public" : "private"));
      } catch {}
      try {
        foreach (var ev in t.GetEvents(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance | BindingFlags.DeclaredOnly)) {
          var add = ev.GetAddMethod();
          sb.AppendLine("event\t" + N(t) + "\t" + ev.Name + "\t" + N(ev.EventHandlerType) + "\t" + (add != null && add.IsStatic ? "static" : "instance"));
        }
      } catch {}
      if (t.IsEnum) { try { sb.AppendLine("enum\t" + N(t) + "\t" + string.Join(",", Enum.GetNames(t))); } catch {} continue; }
      foreach (var m in ms) {
        if (m.IsSpecialName && !(m.Name.StartsWith("get_") || m.Name.StartsWith("set_"))) continue;
        string ps;
        try { ps = string.Join("|", m.GetParameters().Select(p => N(p.ParameterType) + " " + p.Name)); } catch { ps = "?"; }
        string rt; try { rt = N(m.ReturnType); } catch { rt = "?"; }
        sb.AppendLine(string.Join("\t", kind, N(t), m.Name, m.IsStatic ? "static" : "instance", rt, ps, m.IsGenericMethodDefinition ? "generic" : ""));
      }
    }
    File.WriteAllText(a[1], sb.ToString());
    Console.WriteLine("types " + types.Length);
  }
}

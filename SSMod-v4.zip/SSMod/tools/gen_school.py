# Sasquatch School - exec'd by gen_airport.py after gen_part3.py (it lives in the airport mod because its front
# door is on the airport grounds: the old race office next to the terminal becomes the school building).
#   School_Hall        lockers, trophy case, hall monitor; doors to every room
#   Classroom_101      Math + Science (quizzes)
#   Classroom_102      Geography + Sasquatch Studies (quizzes)
#   School_Library     four books that hold the quiz answers
#   Principal_Office   the report card and the diploma
#   School_Cafeteria   lunch you can't buy anywhere else, the lunch-money bully, a delivery job
#   School_Gym         the cone run (a 40 second script)
# Same rules as Parts 2 and 3: top/bottom doors only, right wall at x = -3600, no `end;`, progress is kept in
# flags (items are only rewards).
SH, C1, C2, SL, SP, SC, SG = ("School_Hall", "Classroom_101", "Classroom_102", "School_Library",
                              "Principal_Office", "School_Cafeteria", "School_Gym")

w("// ================================================================ SASQUATCH SCHOOL")
w("flag MathPass, SciencePass, GeoPass, SquatchPass, GymPass, Graduated, MetPrincipal, GymOn, Cone1, Cone2, Cone3,")
w("     Cone4, PaidBully, StoodUpToBully, LunchJob, LunchDelivered, FedHamster, ReadMath, ReadScience, ReadGeo, ReadSquatch;")
w('item Diploma { name = "Sasquatch School Diploma"; description = "Straight A\'s. Mostly. Signed by Principal Pinecone."; icon = sprite("ui_doctor_diploma"); base = "Chairlift Ticket"; }')
w('item GoldStar { name = "Gold Star"; description = "For excellent work. You may stick it on your forehead."; icon = sprite("emoji_symbol_trophy"); base = "Chairlift Ticket"; }')
w('item MysteryMeat { name = "Mystery Meat"; description = "Nobody knows. Nobody asks. Only served at school."; icon = sprite("diner_burger_small"); base = "Burger"; }')
w('item TaterTots { name = "Tater Tots"; description = "Crispy little cafeteria legends."; icon = sprite("fries"); base = "Fries"; }')
w('item ChocMilkCarton { name = "Carton of Chocolate Milk"; description = "The tiny carton that is impossible to open."; icon = sprite("chocolatemilk"); base = "Chocolate Milk"; }')
w('item PrincipalLunch { name = "The Principal\'s Lunch Tray"; description = "Mystery meat, extra gravy. Do not eat. (You want to.)"; icon = sprite("pizza"); base = "Chairlift Ticket"; }')
w('''
area School_Hall from "TownHall_Floor_B1" named "Sasquatch School" {
    room (-6600, 807) to (-3600, 1507);
    door South at (-5100, 807);                      // out to the street
    door North at (-6200, 1507);                     // room 101
    door NorthAlt at (-5400, 1507);                  // room 102
    door East at (-4600, 1507) facing North;         // library
    door West at (-3950, 1507) facing North;         // principal
    door SouthAlt at (-6100, 807);                   // cafeteria
    door EastAlt at (-4100, 807) facing South;       // gym
    connect South to "Airport" West;
    connect North to "Classroom_101" South;
    connect NorthAlt to "Classroom_102" South;
    connect East to "School_Library" South;
    connect West to "Principal_Office" South;
    connect SouthAlt to "School_Cafeteria" North;
    connect EastAlt to "School_Gym" North;
}
area Classroom_101 from "TownHall_Floor_B1" named "Room 101 - Math and Science" {
    room (-5600, 807) to (-3600, 1707);
    door South at (-4600, 807);
    connect South to "School_Hall" North;
}
area Classroom_102 from "TownHall_Floor_B1" named "Room 102 - Geography and Sasquatch Studies" {
    room (-5600, 807) to (-3600, 1707);
    door South at (-4600, 807);
    connect South to "School_Hall" NorthAlt;
}
area School_Library from "TownHall_Floor_B1" named "School Library" {
    room (-5800, 807) to (-3600, 1707);
    door South at (-4700, 807);
    connect South to "School_Hall" East;
}
area Principal_Office from "TownHall_Floor_B1" named "The Principal's Office" {
    room (-4800, 807) to (-3600, 1507);
    door South at (-4200, 807);
    connect South to "School_Hall" West;
}
area School_Cafeteria from "TownHall_Floor_B1" named "School Cafeteria" {
    room (-6200, 807) to (-3600, 1807);
    door North at (-4900, 1807);
    connect North to "School_Hall" SouthAlt;
}
area School_Gym from "TownHall_Floor_B1" named "School Gym" {
    room (-6400, 807) to (-3600, 2007);
    door North at (-5000, 2007);
    connect North to "School_Hall" EastAlt;
}
''')
for _s in (SH, C1, C2, SL, SP, SC, SG):
    w(f'hide "townhall_dailychallenge_board" in "{_s}";')
    w(f'hide "sign" in "{_s}";')


# ---------------------------------------------------------------- building blocks
def chalkboard(scene, x, y, title, lines, wd=560):
    """A green board on the back wall: a title and a few lines of chalk."""
    ht = 70 + 34 * len(lines)
    rect(scene, x, y, wd + 16, ht + 16, "8B5E34", 13)
    rect(scene, x, y, wd, ht, "2D6A4F", 13.5)
    text(scene, x, y + ht / 2 - 38, title, "FFFFFF", sx=wd / 150 * 0.55, sy=0.8, front=16 + ht * 0.05)
    for k, ln in enumerate(lines):
        yy = y + ht / 2 - 78 - 34 * k
        text(scene, x, yy, ln, "E9F5DB", sx=wd / 150 * 0.8, sy=0.6, front=16 + ht * 0.05)
    rect(scene, x, y - ht / 2 - 12, wd * 0.7, 8, "D9D9D9", 13.5)            # the chalk ledge


def desk(scene, x, y, col="C89F6D"):
    """A student desk with its chair (seen from the front of the class)."""
    rect(scene, x, y + 26, 92, 46, col, 1)
    rect(scene, x, y + 4, 92, 8, "8B5E34", 1.2)
    rect(scene, x - 36, y - 10, 8, 26, "6C757D", 1)
    rect(scene, x + 36, y - 10, 8, 26, "6C757D", 1)
    rect(scene, x, y - 46, 50, 34, "457B9D", 0.5)                            # chair


def lockers(scene, x0, y, n, col):
    for k in range(n):
        x = x0 + k * 62
        rect(scene, x, y, 58, 150, "2B2D42", 13)
        rect(scene, x, y, 52, 144, col, 13.5)
        rect(scene, x, y + 46, 30, 4, "2B2D42", 21)
        rect(scene, x, y + 38, 30, 4, "2B2D42", 21)
        rect(scene, x + 16, y - 6, 6, 16, "E9ECEF", 21)


def poster(scene, x, y, words, bg, fg="FFFFFF", wd=200, ht=44):
    sign(scene, x, y, words, bg, fg, wd=wd, ht=ht, front=14)


def quiz(name, scene, x, y, shirt, pants, subject, flag, read_flag, intro, questions, prize):
    """A teacher with a three-question test. One wrong answer ends the lesson; pass and the flag is set."""
    def ask(k, ind):
        q, opts, right, wrong = questions[k]
        pad = "    " * ind
        out = [f'{pad}say "{q}";', f"{pad}choice {{"]
        for i, o in enumerate(opts):
            if i == right:
                out.append(f'{pad}    "{o}" => {{')
                if k + 1 < len(questions):
                    out.append(f'{pad}        say "Correct!";')
                    out += ask(k + 1, ind + 2)
                else:
                    out.append(f'{pad}        set {flag};')
                    out.append(f'{pad}        give coins {prize};')
                    out.append(f'{pad}        give GoldStar;')
                    out.append(f'{pad}        say "<shake>CORRECT!</shake> Three out of three. You pass <item>{subject}</item>! Here is a gold star and <price>{prize}</price> coins.";')
                out.append(f"{pad}    }}")
            else:
                out.append(f'{pad}    "{o}" => say "{wrong}";')
        out.append(f"{pad}}}")
        return out
    body = "\n".join(ask(0, 4))
    w(f'''npc {name} in "{scene}" at ({x}, {y}) {{
    look {{ shirt = #{shirt}; pants = #{pants}; }}
    bubble = true;
    dialogue {{
        if ({flag}) {{
            say "You already passed <item>{subject}</item>. A+. Go and bother the principal about your <item>report card</item>.";
        }} else {{
            say "{intro}";
            choice {{
                "Take the {subject} test" => {{
{body}
                }}
                "Any hints?" => {{
                    if ({read_flag}) say "You've read the book. You know all of this. Deep breath!";
                    else say "The answers are all in a book in the <item>School Library</item>. Reading. It works.";
                }}
                "Not yet" => say "The test will be here. Tests are always here.";
            }}
        }}
    }}
}}''')


# ================================================================= OUTSIDE: the school building
w("// ---------------------------------------------------------------- the school building (airport grounds)")
w(f'hide "Race Office" in "{A}";')
w(f'hide "Dog Poster" in "{A}";')                              # a stock poster that stood right in the doorway
floor(A, -930, 690, 800, 440, "B5523B", 5)                       # brick front
for k in range(5):                                               # brick courses
    floor(A, -930, 760 + k * 74, 800, 5, "9C4431", 6)
floor(A, -950, 1130, 840, 96, "5B3A29", 6)                       # roof
floor(A, -950, 1118, 840, 14, "3E2718", 7)
floor(A, -600, 1226, 144, 110, "B5523B", 6)                      # the bell tower
floor(A, -616, 1336, 176, 26, "5B3A29", 7)
place(A, CIRCLE, -528, 1284, "size (70, 70)", "color #F8F9FA", "front 30")
rect(A, -528, 1294, 5, 24, "2B2D42", 31)
rect(A, -518, 1284, 20, 5, "2B2D42", 31)
for x in (-890, -760, -400, -270):                               # windows
    floor(A, x, 850, 104, 130, "F1FAEE", 6)
    floor(A, x + 8, 858, 88, 114, "A8DADC", 7)
    floor(A, x + 49, 858, 6, 114, "F1FAEE", 8)
    floor(A, x + 8, 912, 88, 6, "F1FAEE", 8)
floor(A, -618, 690, 180, 230, "F1FAEE", 6)                       # the front doors
floor(A, -608, 690, 76, 220, "33415C", 7)
floor(A, -524, 690, 76, 220, "33415C", 7)
floor(A, -596, 800, 52, 90, "A8DADC", 8)
floor(A, -512, 800, 52, 90, "A8DADC", 8)
floor(A, -660, 640, 264, 50, "ADB5BD", 5)                        # steps
floor(A, -640, 660, 224, 30, "CED4DA", 6)
sign(A, -528, 1050, "SASQUATCH SCHOOL", "1D3557", "FFD166", wd=440, ht=64, front=40)
sign(A, -528, 985, "EST. LAST TUESDAY", "F1FAEE", "1D3557", wd=230, ht=30, front=36)
# the building is solid: wall pieces round the footprint, with a gap at the doors
place(A, WALL_H, -930, 688, f"scale ({(-640 + 930) / 669.2:.4f}, 1)", "color #8D99AE")
place(A, WALL_H, -416, 688, f"scale ({(-130 + 416) / 669.2:.4f}, 1)", "color #8D99AE")
rect(A, -1010, 840, 10, 360, "ADB5BD", 0)                        # flagpole
rect(A, -972, 990, 66, 44, "D62828", 0.5)
rect(A, -972, 990, 22, 44, "F8F9FA", 0.7)
# the school bus
rect(A, -10, 470, 360, 120, "FFC300", 0)
rect(A, -10, 432, 360, 10, "1B1C1F", 0.5)
rect(A, -10, 500, 330, 40, "A8DADC", 0.5)
for dx in (-110, -55, 0, 55, 110):
    rect(A, -10 + dx, 500, 6, 40, "FFC300", 0.7)
text(A, -10, 446, "SCHOOL BUS", "1B1C1F", 1.5, 0.5, 1)
for dx in (-110, 110):
    place(A, CIRCLE, -10 + dx, 412, "size (56, 56)", "color #1B1C1F", "front 1")
    place(A, CIRCLE, -10 + dx, 412, "size (24, 24)", "color #ADB5BD", "front 1.5")
rect(A, 180, 470, 20, 70, "D62828", 0.5)                         # stop sign arm
w(f'''
npc Crossing_Guard in "{A}" at (-330, 590) {{
    look {{ shirt = #FFD166; pants = #2B2D42; }}
    bubble = true;
    dialogue {{
        if (Graduated) say "A graduate! Look both ways anyway. Diplomas don't stop buses.";
        else {{
            say "Morning! <item>Sasquatch School</item> is open. Enrollment is free and nobody checks if you're a sasquatch.";
            say "Pass <item>Math</item>, <item>Science</item>, <item>Geography</item>, <item>Sasquatch Studies</item> and <item>Gym</item>, then see the principal for your <item>diploma</item>.";
        }}
    }}
}}
npc Bus_Driver in "{A}" at (230, 400) {{
    look {{ shirt = #457B9D; pants = #1D3557; }}
    dialogue {{ say "Thirty kids, one bus, no radio. I've seen things."; }}
}}
''')

# ================================================================= THE HALL   x -6600..-3600, y 807..1507
floor(SH, -6600, 807, 3000, 700, "D8C9A8", 3)
for k in range(15):                                              # checkerboard strip down the middle
    floor(SH, -6600 + k * 200, 1120, 100, 60, "B7A57A", 4)
    floor(SH, -6500 + k * 200, 1060, 100, 60, "B7A57A", 4)
sign(SH, -5100, 1592, "SASQUATCH SCHOOL", "1D3557", "FFD166", wd=360, ht=52, front=14)
door_mat(SH, -6200, 1507, "ROOM 101", up=True, bg="2A9D8F", fg="FFFFFF")
door_mat(SH, -5400, 1507, "ROOM 102", up=True, bg="E76F51", fg="FFFFFF")
door_mat(SH, -4600, 1507, "LIBRARY", up=True, bg="6A4C93", fg="FFFFFF")
door_mat(SH, -3950, 1507, "PRINCIPAL", up=True, bg="1D3557", fg="FFD166")
door_mat(SH, -6100, 807, "CAFETERIA", up=False, bg="F4A261", fg="1D3557")
door_mat(SH, -5100, 807, "EXIT", up=False, bg="D62828", fg="FFFFFF")
door_mat(SH, -4100, 807, "GYM", up=False, bg="457B9D", fg="FFFFFF")
lockers(SH, -5960, 1592, 5, "457B9D")
lockers(SH, -4320, 1592, 3, "E63946")
# the trophy case
rect(SH, -5770, 1380, 330, 150, "5B3A29", 1)
rect(SH, -5770, 1392, 306, 110, "A8DADC", 1.5)
for dx, col in ((-110, "FFD166"), (-40, "CED4DA"), (40, "CD7F32"), (110, "FFD166")):
    rect(SH, -5770 + dx, 1376, 26, 46, col, 2)
    rect(SH, -5770 + dx, 1348, 40, 10, "2B2D42", 2)
sign(SH, -5770, 1482, "TROPHIES (MOSTLY CHESS)", "5B3A29", "FFD166", wd=300, ht=30, front=3)
for x in (-6520, -3680):
    prop(SH, "Town", "Town Hall/plantpotted_townhall", x, 880)
prop(SH, "Stripmall", "Room Reception/Watercooler", -4920, 1400)
prop(SH, "Stripmall", "TrashCanTown (1)", -5650, 880)
prop(SH, "Stripmall", "Room Reception/Hospital Bench", -4700, 880)
poster(SH, -3720, 1300, "NO RUNNING", "D62828", wd=150, ht=36)
w(f'''
npc Hall_Monitor in "{SH}" at (-5950, 1170) {{
    look {{ shirt = #F4A261; pants = #264653; }}
    bubble = true;
    dialogue {{
        say "Halt! <item>Hall Monitor</item>. No running, no shouting, no sasquatches. ...Hm. Two out of three.";
        choice {{
            "Where do I go?" => {{
                say "<item>Room 101</item> for Math and Science, <item>Room 102</item> for Geography and Sasquatch Studies. Top wall.";
                say "<item>Library</item> if you want the answers. <item>Gym</item> and <item>Cafeteria</item> are downstairs. Bottom wall.";
                say "When you've passed all five, the <item>Principal</item> hands out the diplomas.";
            }}
            "How am I doing?" => {{
                if (MathPass && SciencePass && GeoPass && SquatchPass && GymPass) say "All five passed! Principal's office. Now. Walk, don't run.";
                else say "Not all five yet. The principal has your <item>report card</item> if you want the details.";
            }}
            "Bye" => say "Walk. WALK.";
        }}
    }}
    patrol {{ (-5950, 1170); wait 3; (-5650, 1170); wait 3; }}
}}
npc Janitor_Gus in "{SH}" at (-6380, 1010) {{
    look {{ shirt = #6C757D; pants = #343A40; }}
    dialogue {{
        say "Forty years I've mopped this hall. It was built last Tuesday. Don't ask.";
        say "Tip from an old pro: the <item>cafeteria</item> mystery meat is only a mystery if you don't read the box.";
    }}
}}
spot Trophy_Case in "{SH}" at (-5770, 1250) {{
    dialogue {{
        if (Graduated) say "There's a new plaque: <item>FIRST SASQUATCH GRADUATE</item>. They spelled 'sasquatch' wrong.";
        else say "Chess, chess, chess, and one for <item>Most Improved Hall Monitor</item>.";
    }}
}}
''')

# ================================================================= ROOM 101   x -5600..-3600, y 807..1707
floor(C1, -5600, 807, 2000, 900, "CFE8D5", 3)
door_mat(C1, -4600, 807, "HALL", up=False, bg="2A9D8F", fg="FFFFFF")
chalkboard(C1, -5050, 1800, "MATH", ["7 x 8 = 56", "half of 100 = 50", "a triangle has 3 sides"])
chalkboard(C1, -4150, 1800, "SCIENCE", ["H2O = water", "plants eat sunlight", "the sun is a star"])
for row, y in enumerate((1330, 1130)):
    for x in (-5380, -5180, -4980, -4220, -4020, -3820):
        desk(C1, x, y)
prop(C1, "Stripmall", "Room Reception/Desk", -5050, 1520)
prop(C1, "Stripmall", "Room Reception/Desk", -4150, 1520)
prop(C1, "Town", "Town Hall/plantpotted_townhall", -5530, 880)
prop(C1, "Town", "Bank/bank bookshelf", -3700, 1560)
rect(C1, -5500, 1560, 90, 60, "E9ECEF", 1)                       # the hamster cage
rect(C1, -5500, 1560, 76, 46, "FFE8A1", 1.5)
rect(C1, -5486, 1552, 22, 16, "C89F6D", 2)
sign(C1, -5500, 1620, "MR. NIBBLES", "F4A261", "1D3557", wd=130, ht=26, front=3)
quiz("Mr_Abacus", C1, -5050, 1420, "2A9D8F", "264653", "Math", "MathPass", "ReadMath",
     "Welcome to <item>Math</item>! Three questions. Get them all and you pass. No calculators, no counting on toes.",
     [("Question 1. What is 7 times 8?", ["54", "56", "58", "78"], 1, "Oof. No. Seven eights are... not that. Class dismissed - try again!"),
      ("Question 2. What is half of 100?", ["25", "200", "50"], 2, "Half! HALF! Go and think about what you've done. Try again."),
      ("Question 3. How many sides does a triangle have?", ["3", "4", "It depends on the triangle"], 0, "It's in the NAME. TRI-angle. Back to the start!")],
     60)
quiz("Ms_Beaker", C1, -4150, 1420, "9B5DE5", "3C096C", "Science", "SciencePass", "ReadScience",
     "<item>Science</item>! Safety goggles on. Three questions, no explosions (today).",
     [("Question 1. What is H2O?", ["Hot sauce", "Water", "A robot"], 1, "Please do not drink a robot. Try again!"),
      ("Question 2. What do plants use to make their food?", ["Sunlight", "Pizza", "Wi-Fi"], 0, "If only. No - try again once you've read up."),
      ("Question 3. What is the Sun?", ["A planet", "A big lamp", "A star"], 2, "Our nearest star would like a word. Try again!")],
     60)
w(f'''
spot Hamster_Cage in "{C1}" at (-5500, 1440) {{
    dialogue {{
        if (FedHamster) say "<item>Mr. Nibbles</item> is asleep in a pile of your tater tots. Living his best life.";
        else if (has(TaterTots)) {{ take TaterTots; set FedHamster; give coins 25; say "You share your <item>tater tots</item> with Mr. Nibbles. He pushes <price>25</price> coins out of his bedding. Where did a hamster get coins?"; }}
        else say "<item>Mr. Nibbles</item>, the class hamster, stares at you. He looks hungry. He likes <item>tater tots</item>.";
    }}
}}
npc Student_Dot in "{C1}" at (-4980, 1010) {{
    look {{ shirt = #FFB703; pants = #023047; }}
    dialogue {{ say "Psst. The answers are on the board. Mr. Abacus hasn't noticed in <shake>three years</shake>."; }}
}}
npc Student_Otis in "{C1}" at (-4020, 1010) {{
    look {{ shirt = #8AC926; pants = #386641; }}
    dialogue {{ say "I asked Ms. Beaker if we could make a volcano. She said 'not again'."; }}
}}
''')

# ================================================================= ROOM 102   x -5600..-3600, y 807..1707
floor(C2, -5600, 807, 2000, 900, "FBE3C8", 3)
door_mat(C2, -4600, 807, "HALL", up=False, bg="E76F51", fg="FFFFFF")
chalkboard(C2, -5050, 1800, "GEOGRAPHY", ["Zurich = Switzerland", "Cancun = Mexico", "we live in Canada"])
chalkboard(C2, -4150, 1800, "SASQUATCH STUDIES", ["rangers: AVOID", "food: in coolers", "disguise: wear one"], wd=600)
for y in (1330, 1130):
    for x in (-5380, -5180, -4980, -4220, -4020, -3820):
        desk(C2, x, y, "D9A066")
prop(C2, "Stripmall", "Room Reception/Desk", -5050, 1520)
prop(C2, "Stripmall", "Room Reception/Desk", -4150, 1520)
place(C2, CIRCLE, -5500, 1560, "size (110, 110)", "color #3A86FF", "front 1")      # the globe
place(C2, CIRCLE, -5514, 1574, "size (44, 36)", "color #52B788", "front 1.5")
place(C2, CIRCLE, -5478, 1540, "size (30, 30)", "color #52B788", "front 1.5")
rect(C2, -5500, 1494, 60, 12, "5B3A29", 1)
prop(C2, "Town", "Town Hall/plantpotted_townhall", -3680, 880)
quiz("Mrs_Atlas", C2, -5050, 1420, "E76F51", "6D2E1F", "Geography", "GeoPass", "ReadGeo",
     "<item>Geography</item>! The world is big and you have seen, I'm guessing, one campground. Three questions.",
     [("Question 1. Flight 101 from the airport next door lands in Zurich. Which country is that?", ["Switzerland", "Sweden", "Swaziland", "Saskatchewan"], 0, "Close alphabetically. Wrong geographically. Try again!"),
      ("Question 2. Where is Cancun?", ["Canada", "Mexico", "The Moon"], 1, "Go and look at the board. I'll pretend I'm not watching. Try again."),
      ("Question 3. Which country are we in right now?", ["England", "Mexico", "Canada, eh"], 2, "You LIVE here! Back to the start, eh.")],
     60)
quiz("Professor_Bigfoot", C2, -4150, 1420, "6B4A2B", "3E2718", "Sasquatch Studies", "SquatchPass", "ReadSquatch",
     "<item>Sasquatch Studies</item>. I am definitely a human professor in a very good coat. Three questions.",
     [("Question 1. A ranger is walking towards you. What do you do?", ["Wave", "Sneak away", "Ask for directions"], 1, "And now you're in the back of a ranger truck. Try again."),
      ("Question 2. Where do campers keep the best food?", ["In coolers", "In the lake", "In their shoes"], 0, "Have you ever EATEN from a shoe? Don't answer that. Try again."),
      ("Question 3. How does a sasquatch walk around town without trouble?", ["Very fast", "At night only", "In a disguise"], 2, "That's how you end up on the news. Try again!")],
     80)
w(f'''
npc Student_Pip in "{C2}" at (-5180, 1010) {{
    look {{ shirt = #FF595E; pants = #1D3557; }}
    dialogue {{ say "Professor Bigfoot is SO hairy. And tall. And he ate my sandwich in one bite. Best teacher ever."; }}
}}
npc Student_Wren in "{C2}" at (-3820, 1010) {{
    look {{ shirt = #1982C4; pants = #14213D; }}
    dialogue {{ say "I've been to Mexico. On the plane next door. I had to pay for the <shake>window</shake>."; }}
}}
''')

# ================================================================= LIBRARY   x -5800..-3600, y 807..1707
floor(SL, -5800, 807, 2200, 900, "7B5E3B", 3)
floor(SL, -5300, 1000, 1200, 420, "8E2F3C", 4)                   # reading rug
floor(SL, -5270, 1030, 1140, 360, "A63D4C", 5)
door_mat(SL, -4700, 807, "HALL", up=False, bg="6A4C93", fg="FFFFFF")
sign(SL, -4700, 1792, "LIBRARY", "6A4C93", "FFFFFF", wd=320, ht=56, front=14)
poster(SL, -5450, 1792, "SHHHHHHHH", "2B2D42", wd=220, ht=40)
poster(SL, -3950, 1792, "READING IS SNEAKING FOR THE BRAIN", "2B2D42", "FFD166", wd=420, ht=40)
for x in (-5650, -5350, -5050, -4350, -4050, -3750):
    prop(SL, "Town", "Bank/bank bookshelf", x, 1590)
for x, lab, col in ((-5500, "MATH", "2A9D8F"), (-5100, "SCIENCE", "9B5DE5"), (-4300, "GEOGRAPHY", "E76F51"),
                    (-3900, "SASQUATCH", "6B4A2B")):
    rect(SL, x, 1440, 150, 70, "C89F6D", 1)                      # a reading stand with an open book
    rect(SL, x, 1452, 96, 44, "F8F9FA", 1.5)
    rect(SL, x, 1452, 4, 44, "ADB5BD", 2)
    sign(SL, x, 1516, lab, col, "FFFFFF", wd=150, ht=28, front=3)
for x in (-5000, -4400):
    prop(SL, "Town", "Coffee Shop/CoffeeTableHigh", x, 1180)
prop(SL, "Stripmall", "Room Reception/Desk", -4700, 1500)
prop(SL, "Town", "Town Hall/plantpotted_townhall", -5720, 880)
prop(SL, "Town", "Town Hall/plantpotted_townhall", -3680, 880)
w(f'''
npc Librarian in "{SL}" at (-4700, 1400) {{
    look {{ shirt = #6A4C93; pants = #2B2D42; }}
    bubble = true;
    dialogue {{
        say "<shake>Shhhh.</shake> Welcome to the library. Four books on four stands. Each one has every answer to one test.";
        if (ReadMath && ReadScience && ReadGeo && ReadSquatch) say "You've read all four? I'm so proud I could whisper.";
        else say "Reading them is not cheating. It is called <item>studying</item>. Off you go. Quietly.";
    }}
}}
spot Math_Book in "{SL}" at (-5500, 1330) {{
    dialogue {{
        set ReadMath;
        say "<item>MATH FOR MAMMALS</item>. You read: 7 times 8 is <item>56</item>. Half of 100 is <item>50</item>. A triangle has <item>3</item> sides.";
    }}
}}
spot Science_Book in "{SL}" at (-5100, 1330) {{
    dialogue {{
        set ReadScience;
        say "<item>SCIENCE, PROBABLY</item>. You read: H2O is <item>water</item>. Plants make food from <item>sunlight</item>. The Sun is a <item>star</item>.";
    }}
}}
spot Geography_Book in "{SL}" at (-4300, 1330) {{
    dialogue {{
        set ReadGeo;
        say "<item>PLACES THAT ARE NOT HERE</item>. You read: Zurich is in <item>Switzerland</item>. Cancun is in <item>Mexico</item>. We are in <item>Canada</item>.";
    }}
}}
spot Sasquatch_Book in "{SL}" at (-3900, 1330) {{
    dialogue {{
        set ReadSquatch;
        say "<item>SO YOU ARE A SASQUATCH</item>. You read: <item>sneak away</item> from rangers. The best food is in <item>coolers</item>. Wear a <item>disguise</item> in town.";
    }}
}}
npc Bookworm in "{SL}" at (-5000, 1080) {{
    look {{ shirt = #BC6C25; pants = #283618; }}
    dialogue {{ say "I've read every book in here. All four. Twice."; }}
}}
''')

# ================================================================= PRINCIPAL   x -4800..-3600, y 807..1507
floor(SP, -4800, 807, 1200, 700, "2F4858", 3)
floor(SP, -4600, 950, 800, 380, "86BBD8", 4)                     # rug
door_mat(SP, -4200, 807, "HALL", up=False, bg="1D3557", fg="FFD166")
sign(SP, -4200, 1592, "PRINCIPAL PINECONE", "1D3557", "FFD166", wd=380, ht=52, front=14)
poster(SP, -4620, 1592, "#1 PRINCIPAL", "FFD166", "1D3557", wd=170, ht=34)
poster(SP, -3790, 1592, "HANG IN THERE", "52B788", wd=180, ht=34)
prop(SP, "Stripmall", "Room Reception/Desk", -4200, 1440)
prop(SP, "Town", "Bank/bank bookshelf", -4640, 1400)
prop(SP, "Town", "Bank/bank bookshelf", -3760, 1400)
prop(SP, "Town", "Town Hall/BlackCouch", -4640, 1000)
prop(SP, "Town", "Town Hall/plantpotted_townhall", -3680, 880)
prop(SP, "Stripmall", "Room Reception/Watercooler", -4720, 1250)
w(f'''
npc Principal_Pinecone in "{SP}" at (-4200, 1320) {{
    look {{ shirt = #1D3557; pants = #14213D; }}
    bubble = true;
    dialogue {{
        if (Graduated) {{
            say "My finest graduate. And my only one. The school has been open since Tuesday.";
            if (LunchJob && !LunchDelivered && has(PrincipalLunch)) {{ take PrincipalLunch; set LunchDelivered; give coins 80; say "And you brought my <item>lunch</item>! Here's <price>80</price> coins. Extra gravy. Good."; }}
        }} else if (LunchJob && !LunchDelivered && has(PrincipalLunch)) {{
            take PrincipalLunch; set LunchDelivered; give coins 80;
            say "My <item>lunch tray</item>! Mystery meat, extra gravy. Here's <price>80</price> coins. You're a model student.";
        }} else {{
            if (!MetPrincipal) {{ set MetPrincipal; say "Ah, the new student. Very tall for your age. I'm <item>Principal Pinecone</item>."; }}
            say "Let's have a look at your <item>report card</item>.";
            if (MathPass) say "Math: <item>A+</item>."; else say "Math: <shake>incomplete</shake>. Room 101, Mr. Abacus.";
            if (SciencePass) say "Science: <item>A+</item>."; else say "Science: <shake>incomplete</shake>. Room 101, Ms. Beaker.";
            if (GeoPass) say "Geography: <item>A+</item>."; else say "Geography: <shake>incomplete</shake>. Room 102, Mrs. Atlas.";
            if (SquatchPass) say "Sasquatch Studies: <item>A+</item>."; else say "Sasquatch Studies: <shake>incomplete</shake>. Room 102, Professor Bigfoot.";
            if (GymPass) say "Gym: <item>A+</item>."; else say "Gym: <shake>incomplete</shake>. Coach Whistle, downstairs.";
            if (MathPass && SciencePass && GeoPass && SquatchPass && GymPass) {{
                set Graduated;
                give Diploma;
                give coins 500;
                say "<shake>STRAIGHT A's!</shake> By the power vested in me by this lanyard, you are a <item>graduate of Sasquatch School</item>!";
                say "Your <item>diploma</item>, and <price>500</price> coins from the bake sale fund. Don't tell the bake sale.";
            }} else say "Pass all five and that <item>diploma</item> on my wall has your name on it. Well. It will. I have a pen.";
        }}
    }}
}}
spot Diploma_Wall in "{SP}" at (-3790, 1250) {{
    dialogue {{
        if (Graduated) say "Your diploma hangs between 'HANG IN THERE' and a photo of a pinecone.";
        else say "An empty frame. The label says: <item>RESERVED FOR FIRST GRADUATE</item>.";
    }}
}}
''')

# ================================================================= CAFETERIA   x -6200..-3600, y 807..1807
floor(SC, -6200, 807, 2600, 1000, "E9ECEF", 3)
for k in range(13):
    for j in range(5):
        if (k + j) % 2 == 0:
            floor(SC, -6200 + k * 200, 807 + j * 200, 200, 200, "CED4DA", 4)
door_mat(SC, -4900, 1807, "HALL", up=True, bg="F4A261", fg="1D3557")
sign(SC, -5700, 1892, "CAFETERIA", "F4A261", "1D3557", wd=340, ht=56, front=14)
poster(SC, -4250, 1892, "TODAY: MYSTERY MEAT", "2B2D42", "FFD166", wd=300, ht=40)
poster(SC, -3850, 1892, "TOMORROW: SAME", "2B2D42", wd=220, ht=40)
prop(SC, "Town", "Diner/diner_counter", -5700, 1560)
prop(SC, "Town", "Coffee Shop/Kitchen Counter", -5360, 1680)
prop(SC, "Town", "Coffee Shop/Fridge", -6100, 1650)
for x, y in ((-5700, 1180), (-5100, 1180), (-4500, 1180), (-5700, 960), (-5100, 960), (-4500, 960)):
    prop(SC, "Town", "Diner/SeatsTable_Diner", x, y)
prop(SC, "Stripmall", "VendingMachine", -3720, 1620)
prop(SC, "Stripmall", "TrashCanTown (1)", -3760, 900)
prop(SC, "Stripmall", "TrashCanTown (1)", -6120, 900)
w(f'''
npc Lunch_Lady in "{SC}" at (-5700, 1680) {{ look {{ shirt = #F1FAEE; pants = #A8DADC; }} bubble = false; }}
spot Lunch_Line in "{SC}" at (-5700, 1420) {{
    dialogue {{
        say "<item>LUNCH!</item> Tray up, sweetie. You won't find this food anywhere else. For legal reasons.";
        choice {{
            "Mystery Meat (45)" => {{
                if (coins >= 45) {{ take coins 45; give MysteryMeat; say "One <item>mystery meat</item>. It's a surprise. Mostly to me."; }}
                else say "That's <price>45</price> coins, hon.";
            }}
            "Tater Tots (30)" => {{
                if (coins >= 30) {{ take coins 30; give TaterTots; say "<item>Tater tots</item>! The hamster in 101 would fight you for those."; }}
                else say "Tots are <price>30</price> coins.";
            }}
            "Chocolate Milk (20)" => {{
                if (coins >= 20) {{ take coins 20; give ChocMilkCarton; say "One tiny carton. Good luck opening it."; }}
                else say "Milk's <price>20</price> coins.";
            }}
            "Need any help?" => {{
                if (LunchDelivered) say "You already ran the principal's lunch up. He ate it in the dark, like always.";
                else if (LunchJob) say "The principal's tray is getting cold! His office is off the hall. Top wall, far right.";
                else {{ set LunchJob; give PrincipalLunch; say "Could you run this <item>lunch tray</item> up to <item>Principal Pinecone</item>? He tips. Don't eat it."; }}
            }}
        }}
    }}
}}
npc Bully_Brock in "{SC}" at (-4300, 1420) {{
    look {{ shirt = #6A040F; pants = #03071E; }}
    bubble = true;
    dialogue {{
        if (StoodUpToBully) say "Hey, uh. We're cool, right? Please don't tell Coach Whistle I cried.";
        else if (PaidBully) say "Pleasure doing business. Same time tomorrow, big guy.";
        else {{
            say "Well well. New kid. <shake>Lunch money.</shake> Twenty coins. Now.";
            choice {{
                "Pay him (20)" => {{
                    if (coins >= 20) {{ take coins 20; set PaidBully; say "Smart. Real smart."; }}
                    else say "You're BROKE? Aw, man. Now I feel bad. Go away.";
                }}
                "Stand up straight" => {{
                    set StoodUpToBully;
                    give coins 20;
                    say "You stand up to your full height. It takes a while.";
                    say "...oh. Oh, you're a <shake>big</shake> one. Here. Here's MY lunch money. <price>20</price> coins. We never spoke.";
                }}
                "Run away" => say "Ha! That's what I thought!";
            }}
        }}
    }}
}}
npc Student_Mabel in "{SC}" at (-5100, 1060) {{
    look {{ shirt = #FFCAD4; pants = #9D8189; }}
    dialogue {{ say "I traded my apple for tater tots. Best deal of my life."; }}
}}
npc Student_Finn in "{SC}" at (-4500, 1280) {{
    look {{ shirt = #90BE6D; pants = #277DA1; }}
    dialogue {{ say "My mystery meat blinked. I'm not hungry anymore."; }}
}}
''')

# ================================================================= GYM   x -6400..-3600, y 807..2007
floor(SG, -6400, 807, 2800, 1200, "D9A566", 3)
for k in range(14):                                              # floorboards
    floor(SG, -6400 + k * 200, 807, 4, 1200, "C28E4E", 4)
floor(SG, -6200, 920, 2400, 8, "F8F9FA", 5)                      # court lines
floor(SG, -6200, 1820, 2400, 8, "F8F9FA", 5)
floor(SG, -6200, 920, 8, 908, "F8F9FA", 5)
floor(SG, -3808, 920, 8, 908, "F8F9FA", 5)
floor(SG, -5004, 920, 8, 908, "F8F9FA", 5)
place(SG, CIRCLE, -5000, 1370, "size (300, 300)", "color #E76F51", "front 0")
place(SG, CIRCLE, -5000, 1370, "size (270, 270)", "color #D9A566", "front 0.2")
door_mat(SG, -5000, 2007, "HALL", up=True, bg="457B9D", fg="FFFFFF")
sign(SG, -5900, 2092, "GO SQUATCHES!", "457B9D", "FFD166", wd=360, ht=56, front=14)
sign(SG, -4100, 2092, "HOME 00   GUESTS 00", "0B132B", "8AC926", wd=380, ht=46, front=14)
for x in (-6290, -3710):                                         # hoops
    rect(SG, x, 1470, 14, 200, "F8F9FA", 1)
    rect(SG, x, 1560, 90, 60, "F8F9FA", 1.5)
    rect(SG, x, 1540, 40, 6, "E76F51", 2)
for k in range(3):                                               # bleachers
    rect(SG, -4150, 1930 - k * 26, 760 - k * 60, 22, "6C757D", 1)
CONES = ((-6050, 1700), (-3950, 1700), (-3950, 1040), (-6050, 1040))
for k, (x, y) in enumerate(CONES):
    for col, cond in (("F77F00", f"hideIf Cone{k + 1}"), ("52B788", f"showIf Cone{k + 1}")):
        rect(SG, x, y + 4, 80, 12, col, 1, cond)                 # base
        rect(SG, x, y + 26, 50, 34, col, 1, cond)
        rect(SG, x, y + 54, 30, 26, col, 1, cond)
        rect(SG, x, y + 30, 50, 8, "F8F9FA", 1.5, cond)          # stripe
prop(SG, "Stripmall", "Room Reception/Hospital Bench", -5600, 900)
prop(SG, "Stripmall", "Room Reception/Watercooler", -4300, 900)
w(f'''
npc Coach_Whistle in "{SG}" at (-4650, 1560) {{
    look {{ shirt = #D62828; pants = #F8F9FA; }}
    bubble = true;
    dialogue {{
        if (GymPass) say "That's my star athlete! Biggest feet in the district. A+ in <item>Gym</item>.";
        else if (GymOn && Cone1 && Cone2 && Cone3 && Cone4) {{
            clear GymOn;
            set GymPass;
            give coins 80;
            give GoldStar;
            say "<shake>TWEEEET!</shake> All four cones! You pass <item>Gym</item>! Gold star and <price>80</price> coins. Hit the showers. Please.";
        }}
        else if (GymOn) say "Clock's running! Touch all <item>four cones</item> and get back to me! MOVE MOVE MOVE!";
        else {{
            say "<shake>TWEEET!</shake> I'm <item>Coach Whistle</item>. The <item>cone run</item>: touch all four orange cones, then come back to me. You get 40 seconds.";
            choice {{
                "Start the cone run" => {{
                    clear Cone1; clear Cone2; clear Cone3; clear Cone4;
                    set GymOn;
                    say "On my whistle... <shake>GO!</shake>";
                }}
                "My legs hurt" => say "Your legs are six feet long! Come back when you're ready.";
            }}
        }}
    }}
}}''')
for k, (x, y) in enumerate(CONES):
    w(f'''spot Cone_{k + 1} in "{SG}" at ({x}, {y - 70}) {{
    bubble = false;
    dialogue {{
        if (!GymOn) say "An orange cone. Talk to <item>Coach Whistle</item> to start the cone run.";
        else if (Cone{k + 1}) say "Already got this one. Next cone!";
        else {{ set Cone{k + 1}; say "Cone {k + 1}! <shake>Go go go!</shake>"; }}
    }}
}}''')
w(f'''script Cone_Run in "{SG}" by Coach_Whistle {{
    forever {{
        waitUntil (GymOn);
        speak "GO! Four cones, 40 seconds!";
        wait 20;
        if (GymOn) {{ speak "Twenty seconds left! HUSTLE!"; }}
        wait 20;
        if (GymOn) {{
            clear GymOn;
            clear Cone1;
            clear Cone2;
            clear Cone3;
            clear Cone4;
            speak "TWEET! Time's up! Talk to me to go again.";
        }}
    }}
}}
npc Student_Rex in "{SG}" at (-5600, 1000) {{
    look {{ shirt = #FFFFFF; pants = #D62828; }}
    dialogue {{ say "I've been 'tying my shoe' on this bench for twenty minutes. Coach hasn't noticed."; }}
}}
''')

"""Write ssmodlang/anchors.json: fingerprints (names, not path ids) of the objects SSMod copies from.

Run once against the clean 2.1.9 that SSMod was written on; the ids below are the 2.1.9 ones.
  python3 tools/make_anchors.py
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ssmodlang.unity import load, data_dir  # noqa: E402
from ssmodlang import anchors as A  # noqa: E402

RES, SA0 = "resources.assets", "sharedassets0.assets"
IDS = {   # name: (file, 2.1.9 path id)
    "FLAG_TEMPLATE": (RES, 114225), "DIALOG_TEMPLATE": (RES, 114226),
    "STRINGVAR_TEMPLATE": (RES, 118096), "STRINGDATA_TEMPLATE": (RES, 119274),
    "ITEM_LIBRARY": (RES, 115674), "DEFAULT_ITEM_BASE": (RES, 115404), "LEVEL_LIBRARY": (RES, 118650),
    "TOWNHALL_ELEVATOR": (RES, 118568), "PANEL_6": (RES, 14451),
    "WEATHER_Clear": (RES, 118773), "WEATHER_Rainy": (RES, 118775), "WEATHER_Snowy": (RES, 118777),
    "WEATHER_SnowyHeavy": (RES, 118776),
    "RANDOM_CAMPER_ACTOR": (SA0, 4101), "BEARD_LONG": (SA0, 4157),
    "CAMPER": ("level53", 234), "TALK_GO": ("level8", 130), "BUBBLE_GO": ("level8", 1013),
    "PROP_ACTION_GO": ("level118", 3085), "PROP_DIALOG_GO": ("level118", 5077),
    "PICKUP_GI": ("level13", 3086), "SCRIPT_HOST_GO": ("level10", 15), "SCRIPT_BT": ("level10", 2431),
    "ELEVATOR_GO": ("level123", 344), "ROUTE_GO": ("level118", 1153), "ACTIVATOR_MB": ("level8", 4656),
    "DOOR_GO": ("level16", 99),
}


def scenes():
    import UnityPy
    env = UnityPy.load(os.path.join(data_dir(), "globalgamemanagers"))
    f = list(env.files.values())[0]
    bs = next(o for o in f.objects.values() if o.type.name == "BuildSettings").read_typetree()
    return [os.path.splitext(os.path.basename(p))[0] for p in bs["scenes"]]


def main():
    names = scenes()
    files, trees, out = {}, {}, {}
    for key, (fname, pid) in IDS.items():
        if fname not in files:
            files[fname] = load(fname)
        env, f = files[fname]
        where = {"scene": names[int(fname[5:])]} if fname.startswith("level") else {"file": fname}
        if fname.startswith("level") and fname not in trees:
            trees[fname] = A.Tree(env, f)
        fp = A.fingerprint(env, f, pid, where, trees.get(fname))
        back = A.find(env, f, fp, trees.get(fname))
        assert back == pid, (key, pid, back, fp)          # it must find itself again
        out[key] = fp
        print(f"{key:20} {fname}#{pid}: {fp.get('name') or '/'.join(fp.get('path') or fp['go']['path'])}")
    with open(A.ANCHORS, "w") as fh:
        json.dump(out, fh, indent=1)
    print("wrote", A.ANCHORS)


if __name__ == "__main__":
    main()

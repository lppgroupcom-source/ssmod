"""List every GameObject of a scene with a sprite: name, world position, sprite name, rough size.
usage: python3 tools/objects.py SCENE [filter] [--box x0 y0 x1 y1]"""
import os, sys, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ssmodlang.game import load, Catalog
import preview
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
args = sys.argv[1:]
box = None
if "--box" in args:
    i = args.index("--box"); box = tuple(float(v) for v in args[i + 1:i + 5]); del args[i:i + 5]
scene = args[0]; flt = args[1].lower() if len(args) > 1 else ""
cat = Catalog(os.path.join(HERE, "base"), os.path.join(HERE, "catalog_cache.json"))
level = cat.scene_file(scene, None, None) if not scene.startswith("level") else scene
src = os.path.join(HERE, "base", level)
env, f = load(level, src=src if os.path.exists(src) else None)
O = f.objects
world = {}
def tw(pid):
    if pid in world: return world[pid]
    t = O[pid].read(); m = preview.matrix(t); act = True
    go = O[t.m_GameObject.m_PathID].read(); act = bool(go.m_IsActive)
    path = go.m_Name
    if t.m_Father.m_PathID:
        pm, pa, pp = tw(t.m_Father.m_PathID); m = preview.mul(pm, m); act = act and pa; path = pp + "/" + go.m_Name
    world[pid] = (m, act, path); return world[pid]
rows = []
for p, o in O.items():
    if o.type.name != "SpriteRenderer": continue
    r = o.read(); go = r.m_GameObject.read()
    trp = preview_tr = None
    for c in go.m_Component:
        cp = c.component if hasattr(c, "component") else c
        if cp.m_PathID in O and O[cp.m_PathID].type.name in ("Transform", "RectTransform"): trp = cp.m_PathID
    m, act, path = tw(trp)
    sname = ""
    try:
        sname = r.m_Sprite.deref().read_typetree()["m_Name"] if r.m_Sprite.m_PathID else ""
    except Exception: pass
    x, y = m[4], m[5]
    if box and not (box[0] <= x <= box[2] and box[1] <= y <= box[3]): continue
    line = f"{'  ' if act else 'x '}{path[:70]:70} ({x:7.0f},{y:7.0f}) sc=({m[0]:.2f},{m[3]:.2f}) {sname}"
    if flt and flt not in line.lower(): continue
    rows.append(line)
print("\n".join(rows)); print(len(rows), "rows")

# Airport Part 3 - exec'd by gen_airport.py after gen_part2.py.
#   * a third country: England (a copy of Farm Town), with its own ticket, door in the plane and shops
#   * the Hangar (bottom door of the Runway)
#   * jobs: lost bags, cheese smuggling, the tower's three tasks, the golden wrench, the world traveler stamps
#   * a lot more decoration in the Part 2 rooms
# Same rules as Part 2: top/bottom doors only, rooms keep their right wall at x = -3600, gates are hideIf walls.
PH, PE = "Hangar", "England"

w("// ================================================================ AIRPORT PART 3")
w('''
area Hangar from "TownHall_Floor_B1" named "Hangar 1" {
    room (-6000, 807) to (-3600, 1907);
    door North at (-5200, 1907);                 // back up to the runway
    connect North to "Runway" South;
}
area England from "Farm Town" named "Sasquatchshire, England" {
    close North, NorthAlt, South, East, West;
    door SouthAlt at (600, 1300) facing South;   // the airport doors (back to the plane)
    connect SouthAlt to "Plane_Cabin" NorthAlt;
}
''')
w(f'hide "townhall_dailychallenge_board" in "{PH}";')
w(f'hide "sign" in "{PH}";')


def pillar(scene, x, y):
    rect(scene, x, y + 80, 56, 160, "B8BEC6", 1)
    rect(scene, x, y + 166, 70, 14, "8D949C", 1.2)
    rect(scene, x, y + 4, 70, 14, "8D949C", 1.2)


def screen(scene, x, y, words, wd=300, front=2):
    rect(scene, x, y, wd + 12, 52, "2B2D42", front)
    rect(scene, x, y, wd, 40, "0B132B", front + 0.5)
    text(scene, x, y - 4, words, "8AC926", sx=wd / 150 * 0.9, sy=0.7, front=front + 1)


def bag(scene, x, y, col, flag):
    """A tagged suitcase that disappears once it's found."""
    rect(scene, x, y, 78, 56, col, 1, f"hideIf {flag}")
    rect(scene, x, y + 32, 28, 10, "2B2D42", 1.2, f"hideIf {flag}")
    rect(scene, x + 30, y + 10, 20, 26, "F1FAEE", 1.4, f"hideIf {flag}")


def drum(scene, x, y, col):
    place(scene, CIRCLE, x, y, "size (56, 44)", f"color #{col}", "front 1")
    place(scene, CIRCLE, x, y + 6, "size (38, 26)", "color #1B1C1F", "front 1.5")


# ================================================================= JOBS
w('''
// ---------------------------------------------------------------- the three lost bags
spot Red_Suitcase in "Airport_Terminal" at (-4560, 1770) {
    dialogue {
        if (BagA) say "Just an empty bit of carpet now.";
        else if (BagJob) { set BagA; say "The <item>red suitcase</item>! The tag says 'PROPERTY OF THE HANDLER'S NAN'. One found."; }
        else say "A red suitcase with a big tag. Somebody downstairs in <item>Baggage Claim</item> is probably looking for it.";
    }
}
spot Blue_Suitcase in "Runway" at (-4560, 1640) {
    dialogue {
        if (BagB) say "Just tarmac.";
        else if (BagJob) { set BagB; say "The <item>blue suitcase</item>! It fell off a baggage cart. Somehow it's still ticking. One found."; }
        else say "A blue suitcase, alone on the runway. The baggage handler would want to know.";
    }
}
spot Green_Suitcase in "Hangar" at (-5750, 950) {
    dialogue {
        if (BagC) say "Just an oil stain.";
        else if (BagJob) { set BagC; say "The <item>green suitcase</item>! Someone used it as a step stool. One found."; }
        else say "A green suitcase with a boot print on it.";
    }
}

// ---------------------------------------------------------------- the airport manager lists the jobs
npc Airport_Manager in "Airport_Terminal" at (-4930, 1010) {
    look { shirt = #14213D; pants = #14213D; }
    bubble = true;
    dialogue {
        say "I'm the <item>Airport Manager</item>. We are, as always, short-staffed. Fancy helping out?";
        if (BagJobDone) say "Lost bags: <item>done</item>."; else say "Lost bags: ask the handler in <item>Baggage Claim</item>.";
        if (CheeseDone) say "A certain cheese: <item>delivered</item>. I know nothing."; else say "A nervous man in <item>Customs</item> needs a favour. I know nothing.";
        if (TowerChainDone) say "Control tower: <item>done</item>."; else say "The <item>Control Tower</item> needs a hand: runway, top-left door.";
        if (WrenchDone) say "Hangar: <item>done</item>."; else say "The mechanic in the <item>Hangar</item> lost something: runway, bottom door.";
        if (StampsDone) say "World traveler: <item>done</item>."; else say "And the stamp collector in <item>Customs</item> wants stories from all three countries.";
        say "Everything downstairs is through the yellow <item>BAGGAGE CLAIM</item> door by the cafe.";
    }
}

// ---------------------------------------------------------------- world traveler stamps
npc Stamp_Collector in "Customs" at (-6150, 1010) {
    look { shirt = #7B2CBF; pants = #3C096C; }
    bubble = true;
    dialogue {
        if (StampsDone) { say "Switzerland, Mexico AND England. You've seen more of the world than I have, and I work at an airport."; end; }
        if (MetGuideCH && MetGuideMX && MetGuideUK) {
            set StampsDone;
            give coins 300;
            give WorldMap;
            say "You met the guides in <item>all three countries</item>! Tell me everything. Slowly.";
            say "Here's <price>300</price> coins and my <item>World Traveler Map</item>. You've earned it.";
            end;
        }
        say "I collect stories from every country this airport flies to. Say hello to the <item>guide</item> in each one.";
        if (MetGuideCH) say "Switzerland: done."; else say "Switzerland: not yet.";
        if (MetGuideMX) say "Mexico: done."; else say "Mexico: not yet.";
        if (MetGuideUK) say "England: done."; else say "England: not yet.";
    }
}

// ---------------------------------------------------------------- the tower's other two tasks
spot Microphone in "Control_Tower" at (-4300, 1560) {
    dialogue {
        say "The airport's <item>PA microphone</item>. It's on. Everybody can hear you breathing.";
        choice {
            "Flight 101 is delayed. Forever." => { set PADone; say "A hundred people downstairs groan at once."; }
            "Free poutine at Gate 1!" => { set PADone; say "You hear a stampede."; }
            "This is your sasquatch speaking" => { set PADone; say "Somewhere, a tourist faints."; }
            "Say nothing" => say "You breathe into it a bit more and leave.";
        }
    }
}
spot Runway_Light_Switch in "Runway" at (-6510, 900) {
    dialogue {
        if (RunwayLights) { say "The runway lights are on. It looks like a very long birthday cake."; end; }
        say "A big switch labelled <item>RUNWAY LIGHTS</item>.";
        choice {
            "Flip it" => { set RunwayLights; say "<shake>CLUNK.</shake> Lights blink on all the way down the runway."; }
            "Leave it" => say "You leave it. The pilots squint.";
        }
    }
}

// ---------------------------------------------------------------- the golden wrench
spot Lost_Luggage_Pile in "Baggage_Claim" at (-6010, 1340) {
    dialogue {
        if (WrenchJob && !WrenchDone && !has(GoldenWrench)) {
            give GoldenWrench;
            say "You dig through the lost luggage. Socks. More socks. And... a <item>Golden Wrench</item>!";
        } else {
            say "A pile of lost luggage. It smells like forty different airports.";
        }
    }
}
''')

# the bags themselves
bag("Airport_Terminal", -4560, 1850, "B03A2E", "BagA")
bag("Runway", -4560, 1710, "2E5C9E", "BagB")
bag(PH, -5750, 1010, "2E7D4F", "BagC")
# the microphone and the light switch
rect(PT, -4300, 1650, 8, 70, "6C757D", 1)
place(PT, CIRCLE, -4300, 1690, "size (26, 26)", "color #2B2D42", "front 1.5")
rect(PT, -4300, 1612, 60, 10, "6C757D", 1)
rect(PR, -6510, 990, 60, 80, "8D949C", 1)
rect(PR, -6510, 1006, 22, 22, "E63946", 1.5, "hideIf RunwayLights")
rect(PR, -6510, 1006, 22, 22, "39FF14", 1.5, "showIf RunwayLights")
for i in range(8):                                                    # runway edge lights (on after the switch)
    for y in (880, 1360):
        place(PR, CIRCLE, -6300 + i * 360, y, "size (22, 22)", "color #FFE066", "front 2", "showIf RunwayLights")

# ================================================================= HANGAR   x -6000..-3600, y 807..1907
floor(PH, -6000, 807, 2400, 1100, "7A7F87", 3)
for i in range(12):                                                   # hazard stripes along the bottom
    floor(PH, -6000 + i * 200, 807, 100, 46, "FFD166", 4)
    floor(PH, -5900 + i * 200, 807, 100, 46, "2B2D42", 4)
floor(PH, -5400, 1050, 1700, 620, "6A6F77", 4)                       # the repair bay
sign(PH, -4500, 1992, "SASQUATCH AIR MAINTENANCE", "1D4E89", "FFFFFF", wd=620, ht=60, front=14)
door_mat(PH, -5200, 1907, "RUNWAY", up=True)
jet(PH, -4550, 1350, "FF8C00")
rect(PH, -4950, 1590, 14, 240, "ADB5BD", 3)                           # scaffolding by the tail
rect(PH, -4820, 1590, 14, 240, "ADB5BD", 3)
rect(PH, -4885, 1700, 150, 12, "ADB5BD", 3.2)
rect(PH, -4885, 1620, 150, 12, "ADB5BD", 3.2)
for x, y in ((-5850, 1450), (-5850, 1560), (-5740, 1500)):           # tyres
    place(PH, CIRCLE, x, y, "size (84, 84)", "color #1B1C1F", "front 1")
    place(PH, CIRCLE, x, y, "size (40, 40)", "color #6C757D", "front 1.5")
for x, col in ((-3760, "2E5C9E"), (-3690, "2E5C9E"), (-3725, "B03A2E")):
    drum(PH, x, 1750 if col != "B03A2E" else 1700, col)
for x in (-5650, -5480):                                              # tool chests
    rect(PH, x, 1760, 130, 110, "B03A2E", 1)
    for k in range(3):
        rect(PH, x, 1730 + k * 30, 116, 6, "6D1F1F", 1.5)
prop(PH, "Town", "Coffee Shop/Kitchen Counter", -4100, 1800)
rect(PH, -3900, 1090, 150, 110, "495057", 1)                          # a spare engine on a stand
place(PH, CIRCLE, -3900, 1100, "size (110, 80)", "color #212529", "front 1.5")
rect(PH, -3900, 1030, 180, 14, "FFD166", 1.2)
w('''
npc Mechanic in "Hangar" at (-5250, 1350) {
    look { shirt = #3A5A40; pants = #344E41; }
    bubble = true;
    dialogue {
        if (WrenchDone) { say "She flies like a dream now. A loud, shaky dream."; end; }
        if (has(GoldenWrench)) {
            take GoldenWrench;
            set WrenchDone;
            give coins 200;
            say "My <item>Golden Wrench</item>! I've had it since flight school. I failed flight school.";
            say "Here's <price>200</price> coins. This jet will be flying again by Tuesday. Or Thursday.";
            end;
        }
        if (!WrenchJob) {
            set WrenchJob;
            say "Can't fix this jet. Lost my lucky <item>Golden Wrench</item>.";
            say "Last time I saw it, I was checking a bag. Might be in the <item>lost luggage pile</item> in Baggage Claim.";
        } else {
            say "Any luck? Try the <item>lost luggage pile</item> in Baggage Claim, top-left corner.";
        }
    }
}
npc Apprentice in "Hangar" at (-4100, 1680) {
    look { shirt = #3A5A40; pants = #344E41; }
    dialogue { say "I put the engine back on upside down once. It flew better. Nobody knows why."; }
}
''')

# ================================================================= ENGLAND (a copy of Farm Town)
EX, EY = 600, 1300
floor(PE, EX - 300, EY - 40, 600, 360, "CED4DA", 3)
rect(PE, EX - 140, EY + 90, 20, 180, "6C757D", 1)                     # the airport doors' frame
rect(PE, EX + 140, EY + 90, 20, 180, "6C757D", 1)
rect(PE, EX, EY + 185, 300, 22, "6C757D", 1.2)
sign(PE, EX, EY + 400, "SASQUATCHSHIRE AIRPORT", "012169", "FFFFFF", wd=440, ht=60, front=3)
FX, FY = EX - 310, EY + 400                                           # the flag
rect(PE, FX, FY, 96, 60, "012169", 3)
place(PE, RECT, FX, FY, "size (112, 10)", "color #FFFFFF", "rotate 32", "front 3.2")
place(PE, RECT, FX, FY, "size (112, 10)", "color #FFFFFF", "rotate -32", "front 3.2")
rect(PE, FX, FY, 96, 18, "FFFFFF", 3.4)
rect(PE, FX, FY, 18, 60, "FFFFFF", 3.4)
rect(PE, FX, FY, 96, 9, "C8102E", 3.6)
rect(PE, FX, FY, 9, 60, "C8102E", 3.6)
prop(PE, "Town", "Coffee Shop/Front Counter", EX + 450, EY + 200)
sign(PE, EX + 450, EY + 360, "FISH & CHIPS", "C8102E", "FFFFFF", wd=260, ht=46, front=3)
prop(PE, "Town", "Town Hall/townhall_counter", EX - 470, EY + 260)
sign(PE, EX - 470, EY + 420, "RETURN FLIGHTS", "012169", "FFFFFF", wd=260, ht=46, front=3)
rect(PE, EX + 230, EY + 110, 60, 170, "C8102E", 1)                    # a red phone box
rect(PE, EX + 230, EY + 130, 40, 100, "A8DADC", 1.5)
rect(PE, EX + 230, EY + 200, 66, 14, "8E0B21", 1.6)
w(f'''
npc England_Guide in "{PE}" at ({EX - 110}, {EY + 300}) {{
    look {{ shirt = #012169; pants = #C8102E; }}
    bubble = true;
    dialogue {{
        if (!MetGuideUK) {{ set MetGuideUK; say "Good afternoon and welcome to <item>Sasquatchshire, England</item>! Lovely weather. For ducks."; }}
        say "We have fields, a village, and the finest <item>fish and chips</item> on Earth. You can only get them here.";
        say "To go home, buy a ticket at the <item>Return Flights</item> desk and walk back through the airport doors.";
    }}
}}
npc Royal_Guard in "{PE}" at ({EX - 220}, {EY + 60}) {{
    look {{ shirt = #C8102E; pants = #1B1B1B; }}
    dialogue {{
        say "...";
        say "He is not allowed to talk. Or move. You respect that.";
        choice {{
            "Pull a funny face" => say "His eye twitches. <shake>Victory.</shake>";
            "Salute" => say "Nothing. But you feel he appreciated it.";
            "Leave him alone" => say "...";
        }}
    }}
}}
npc Chippy in "{PE}" at ({EX + 450}, {EY + 290}) {{ look {{ shirt = #FFFFFF; pants = #012169; }} bubble = false; }}
spot Fish_And_Chips in "{PE}" at ({EX + 450}, {EY + 110}) {{
    dialogue {{
        say "<item>The Codfather</item>. Best chippy in Sasquatchshire. Only in England, love.";
        choice {{
            "Fish and Chips (60)" => {{ if (coins >= 60) {{ take coins 60; give FishChips; say "Salt and vinegar? Course you do."; }} else say "That's <price>60</price> coins, love."; }}
            "A Proper Cup of Tea (35)" => {{ if (coins >= 35) {{ take coins 35; give ProperTea; say "That'll sort you right out."; }} else say "That's <price>35</price> coins."; }}
            "Scone (40)" => {{ if (coins >= 40) {{ take coins 40; give Scone; say "Jam first. Don't let anyone tell you different."; }} else say "That's <price>40</price> coins."; }}
            "Nothing" => say "Ta-ra then!";
        }}
    }}
}}
npc England_Agent in "{PE}" at ({EX - 470}, {EY + 350}) {{ look {{ shirt = #012169; pants = #1B1B1B; }} bubble = false; }}
spot England_Return_Desk in "{PE}" at ({EX - 470}, {EY + 170}) {{
    dialogue {{
        if (has(TicketHome)) {{ say "You have your ticket home. Walk through the airport doors to board!"; end; }}
        choice "Need a flight home?" {{
            "Flight home to Canada (200)" => {{
                if (coins >= 200) {{ take coins 200; give TicketHome; say "Flight 303 to Canada. Mind the gap!"; }}
                else say "A ticket home is <price>200</price> coins.";
            }}
            "I can't afford it..." => {{
                say "Oh dear. The embassy keeps an <item>emergency ticket</item> for stranded sasquatches.";
                give TicketHome;
                say "There you are. Terribly sorry about the weather.";
            }}
            "Not yet" => say "Do enjoy the drizzle!";
        }}
    }}
}}
''')

# ================================================================= MORE DECORATION
# ---- baggage claim
for x in (-5900, -5000, -4100):
    floor(PB, x - 60, 847, 120, 760, "959AA3", 4)                    # lighter floor bands
for x, y in ((-5750, 1420), (-4750, 1420), (-5750, 960), (-3760, 1400)):
    pillar(PB, x, y)
screen(PB, -5450, 1500, "BELT 1   101 ZURICH", 300)
screen(PB, -4450, 1260, "BELT 2   202 CANCUN", 300)
prop(PB, "Stripmall", "Room Reception/Desk", -3900, 870)
sign(PB, -3900, 1010, "CAR RENTAL", "F77F00", "FFFFFF", wd=200, ht=36, front=2)
prop(PB, "Town", "Bank/ATM Machine", -3700, 1480)
sign(PB, -3700, 1570, "CASH", "2E7D4F", "FFFFFF", wd=100, ht=30, front=2)
w('''
npc Rental_Agent in "Baggage_Claim" at (-4070, 900) {
    look { shirt = #F77F00; pants = #2B2D42; }
    dialogue { say "Car rental! We have one car. It's a golf cart. It's taken."; say "It's always taken."; }
}
npc Pacing_Passenger in "Baggage_Claim" at (-5300, 1130) {
    look { shirt = #457B9D; pants = #1D3557; }
    dialogue { say "Forty minutes. FORTY. It's one bag!"; }
    patrol { (-5300, 1130); wait 2; (-4900, 1130); wait 2; }
}
''')
# ---- customs
floor(PC, -5450, 1257, 290, 550, "2E7D4F", 4)                        # green lane / red lane up to the gate
floor(PC, -4840, 1257, 290, 550, "B03A2E", 4)
text(PC, -5305, 1640, "NOTHING TO DECLARE", "FFFFFF", sx=1.7, sy=0.8, front=1)
text(PC, -4695, 1640, "GOODS TO DECLARE", "FFFFFF", sx=1.7, sy=0.8, front=1)
prop(PC, "Town", "Grocery Store/Register 1", -6000, 1300)             # an x-ray belt
sign(PC, -6020, 1560, "X-RAY", "1D3557", "FFFFFF", wd=140, ht=36, front=2)
for x in (-6400, -5900, -4200, -3800):
    pillar(PC, x, 1650)
screen(PC, -4250, 1130, "WELCOME TO CANADA, EH", 320)
prop(PC, "Stripmall", "Room Reception/Hospital Bench", -6300, 900)
# ---- VIP lounge
prop(PV, "Town", "Bank/bank bookshelf", -4950, 1480)
prop(PV, "Town", "Bank/bank bookshelf", -4840, 1480)
rect(PV, -4250, 1470, 230, 120, "1D3557", 1)                          # an aquarium
rect(PV, -4250, 1476, 210, 96, "48CAE4", 1.5)
for dx, dy, col in ((-60, 10, "FF8C00"), (20, -14, "FFD166"), (60, 20, "E63946")):
    place(PV, CIRCLE, -4250 + dx, 1476 + dy, "size (26, 14)", f"color #{col}", "front 2")
rect(PV, -4600, 1150, 250, 130, "5C3D2E", 1)                          # a pool table on the rug
rect(PV, -4600, 1156, 222, 100, "2E7D4F", 1.5)
for dx, dy, col in ((-50, 10, "F1FAEE"), (30, -10, "E63946"), (60, 20, "FFD166"), (10, 24, "1D3557")):
    place(PV, CIRCLE, -4600 + dx, 1156 + dy, "size (16, 16)", f"color #{col}", "front 2")
floor(PV, -5600, 1577, 2000, 30, "B8860B", 4)
w('''
npc Waiter in "VIP_Lounge" at (-4900, 1250) {
    look { shirt = #F1FAEE; pants = #14213D; }
    dialogue { say "Sparkling water? Still water? Water that has merely been near a lemon?"; }
    patrol { (-4900, 1250); wait 3; (-4200, 900); wait 3; (-5300, 1150); wait 3; }
}
''')
# ---- runway
for i in range(6):                                                    # cones along the apron line
    place(PR, TRI, -6050 + i * 150, 1420, "size (30, 36)", "color #FF8C00", "front 1")
rect(PR, -3780, 1250, 200, 90, "E9C46A", 1)                           # a fuel truck
rect(PR, -3700, 1250, 70, 70, "F1FAEE", 1.5)
rect(PR, -3840, 1256, 90, 10, "2B2D42", 1.6)
for dx in (-70, 60):
    place(PR, CIRCLE, -3780 + dx, 1202, "size (36, 30)", "color #1B1C1F", "front 2")
rect(PR, -6520, 1700, 10, 200, "ADB5BD", 1)                           # a windsock
place(PR, TRI, -6480, 1790, "size (70, 36)", "color #FF8C00", "rotate -90", "front 1.5")
# ---- control tower
for x in (-4530, -3830):
    prop(PT, "Town", "PoliceStation/ChairBlue_Up", x, 1770)
prop(PT, "Town", "Coffee Shop/Kitchen Counter", -4780, 1300)
screen(PT, -4300, 2060, "ALL RUNWAYS: MOSTLY FINE", 420)
rect(PT, -3760, 1300, 160, 120, "1D3557", 1)                          # a wall map
rect(PT, -3760, 1300, 140, 100, "8ECAE6", 1.5)
for dx, dy in ((-30, 10), (20, -16), (36, 22)):
    rect(PT, -3760 + dx, 1300 + dy, 30, 20, "2E7D4F", 2)
w("")

"""Show or change the version the installed game reports.

    python3 tools/gameversion.py show
    python3 tools/gameversion.py set 2.2
    python3 tools/gameversion.py reset        # back to the real version, 2.1.9

The chosen version is remembered in SSMod/version_override.txt, and ./ssmod install re-applies it
after it writes its files, so an install never silently puts the version back.
"""
import os
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)
from ssmodlang.appversion import read_version, set_version  # noqa: E402

from ssmodlang.config import game_data  # noqa: E402

HC = game_data()
OVERRIDE = os.path.join(HERE, "version_override.txt")
REAL = "2.1.9"


def main():
    args = sys.argv[1:]
    cmd = args[0] if args else "show"
    if cmd == "show":
        over = open(OVERRIDE).read().strip() if os.path.exists(OVERRIDE) else None
        print(f"installed game reports: {read_version(HC)}   (real build: {REAL})")
        print(f"override file: {over or 'none'}")
        return 0
    if cmd in ("set", "reset"):
        version = REAL if cmd == "reset" else (args[1] if len(args) > 1 else "")
        if not version:
            sys.exit("usage: gameversion.py set <version>")
        old = set_version(HC, version)
        if cmd == "reset":
            if os.path.exists(OVERRIDE):
                os.remove(OVERRIDE)
        else:
            with open(OVERRIDE, "w") as fh:
                fh.write(version + "\n")
        print(f"version: {old or version} -> {version}")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())

"""Render a rough top-down picture of a scene (sprites + flat-shaded meshes) so builds can be checked by eye.

usage: python3 tools/preview.py SCENE [out.png] [--box x0 y0 x1 y1] [--scale 0.25] [--installed] [--grid 200]

Coordinates are the game's world coordinates (the ones .ssmod uses). A grid with labels is drawn on top.
--installed renders the Hidden Content file (with mods) instead of the clean game.
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ssmodlang.game import load, Catalog  # noqa: E402
from PIL import Image, ImageDraw, ImageFont  # noqa: E402

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
from ssmodlang.config import game_data  # noqa: E402

HC = game_data()

_sprite_cache = {}


def matrix(t):
    """2D affine (a, b, c, d, tx, ty) of a Transform's local TRS (z rotation only)."""
    q = t.m_LocalRotation
    ang = 2 * math.atan2(q.z, q.w)
    s = t.m_LocalScale
    ca, sa = math.cos(ang), math.sin(ang)
    return (ca * s.x, sa * s.x, -sa * s.y, ca * s.y, t.m_LocalPosition.x, t.m_LocalPosition.y)


def mul(p, c):
    a1, b1, c1, d1, x1, y1 = p
    a2, b2, c2, d2, x2, y2 = c
    return (a1 * a2 + c1 * b2, b1 * a2 + d1 * b2, a1 * c2 + c1 * d2, b1 * c2 + d1 * d2,
            a1 * x2 + c1 * y2 + x1, b1 * x2 + d1 * y2 + y1)


def apply(m, x, y):
    a, b, c, d, tx, ty = m
    return a * x + c * y + tx, b * x + d * y + ty


def render(level_path_or_name, out, box=None, scale=0.25, grid=200, src=None):
    env, f = load(level_path_or_name, src=src)
    O = f.objects
    world, active, zpos = {}, {}, {}

    def tr_world(pid):
        if pid in world:
            return world[pid]
        t = O[pid].read()
        m = matrix(t)
        z = t.m_LocalPosition.z
        go = O[t.m_GameObject.m_PathID].read()
        act = bool(go.m_IsActive)
        if t.m_Father.m_PathID:
            pm, pa, pz = tr_world(t.m_Father.m_PathID)
            m, act, z = mul(pm, m), act and pa, z + pz
        so = sortable_offset(go, O)
        if so is not None:                 # SortableObject: the game sets z from y at runtime
            z = 374.0 + 0.1 * m[5] + so
        world[pid] = (m, act, z)
        return world[pid]

    def go_tr(go):
        for c in go.m_Component:
            p = c.component if hasattr(c, "component") else c
            if p.m_PathID in O and O[p.m_PathID].type.name in ("Transform", "RectTransform"):
                return p.m_PathID

    draws = []
    for pid, o in O.items():
        tn = o.type.name
        if tn not in ("SpriteRenderer", "MeshRenderer"):
            continue
        try:
            r = o.read()
        except Exception:
            continue
        if not r.m_Enabled:
            continue
        go = r.m_GameObject.read()
        trp = go_tr(go)
        if trp is None:
            continue
        m, act, z = tr_world(trp)
        if not act or not go.m_IsActive:
            continue
        mname, mcol = mat_info(r)
        if "SDF" in mname and tn == "MeshRenderer":
            tmp = tmp_text(go, O)
            if tmp:
                order = (r.m_SortingLayer if hasattr(r, "m_SortingLayer") else 0, r.m_SortingOrder + 1000)
                draws.append((order, -z, "Text", tmp, m, go, mname, mcol))
            continue
        if any(k in mname for k in ("Additive", "DepthMask", "Light")):
            continue
        order = (r.m_SortingLayer if hasattr(r, "m_SortingLayer") else 0, r.m_SortingOrder)
        if tn == "MeshRenderer" and any(k in mname for k in ("Terrain", "Water", "Ground")):
            order = (-1000, 0)
        wbl = bg_delta(go, O)
        if wbl is not None:                # floors: the game puts them at z 752 - delta, behind everything
            order = (-500, wbl, r.m_SortingOrder)
            z = 752 - wbl
        draws.append((order, -z, tn, r, m, go, mname, mcol))

    # world bounds
    pts = [(d[4][4], d[4][5]) for d in draws]
    if box is None:
        xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        box = (min(xs) - 200, min(ys) - 200, max(xs) + 200, max(ys) + 200)
    x0, y0, x1, y1 = box
    W, H = int((x1 - x0) * scale), int((y1 - y0) * scale)
    img = Image.new("RGBA", (W, H), (40, 40, 48, 255))

    def to_px(x, y):
        return (x - x0) * scale, (y1 - y) * scale

    # floors/terrain first; then like the game's depth buffer: far to near (sorting order only breaks ties)
    draws.sort(key=lambda d: ((0, d[0]) if d[0][0] in (-1000, -500) else (1, ())) + (d[1], d[0]))
    for order, nz, tn, r, m, go, mname, mcol in draws:
        if tn == "SpriteRenderer":
            draw_sprite(img, r, m, to_px, scale)
        elif tn == "Text":
            draw_text(img, r, m, to_px, scale)
        else:
            if "Shadow" in mname:
                mcol = (0, 0, 0, 70)
            draw_mesh(img, r, m, go, O, to_px, mcol)
    d = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 11)
    except Exception:
        font = None
    if grid:
        gx = math.ceil(x0 / grid) * grid
        while gx < x1:
            px, _ = to_px(gx, 0)
            d.line([(px, 0), (px, H)], fill=(255, 255, 255, 60))
            d.text((px + 2, 2), str(int(gx)), fill=(255, 255, 0, 255), font=font)
            gx += grid
        gy = math.ceil(y0 / grid) * grid
        while gy < y1:
            _, py = to_px(0, gy)
            d.line([(0, py), (W, py)], fill=(255, 255, 255, 60))
            d.text((2, py + 2), str(int(gy)), fill=(255, 255, 0, 255), font=font)
            gy += grid
    img.convert("RGB").save(out)
    return box


def parse_vd(vd, index_bytes, index_fmt=0):
    """(positions [(x, y)], colors [(r, g, b, a)] or None, indices) from a VertexData typetree dict."""
    import struct
    n = vd["m_VertexCount"]
    data = bytes(vd["m_DataSize"])
    ch = vd["m_Channels"]
    sizes = {0: 4, 1: 2, 2: 1, 3: 1, 4: 2, 5: 2, 6: 1, 7: 1, 8: 2, 9: 2, 10: 4, 11: 4}
    strides = {}
    for c in ch:
        if c["dimension"]:
            strides[c["stream"]] = max(strides.get(c["stream"], 0), c["offset"] + sizes[c["format"]] * (c["dimension"] & 0xF))
    starts, off = {}, 0
    for s in sorted(strides):
        starts[s] = off
        off += strides[s] * n
        off = (off + 15) & ~15
    pos = ch[0]
    ps, pst = starts[pos["stream"]] + pos["offset"], strides[pos["stream"]]
    verts = [struct.unpack_from("<2f", data, ps + i * pst) for i in range(n)]
    cols = None
    c = ch[3]
    if c["dimension"] and c["format"] == 2:
        cs, cst = starts[c["stream"]] + c["offset"], strides[c["stream"]]
        cols = [tuple(data[cs + i * cst: cs + i * cst + 4]) for i in range(n)]
    ib = bytes(index_bytes)
    if index_fmt == 0:
        idx = list(struct.unpack_from(f"<{len(ib) // 2}H", ib))
    else:
        idx = list(struct.unpack_from(f"<{len(ib) // 4}I", ib))
    return verts, cols, idx


def sprite_data(sp_ptr):
    try:
        obj = sp_ptr.deref()
    except Exception:
        return None
    key = (id(obj.assets_file), obj.path_id)
    if key in _sprite_cache:
        return _sprite_cache[key]
    res = None
    try:
        t = obj.read_typetree()
        rd = t["m_RD"]
        if (rd["texture"]["m_PathID"] == 0 or t["m_Name"].startswith("ssmod mesh")) and rd["m_VertexData"]["m_VertexCount"]:
            res = ("mesh",) + parse_vd(rd["m_VertexData"], rd["m_IndexBuffer"])
        else:
            sp = obj.read()
            res = ("image", sp.image, sp.m_PixelsToUnits, (sp.m_Pivot.x, sp.m_Pivot.y))
    except Exception:
        res = None
    _sprite_cache[key] = res
    return res


def draw_tris(img, verts, cols, idx, m, to_px, tint=(1, 1, 1, 1), flat=None):
    d = ImageDraw.Draw(img, "RGBA")
    pts = [to_px(*apply(m, x, y)) for x, y in verts]
    for k in range(0, len(idx) - 2, 3):
        a, b, c = idx[k], idx[k + 1], idx[k + 2]
        if cols is not None:
            cr = cols[a]
        else:
            cr = flat or (200, 200, 200, 255)
        col = (int(cr[0] * tint[0]), int(cr[1] * tint[1]), int(cr[2] * tint[2]), int(cr[3] * tint[3]))
        if col[3] < 4:
            continue
        d.polygon([pts[a], pts[b], pts[c]], fill=col)


def draw_sprite(img, r, m, to_px, scale):
    if not r.m_Sprite or not r.m_Sprite.m_PathID:
        return
    sd = sprite_data(r.m_Sprite)
    if not sd:
        return
    col = r.m_Color
    tint = (col.r, col.g, col.b, col.a)
    if "Shadow" in mat_info(r)[0]:
        tint = (0, 0, 0, 0.3)
    if getattr(r, "m_FlipX", False) or getattr(r, "m_FlipY", False):
        fx = -1 if getattr(r, "m_FlipX", False) else 1
        fy = -1 if getattr(r, "m_FlipY", False) else 1
        m = mul(m, (fx, 0, 0, fy, 0, 0))
    if sd[0] == "mesh":
        _, verts, cols, idx = sd
        draw_tris(img, verts, cols, idx, m, to_px, tint, flat=(255, 255, 255, 255))   # no vertex colours = white
        return
    _, im, ppu, (pvx, pvy) = sd
    w, h = im.size
    wu, hu = w / ppu, h / ppu
    lx0, ly0 = -pvx * wu, -pvy * hu
    corners = [apply(m, lx0, ly0), apply(m, lx0 + wu, ly0), apply(m, lx0 + wu, ly0 + hu), apply(m, lx0, ly0 + hu)]
    pxs = [to_px(*c) for c in corners]
    minx, maxx = min(p[0] for p in pxs), max(p[0] for p in pxs)
    miny, maxy = min(p[1] for p in pxs), max(p[1] for p in pxs)
    tw, th = int(round(maxx - minx)), int(round(maxy - miny))
    if tw < 1 or th < 1 or tw > 6000 or th > 6000:
        return
    if maxx < 0 or maxy < 0 or minx > img.size[0] or miny > img.size[1]:
        return
    src = im.convert("RGBA")
    if m[0] < 0:
        src = src.transpose(Image.FLIP_LEFT_RIGHT)
    if m[3] < 0:
        src = src.transpose(Image.FLIP_TOP_BOTTOM)
    src = src.resize((tw, th), Image.BILINEAR)
    if tint != (1, 1, 1, 1):
        bands = src.split()
        src = Image.merge("RGBA", [b.point(lambda v, t=t: int(v * t)) for b, t in zip(bands, tint)])
    paste_clip(img, src, int(round(minx)), int(round(miny)))


def paste_clip(img, src, x, y):
    cx, cy = max(0, -x), max(0, -y)
    src = src.crop((cx, cy, src.size[0], src.size[1]))
    if src.size[0] < 1 or src.size[1] < 1:
        return
    img.alpha_composite(src, (x + cx, y + cy))


_mesh_cache = {}


_mat_cache = {}
_wbl_cache = {}


def sortable_offset(go, O):
    from ssmodlang.game import script_name
    for c in go.m_Component:
        p = c.component if hasattr(c, "component") else c
        o = O.get(p.m_PathID)
        if o is None or o.type.name != "MonoBehaviour":
            continue
        try:
            t = o.read_typetree()
        except Exception:
            continue
        if "hasContainer" in t and "offset" in t:
            return t["offset"]
    return None


def bg_delta(go, O):
    """layerConfigDelta if this GameObject has a WorldBackgroundLayer (a floor), else None."""
    from ssmodlang.game import script_name
    key = id(go)
    for c in go.m_Component:
        p = c.component if hasattr(c, "component") else c
        o = O.get(p.m_PathID)
        if o is None or o.type.name != "MonoBehaviour":
            continue
        if p.m_PathID in _wbl_cache:
            if _wbl_cache[p.m_PathID] is not None:
                return _wbl_cache[p.m_PathID]
            continue
        try:
            t = o.read_typetree()
        except Exception:
            _wbl_cache[p.m_PathID] = None
            continue
        v = t.get("layerConfigDelta") if "layerConfig" in t else None
        _wbl_cache[p.m_PathID] = v
        if v is not None:
            return v
    return None


def tmp_text(go, O):
    """(text, font size, rgba, rect w, rect h) of a TextMeshPro on this GameObject."""
    from ssmodlang.game import script_name
    rect = (100.0, 30.0)
    for c in go.m_Component:
        p = c.component if hasattr(c, "component") else c
        o = O.get(p.m_PathID)
        if o is None:
            continue
        if o.type.name == "RectTransform":
            t = o.read_typetree()
            rect = (t["m_SizeDelta"]["x"], t["m_SizeDelta"]["y"])
        if o.type.name == "MonoBehaviour":
            try:
                t = o.read_typetree()
            except Exception:
                continue
            if "m_text" in t:
                fc = t.get("m_fontColor", {"r": 1, "g": 1, "b": 1, "a": 1})
                col = tuple(int(fc[k] * 255) for k in ("r", "g", "b", "a"))
                import re
                txt = re.sub(r"<[^>]+>", " ", t["m_text"]).strip()
                return (txt, t.get("m_fontSize", 20), col, rect)
    return None


def draw_text(img, tmp, m, to_px, scale):
    txt, size, col, (rw, rh) = tmp
    if not txt:
        return
    d = ImageDraw.Draw(img)
    px = max(6, int(size * abs(m[3]) * scale))
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", px)
    except Exception:
        font = None
    x, y = to_px(m[4], m[5])
    w = d.textlength(txt, font=font)
    d.text((x - w / 2, y - px / 2), txt, fill=col, font=font)


def mat_info(r):
    """(material name, flat colour from its _Color) of a renderer's first material."""
    try:
        mp = r.m_Materials[0]
        obj = mp.deref()
    except Exception:
        return "", None
    key = (id(obj.assets_file), obj.path_id)
    if key not in _mat_cache:
        try:
            mat = obj.read()
            col = None
            tex = None
            for name, te in mat.m_SavedProperties.m_TexEnvs:
                if name in ("_MainTex", "_BaseMap") and te.m_Texture.m_PathID:
                    try:
                        tex = te.m_Texture.read().image.convert("RGBA").resize((1, 1), Image.BOX).getpixel((0, 0))
                    except Exception:
                        tex = None
            for name, c in mat.m_SavedProperties.m_Colors:
                if name == "_Color":
                    col = (int(c.r * 255), int(c.g * 255), int(c.b * 255), int(c.a * 255))
            if tex is not None:
                col = tex if col is None else (tex[0] * col[0] // 255, tex[1] * col[1] // 255, tex[2] * col[2] // 255, 255)
            _mat_cache[key] = (mat.m_Name, col)
        except Exception:
            _mat_cache[key] = ("", None)
    return _mat_cache[key]


def draw_mesh(img, r, m, go, O, to_px, flat=None):
    mf = None
    for c in go.m_Component:
        p = c.component if hasattr(c, "component") else c
        if p.m_PathID in O and O[p.m_PathID].type.name == "MeshFilter":
            mf = O[p.m_PathID].read()
    if mf is None or not mf.m_Mesh.m_PathID:
        return
    try:
        obj = mf.m_Mesh.deref()
    except Exception:
        return
    key = (id(obj.assets_file), obj.path_id)
    if key not in _mesh_cache:
        try:
            t = obj.read_typetree()
            _mesh_cache[key] = parse_vd(t["m_VertexData"], t["m_IndexBuffer"], t["m_IndexFormat"])
        except Exception:
            _mesh_cache[key] = None
    md = _mesh_cache[key]
    if not md:
        return
    verts, cols, idx = md
    draw_tris(img, verts, cols, idx, m, to_px, flat=flat)


def main():
    args = sys.argv[1:]
    box, scale, grid, installed = None, 0.25, 200, False
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--box":
            box = tuple(float(v) for v in args[i + 1:i + 5])
            i += 5
            continue
        if a == "--scale":
            scale = float(args[i + 1])
            i += 2
            continue
        if a == "--grid":
            grid = int(args[i + 1])
            i += 2
            continue
        if a == "--installed":
            installed = True
            i += 1
            continue
        rest.append(a)
        i += 1
    built = os.environ.get("SSMOD_KEEP")
    scene = rest[0]
    out = rest[1] if len(rest) > 1 else f"/tmp/preview_{scene.replace(' ', '_')}.png"
    cat = Catalog(os.path.join(HERE, "base"), os.path.join(HERE, "catalog_cache.json"))
    level = scene if scene.startswith("level") else cat.scene_file(scene, None, None)
    src = None
    if built and os.path.exists(os.path.join(built, level)):
        src = os.path.join(built, level)
    elif installed:
        src = os.path.join(HC, level)
    elif os.path.exists(os.path.join(HERE, "base", level)):
        src = os.path.join(HERE, "base", level)
    b = render(level, out, box, scale, grid, src)
    print(f"{scene} ({level}) box={tuple(round(v) for v in b)} -> {out}")


if __name__ == "__main__":
    main()

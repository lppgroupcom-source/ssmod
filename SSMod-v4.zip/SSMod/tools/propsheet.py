"""Contact sheet of objects: python3 tools/propsheet.py out.png "Scene::path/or/name" ...
Each object (with its children) is drawn on its own tile with its name and size in world units."""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import preview
from preview import Image, ImageDraw, ImageFont
from ssmodlang.game import load, Catalog, SceneCtx, hierarchy_ids
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
cat = Catalog(os.path.join(HERE, "base"), os.path.join(HERE, "catalog_cache.json"))
_files = {}
def scene_file(scene):
    level = cat.scene_file(scene, None, None)
    if level not in _files:
        src = os.path.join(HERE, "base", level)
        _files[level] = load(level, src=src if os.path.exists(src) else None)
    return _files[level]

def draws_of(f, go_pid):
    O = f.objects
    ids = set(hierarchy_ids(f, go_pid))
    world = {}
    def tw(pid):
        if pid in world: return world[pid]
        t = O[pid].read(); m = preview.matrix(t)
        if t.m_Father.m_PathID:
            m = preview.mul(tw(t.m_Father.m_PathID), m)
        world[pid] = m; return m
    out = []
    for i in ids:
        o = O[i]
        if o.type.name not in ("SpriteRenderer", "MeshRenderer"): continue
        r = o.read()
        if not r.m_Enabled: continue
        go = r.m_GameObject.read()
        if not go.m_IsActive: continue
        mname, mcol = preview.mat_info(r)
        if any(k in mname for k in ("Additive", "DepthMask", "SDF", "Light")): continue
        trp = None
        for c in go.m_Component:
            cp = c.component if hasattr(c, "component") else c
            if O[cp.m_PathID].type.name in ("Transform", "RectTransform"): trp = cp.m_PathID
        m = tw(trp)
        t = O[trp].read()
        out.append(((r.m_SortingLayer, r.m_SortingOrder), 0, o.type.name, r, m, go, mname, mcol))
    return out

def bounds(draws, f):
    xs, ys = [], []
    for d in draws:
        r, m = d[3], d[4]
        pts = []
        if d[2] == "SpriteRenderer" and r.m_Sprite.m_PathID:
            sd = preview.sprite_data(r.m_Sprite)
            if sd and sd[0] == "mesh": pts = sd[1]
            elif sd:
                im, ppu, (px, py) = sd[1], sd[2], sd[3]; w, h = im.size[0] / ppu, im.size[1] / ppu
                pts = [(-px * w, -py * h), ((1 - px) * w, (1 - py) * h)]
        for x, y in pts[::max(1, len(pts) // 50)] + pts[-1:]:
            X, Y = preview.apply(m, x, y); xs.append(X); ys.append(Y)
    if not xs: return None
    return min(xs), min(ys), max(xs), max(ys)

def main():
    out = sys.argv[1]; specs = sys.argv[2:]
    tiles = []
    try: font = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 11)
    except Exception: font = None
    for spec in specs:
        scene, name = spec.split("::", 1)
        env, f = scene_file(scene)
        ctx = SceneCtx.__new__(SceneCtx)
        try:
            go = SceneCtx.find_in(ctx, f, name, scene, None, None)
        except Exception as e:
            print("missing", spec, e); continue
        ds = draws_of(f, go)
        b = bounds(ds, f)
        if not b: print("empty", spec); continue
        x0, y0, x1, y1 = b
        w, h = x1 - x0, y1 - y0
        from ssmodlang.game import world_position, transform_of
        ox, oy, _ = world_position(f, transform_of(f, f.objects[go].read()).path_id)
        print(f"{spec:70s} size {w:6.0f} x {h:5.0f}   bounds rel. to origin: x {x0-ox:+6.0f}..{x1-ox:+6.0f}  y {y0-oy:+6.0f}..{y1-oy:+6.0f}")
        sc = min(1.0, 220 / max(w, h, 1))
        img = Image.new("RGBA", (240, 260), (60, 60, 70, 255))
        def to_px(x, y, x0=x0, y1=y1, sc=sc): return (x - x0) * sc + 10, (y1 - y) * sc + 10
        ds.sort(key=lambda d: d[0])
        for d in ds:
            if d[2] == "SpriteRenderer": preview.draw_sprite(img, d[3], d[4], to_px, sc)
            else: preview.draw_mesh(img, d[3], d[4], d[5], f.objects, to_px, d[7])
        dr = ImageDraw.Draw(img)
        dr.rectangle([0, 238, 240, 260], fill=(0, 0, 0, 255))
        dr.text((3, 240), f"{name[-34:]}", fill=(255, 255, 0, 255), font=font)
        dr.text((3, 250), f"{w:.0f}x{h:.0f} ({scene})", fill=(200, 200, 200, 255), font=font)
        tiles.append(img)
    cols = 5
    rows = math.ceil(len(tiles) / cols)
    sheet = Image.new("RGB", (cols * 244, rows * 264), (20, 20, 20))
    for k, t in enumerate(tiles):
        sheet.paste(t, ((k % cols) * 244, (k // cols) * 264))
    sheet.save(out); print("wrote", out, len(tiles), "tiles")
main()

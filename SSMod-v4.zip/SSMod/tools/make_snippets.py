"""Write editor/vscode-ssmod/snippets/ssmod.json: autocomplete for SSMod's commands and the game's dialogue API
(every NodeCanvasBridge function from ssmodlang/api.json, with its values as placeholders).
  python3 tools/make_snippets.py
"""
import json
import os
import sys

HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HOME)
from ssmodlang import calls  # noqa: E402

OUT = os.path.join(HOME, "editor", "vscode-ssmod", "snippets", "ssmod.json")

KEYWORDS = {
    "mod": ('mod "${1:My Mod}" by "${2:Me}" version 1.0;', "the header line"),
    "npc": ('npc ${1:Name} in "${2:Campground_Hub}" at "${3:Doctor Duck}" + (${4:150}, ${5:0}) {\n\tlook { shirt = #${6:FF8800}; }\n\tdialogue {\n\t\tsay "${7:Hi!}";\n\t}\n}', "a character"),
    "spot": ('spot ${1:Name} in "${2:Campground_Hub}" at (${3:0}, ${4:0}) {\n\tdialogue { say "${5:...}"; }\n}', "something to look at / use"),
    "behavior": ("behavior {\n\tforever {\n\t\twander ${1:300};\n\t\twait random ${2:2} to ${3:5};\n\t}\n}", "an npc's own life"),
    "function": ("function ${1:Name}(${2}) {\n\t$0\n}", "your own reusable function"),
    "template": ("template ${1:Name} {\n\tlook { shirt = #${2:1D3557}; }\n\tdialogue { say \"${3:Hi}\"; }\n}", "a kind of npc"),
    "hud": ('hud ${1:Name} "${2:text}" in "${3:Campground_Hub}" at (${4:0}, ${5:250});', "text on the screen"),
    "image": ('image ${1:Name} from "${2:art/picture.png}";', "your own picture"),
    "place image": ('place image ${1:Name} in "${2:Campground_Hub}" at (${3:0}, ${4:0});', "put a picture in the world"),
    "sound": ('sound ${1:Name} from "${2:sounds/sound.wav}";', "your own sound"),
    "play": ("play ${1:Name};", "play a sound"),
    "override": ('override "${1:Doctor Duck}" in "${2:Campground_Hub}" {\n\tdialogue { say "${3:...}"; }\n}', "new lines for a game character"),
    "on key": ('on key "${1:e}" in "${2:Campground_Hub}" {\n\t$0\n}', "a new control"),
    "script": ('script ${1:Name} in "${2:Campground_Hub}" {\n\t$0\n}', "code that runs by itself"),
    "parallel": ("parallel {\n\t{ $1 }\n\t{ $2 }\n}", "run branches at the same time"),
    "choice": ('choice "${1:Question?}" {\n\t"${2:Yes}" => { $3 }\n\t"${4:No}" => { $5 }\n}', "a menu"),
    "random": ('random {\n\t"${1:Line one}";\n\t"${2:Line two}";\n}', "one of several"),
    "random daily": ('random daily {\n\t"${1:Line one}";\n\t"${2:Line two}";\n}', "a new pick each day"),
    "once": ("once { $0 }", "only the first time"),
    "call": ("call ${1:Misc_SetWeather}(${2});", "run one of the game's functions"),
    "walk to": ("walk to ${1:player} within ${2:150};", "npc walks somewhere"),
    "wander": ("wander ${1:300};", "npc walks somewhere random"),
    "waitUntil event": ("waitUntil (event player.${1:OnInteriorChange});", "wait for a game event"),
}


def main():
    snips = {}
    for key, (body, desc) in KEYWORDS.items():
        snips[f"ssmod: {key}"] = {"prefix": key, "body": body.split("\n"), "description": desc}
    have = calls.game_methods()
    n = 0
    for key, sigs in sorted(calls.api()["functions"].items()):
        cls, name = key.rsplit(".", 1)
        if cls != calls.DEFAULT_CLASS:
            continue
        for sig in sigs:
            if (cls, name, len(sig["params"])) not in have:
                continue
            ps = ", ".join(f"${{{i + 1}:{p}}}" for i, (t, p) in enumerate(sig["params"]))
            label = f"{name}({', '.join(calls.friendly(t) + ' ' + p for t, p in sig['params'])})"
            ret = calls.friendly(sig["ret"])
            snips[f"game: {label}"] = {"prefix": [name, f"call {name}"], "body": [f"call {name}({ps});"],
                                       "description": f"game function{'' if ret == 'nothing' else ' -> ' + ret}"}
            n += 1
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(snips, open(OUT, "w"), indent=1)
    print(f"{len(KEYWORDS)} commands + {n} game functions -> {OUT}")


if __name__ == "__main__":
    main()

"""SSMod Bridge, your side: control Sneaky Sasquatch from your own program while you play.

The game side is mods/bridge.ssmod: it watches a mailbox folder in the game's data folder. This file writes
commands there and reads the events the game writes back. Only Python's standard library is used.

Use it two ways:
  ./ssmod bridge                 an interactive console: type  weather Snowy,  coins 100,  hud Hello!  ...
  from bridge import Bridge      in your own Python program:

      b = Bridge()
      b.weather("Snowy")
      b.coins(250)
      b.hud("Hello from Python!")
      for event in b.events():  # waits for things that happen in the game
          print(event)          # e.g. "building town"

Any language works the same way: write a file, the game reads it (see the top of mods/bridge.ssmod).
"""
import glob
import os
import re
import sys
import threading
import time

CONTAINER = os.path.expanduser("~/Library/Containers/com.rac7.SneakySasquatchMac/Data")
GAME_LOG = os.path.join(CONTAINER, "Library/Logs/RAC7/Sasquatch/Player.log")
WEATHERS = ("Clear", "Rainy", "Snowy", "SnowyHeavy")
SERVICES = ("Police", "Ambulance", "Fire")


def find_folder():
    """The mailbox: the bridge logs its folder when it starts; before that, look where Unity keeps app data."""
    if os.path.exists(GAME_LOG):
        with open(GAME_LOG, errors="replace") as fh:
            hits = re.findall(r"\[SSMod\] bridge script: bridge folder=(.+)", fh.read())
        if hits:
            return hits[-1].strip()
    found = glob.glob(os.path.join(CONTAINER, "Library/Application Support/*/*/ssmod_bridge"))
    return found[0] if found else None


class Bridge:
    def __init__(self, folder=None):
        self.folder = folder or find_folder()
        if not self.folder:
            raise RuntimeError("The bridge hasn't started yet: install mods/bridge.ssmod (./ssmod install), open the "
                               "game, and go to the campground, Town, the seaport or the airport.")
        os.makedirs(self.folder, exist_ok=True)

    def _send(self, name, text):
        """Write a command file in one go (the game never sees half a file)."""
        tmp = os.path.join(self.folder, f".{name}.tmp")
        with open(tmp, "w") as fh:
            fh.write(str(text))
        os.replace(tmp, os.path.join(self.folder, f"{name}.txt"))

    # ---- commands
    def weather(self, kind):
        if kind not in WEATHERS:
            raise ValueError(f"weather is one of {WEATHERS}")
        self._send("weather", kind)

    def coins(self, amount):
        self._send("coins", int(amount))

    def hud(self, text):
        self._send("hud", text)

    def music(self, kind):
        if kind not in ("halloween", "xmas"):
            raise ValueError("music is halloween or xmas")
        self._send("music", kind)

    def call_911(self, service):
        if service not in SERVICES:
            raise ValueError(f"911 is one of {SERVICES}")
        self._send("911", service)

    # ---- events from the game
    def status(self):
        p = os.path.join(self.folder, "status.txt")
        return open(p).read() if os.path.exists(p) else None

    def poll(self):
        """Events written since the last call (oldest first); each is read once."""
        out = []
        files = glob.glob(os.path.join(self.folder, "event_*.txt"))
        for p in sorted(files, key=os.path.getmtime):
            try:
                out.append(open(p).read())
                os.remove(p)
            except OSError:
                pass
        return out

    def events(self, every=0.2):
        """A generator that waits for events forever."""
        while True:
            for e in self.poll():
                yield e
            time.sleep(every)


HELP = """commands:
  weather Clear|Rainy|Snowy|SnowyHeavy     coins 100   coins -50     hud some text   hud   (clears it)
  music halloween|xmas                     911 Police|Ambulance|Fire   status          help   quit
events from the game show up as  << ...  while you type."""


def console():
    try:
        b = Bridge()
    except RuntimeError as e:
        sys.exit(str(e))
    print(f"SSMod Bridge: connected to {b.folder}")
    print(f"game says: {b.status() or '(nothing yet)'}")
    print(HELP)
    stop = threading.Event()

    def watch():
        while not stop.is_set():
            for e in b.poll():
                print(f"\n  << {e}\n> ", end="", flush=True)
            time.sleep(0.2)
    threading.Thread(target=watch, daemon=True).start()
    while True:
        try:
            line = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            continue
        cmd, _, arg = line.partition(" ")
        try:
            if cmd in ("quit", "exit"):
                break
            elif cmd == "help":
                print(HELP)
            elif cmd == "status":
                print(f"game says: {b.status() or '(nothing yet)'}")
            elif cmd == "weather":
                b.weather(arg)
            elif cmd == "coins":
                b.coins(int(arg))
            elif cmd == "hud":
                b.hud(arg)
            elif cmd == "music":
                b.music(arg)
            elif cmd == "911":
                b.call_911(arg)
            else:
                print("unknown command (type help)")
                continue
            print("  sent")
        except ValueError as e:
            print(f"  {e}")
    stop.set()


if __name__ == "__main__":
    console()

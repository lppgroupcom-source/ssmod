# The Fairground - exec'd by gen_airport.py after gen_school.py (its gate is on the airport grounds, south of the
# parking lot).
#   Fairground    a fenced field: game stalls, a prize booth, food, a fortune teller, a Ferris wheel, a staff trailer
#   Big_Top       the circus tent: the ringmaster and the strongman act
#   Fair_Office   the locked office trailer (the end of the story)
# Play: games cost coins and pay TICKETS; tickets buy prizes. Jobs for the owner: litter -> run the ring toss ->
# strongman. Story: the takings go missing; a magnet, a torn ledger and the office safe point at the ringmaster.
# Rules as before: top/bottom doors only, right wall at x = -3600, no `end;`, every menu has a line before it.
import math as _m

FA, FB, FO = "Fairground", "Big_Top", "Fair_Office"
GX, GY = 1000, -100                                   # the gate on the airport grounds

w("// ================================================================ THE FAIRGROUND")
w("flag MetBarnaby, LitterJob, Lit1, Lit2, Lit3, Lit4, Lit5, StallJob, FoundMagnet, Unrigged, StrongJob, StrongDone,")
w("     ClueLedger, OfficeOpen, FoundSafe, Confronted, WheelStopped, FairSaved, FairRewarded, DuckTurn1, DuckTurn2,")
w("     Bal1, Bal2, Bal3, Bal4, Bal5, Bal6, BalloonPrize, FortuneTold;")
w('item FairTicket { name = "Fair Ticket"; description = "Win these at the stalls, spend them at the prize booth."; icon = sprite("ui_ticket_large"); base = "Chairlift Ticket"; }')
w('item CornDog { name = "Corn Dog"; description = "Fairground fuel. Mustard included, napkin not."; icon = sprite("hotdog"); base = "Burger"; }')
w('item CandyFloss { name = "Candy Floss"; description = "A cloud of sugar on a stick."; icon = sprite("candy"); base = "Candy"; }')
w('item FairPopcorn { name = "Fairground Popcorn"; description = "Half of it is already on the ground."; icon = sprite("popcorn_bag"); base = "Popcorn"; }')
w('item PlushDuck { name = "Giant Plush Duck"; description = "The top prize. It judges you softly."; icon = sprite("achievement_icon_duck-hat"); base = "Chairlift Ticket"; }')
w('item PartyBalloon { name = "Gold Balloon"; description = "A prize from the booth. Do not let go."; icon = sprite("dirttrack_balloon_gold"); base = "Chairlift Ticket"; }')
w('item FairPass { name = "Lifetime Fair Pass"; description = "Barnaby\'s thanks. Good for every ride, forever."; icon = sprite("bus_pass_30"); base = "Chairlift Ticket"; }')
w('''
area Fairground from "TownHall_Floor_B1" named "Barnaby's Travelling Fair" {
    room (-7600, 807) to (-3600, 2607);
    door South at (-5600, 807) narrow;                // the gate (back to the airport grounds)
    door North at (-6800, 2607) narrow;               // the Big Top
    door NorthAlt at (-4300, 2607);                   // the office trailer (walled off until you have the key)
    connect South to "Airport" East;
    connect North to "Big_Top" South;
    connect NorthAlt to "Fair_Office" South;
}
area Big_Top from "TownHall_Floor_B1" named "The Big Top" {
    room (-6000, 807) to (-3600, 2207);
    door South at (-4800, 807) narrow;
    connect South to "Fairground" North;
}
area Fair_Office from "TownHall_Floor_B1" named "The Fair Office" {
    room (-4800, 807) to (-3600, 1507);
    door South at (-4200, 807);
    connect South to "Fairground" NorthAlt;
}
''')
for _s in (FA, FB, FO):
    w(f'hide "townhall_dailychallenge_board" in "{_s}";')
    w(f'hide "sign" in "{_s}";')


# ---------------------------------------------------------------- meshes
def _pts(pts):
    return " ".join(f"({x:.0f}, {y:.0f})" for x, y in pts)


def _stripes(x0, x1, y0, y1, n, cols, top=None):
    """n vertical stripes between x0..x1; with top = (tx, ty) they all meet at that point (a tent roof)."""
    out = []
    for k in range(n):
        a, b = x0 + (x1 - x0) * k / n, x0 + (x1 - x0) * (k + 1) / n
        col = cols[k % len(cols)]
        if top:
            out.append(f"    polygon #{col} {_pts([(a, y0), (b, y0), top])};")
        else:
            out.append(f"    polygon #{col} {_pts([(a, y0), (b, y0), (b, y1), (a, y1)])};")
    return out


RW = ("D62828", "F8F9FA")
m = ["mesh FairGate {"]                                       # an arch with a striped banner
m += ["    rect (-150, 0) (36, 250) #5B3A29;", "    rect (114, 0) (36, 250) #5B3A29;"]
m += _stripes(-170, 170, 250, 320, 10, RW)
m += ["    circle (-132, 345) 24 #FFD166;", "    circle (132, 345) 24 #FFD166;", "}"]
m += ["mesh TentFront {"]                                     # the Big Top seen from outside (stands on the wall line)
m += _stripes(-340, 340, 0, 190, 12, RW)
m += _stripes(-390, 390, 190, 0, 14, RW, top=(0, 430))
m += [f"    polygon #2B2D42 {_pts([(-60, 0), (60, 0), (0, 150)])};",                   # the way in
      "    rect (-4, 430) (8, 70) #5B3A29;", f"    polygon #FFD166 {_pts([(4, 500), (70, 480), (4, 460)])};", "}"]
m += ["mesh TentFlap {"]                                      # the way out, from inside
m += [f"    polygon #2B2D42 {_pts([(-70, 0), (70, 0), (0, 170)])};",
      f"    polygon #D62828 {_pts([(-70, 0), (-40, 0), (0, 170)])};", f"    polygon #D62828 {_pts([(70, 0), (40, 0), (0, 170)])};", "}"]
m += ["mesh Awning {"]                                        # the roof of a stall
m += ["    rect (-150, 0) (14, 190) #5B3A29;", "    rect (136, 0) (14, 190) #5B3A29;"]
m += _stripes(-170, 170, 190, 250, 8, RW)
for k in range(8):
    m.append(f"    circle ({-170 + 42.5 * k + 21:.0f}, 190) 21 #{RW[k % 2]};")
m += ["}"]
m += ["mesh Wheel {"]                                         # the Ferris wheel (origin at the foot of its legs)
CY, R = 430, 300
m += [f"    polygon #6C757D {_pts([(-190, 0), (-150, 0), (10, CY), (-10, CY)])};",
      f"    polygon #6C757D {_pts([(190, 0), (150, 0), (-10, CY), (10, CY)])};",
      f"    circle (0, {CY}) {R} #ADB5BD;", f"    circle (0, {CY}) {R - 22} #7FB069;"]
for k in range(8):
    a = _m.pi * k / 4
    c, s_ = _m.cos(a), _m.sin(a)
    m.append(f"    polygon #ADB5BD {_pts([(-8 * s_, CY + 8 * c), (8 * s_, CY - 8 * c), (R * c + 8 * s_, CY + R * s_ - 8 * c), (R * c - 8 * s_, CY + R * s_ + 8 * c)])};")
for k, col in enumerate(("D62828", "FFD166", "3A86FF", "8AC926", "9B5DE5", "FF7F11", "2A9D8F", "F15BB5")):
    a = _m.pi * k / 4 + 0.2
    gx, gy = R * _m.cos(a), CY + R * _m.sin(a)
    m.append(f"    rect ({gx - 34:.0f}, {gy - 52:.0f}) (68, 46) #{col};")
    m.append(f"    polygon #2B2D42 {_pts([(gx - 40, gy - 6), (gx + 40, gy - 6), (gx, gy + 14)])};")
m += [f"    circle (0, {CY}) 34 #D62828;", "}"]
m += ["mesh Trailer {"]                                       # the office trailer front (stands on the wall line)
m += ["    rect (-260, 30) (520, 200) #E9ECEF;", "    rect (-260, 200) (520, 30) #457B9D;", "    rect (-200, 110) (90, 70) #A8DADC;",
      "    rect (110, 110) (90, 70) #A8DADC;", "    circle (-170, 26) 30 #2B2D42;", "    circle (170, 26) 30 #2B2D42;", "}"]
m += ["mesh Balloon {", f"    polygon #6C757D {_pts([(-2, 0), (2, 0), (2, 90), (-2, 90)])};", "    circle (0, 126) 40 #E63946;",
      "    circle (-12, 140) 9 #FFB3B8;", "}"]
m += ["mesh Lights {"]                                        # a string of bulbs
m.append(f"    polygon #2B2D42 {_pts([(-900, 4), (900, 4), (900, 8), (-900, 8)])};")
for k in range(19):
    m.append(f"    circle ({-900 + 100 * k}, {(-6 if k % 2 else -14)}) 13 #{('FFD166', 'E63946', '3A86FF', '8AC926')[k % 4]};")
m += ["}"]
m += ["mesh Tester {",                                        # the strength tester tower
      "    rect (-34, 0) (68, 360) #2B2D42;", "    rect (-22, 20) (44, 300) #F8F9FA;"]
for k in range(6):
    m.append(f"    rect (-22, {40 + k * 46}) (44, 8) #{'D62828' if k % 2 else 'FFD166'};")
m += ["    circle (0, 384) 34 #FFD166;", "    rect (-70, 0) (140, 26) #6C757D;", "}"]
m += ["mesh Barbell {", "    rect (-150, 20) (300, 14) #6C757D;", "    circle (-150, 27) 50 #2B2D42;", "    circle (150, 27) 50 #2B2D42;",
      "    circle (-150, 27) 18 #6C757D;", "    circle (150, 27) 18 #6C757D;", "}"]
m += ["mesh Safe {", "    rect (-80, 0) (160, 180) #495057;", "    rect (-64, 16) (128, 148) #6C757D;", "    circle (0, 90) 30 #2B2D42;",
      "    circle (0, 90) 10 #FFD166;", "}"]
w("\n".join(m))


def pm(scene, name, x, y, *opts):
    w(f'place mesh {name} in "{scene}" at ({x:.0f}, {y:.0f}){(" " + " ".join(o for o in opts if o)) if any(opts) else ""};')


def stall(scene, x, y, words, col):
    """A stall: striped awning, a counter and its name. The keeper stands behind it, you stand in front."""
    pm(scene, "Awning", x, y)
    rect(scene, x, y + 40, 280, 80, col, 1)
    rect(scene, x, y + 84, 300, 14, "5B3A29", 1.5)
    sign(scene, x, y + 290, words, "1D3557", "FFD166", wd=max(200, 20 * len(words) + 40), ht=40, front=3)


def keeper(name, scene, x, y, shirt, pants="264653", **look):
    extra = "".join(f" {k} = {v};" for k, v in look.items())
    w(f'npc {name} in "{scene}" at ({x}, {y}) {{ look {{ shirt = #{shirt}; pants = #{pants};{extra} }} bubble = false; }}')


# ================================================================= THE GATE (airport grounds)
w("// ---------------------------------------------------------------- the fair's gate, south of the airport parking lot")
pm(A, "FairGate", GX, GY)
sign(A, GX, GY + 400, "BARNABY'S FAIR", "D62828", "FFD166", wd=330, ht=50, front=3)
pm(A, "Balloon", GX - 230, GY + 20)
pm(A, "Balloon", GX + 230, GY + 20, "color #3A86FF")
w(f'''
npc Ticket_Tout in "{A}" at ({GX + 340}, {GY + 200}) {{
    look {{ shirt = #D62828; pants = #F8F9FA; hair = #3D2314; }}
    bubble = true;
    dialogue {{
        if (FairSaved) say "Best fair in Canada, and it's staying! Tell your friends. Tell your enemies.";
        else {{
            say "Roll up, roll up! <item>Barnaby's Travelling Fair</item>, through the striped gate!";
            say "Games, prizes, a <item>Ferris wheel</item> and the <shake>Big Top</shake>. Bring coins. Bring more coins.";
        }}
    }}
}}
''')

# ================================================================= THE FAIRGROUND   x -7600..-3600, y 807..2607
floor(FA, -7600, 807, 4000, 1800, "7FB069", 3)
floor(FA, -7600, 1500, 4000, 170, "D9B382", 4)                   # the midway (dirt paths)
floor(FA, -5700, 807, 200, 1800, "D9B382", 4)
for k in range(10):                                              # worn grass
    floor(FA, -7500 + k * 400, 900 + (k * 173) % 500, 90, 30, "74A35F", 4)
    floor(FA, -7300 + k * 380, 1800 + (k * 211) % 600, 70, 26, "74A35F", 4)
pm(FA, "FairGate", -5600, 830)
sign(FA, -5600, 1230, "EXIT", "D62828", "F8F9FA", wd=140, ht=40, front=3)
pm(FA, "TentFront", -6800, 2607, "front 14")
sign(FA, -6800, 2470, "THE BIG TOP", "1D3557", "FFD166", wd=260, ht=40, front=60)
pm(FA, "Trailer", -4300, 2607, "front 14")
sign(FA, -4300, 2880, "OFFICE - STAFF ONLY", "2B2D42", "F8F9FA", wd=330, ht=40, front=20)
w(f'wall in "{FA}" from (-4420, 2480) to (-4180, 2480) color #6C757D hideIf OfficeOpen;')      # the office is fenced off
w(f'wall in "{FA}" from (-4420, 2480) to (-4420, 2607) color #6C757D hideIf OfficeOpen;')
w(f'wall in "{FA}" from (-4180, 2480) to (-4180, 2607) color #6C757D hideIf OfficeOpen;')
sign(FA, -4300, 2440, "LOCKED", "D62828", "F8F9FA", wd=150, ht=36, front=3, cond="hideIf OfficeOpen")
pm(FA, "Lights", -6600, 2440, "front 14")
pm(FA, "Lights", -4700, 1760)
pm(FA, "Lights", -6600, 1760)
pm(FA, "Wheel", -4350, 1720)
pm(FA, "Tester", -5150, 2090)
sign(FA, -5150, 2530, "STRENGTH", "1D3557", "FFD166", wd=200, ht=40, front=3)
stall(FA, -7150, 2000, "RING TOSS", "2A9D8F")
stall(FA, -6200, 2000, "DUCK POND", "3A86FF")
stall(FA, -4750, 2000, "PRIZES", "9B5DE5")
stall(FA, -7000, 1050, "FOOD", "F77F00")
# the fortune teller's tent and the staff trailer
w("mesh SmallTent {")
w("\n".join(_stripes(-150, 150, 0, 150, 6, ("6A4C93", "F8F9FA"))))
w("\n".join(_stripes(-180, 180, 150, 0, 6, ("6A4C93", "F8F9FA"), top=(0, 300))))
w(f"    polygon #2B2D42 {_pts([(-40, 0), (40, 0), (0, 110)])};")
w("    circle (0, 310) 16 #FFD166;\n}")
pm(FA, "SmallTent", -6250, 1020)
sign(FA, -6250, 1360, "FORTUNES", "6A4C93", "FFD166", wd=200, ht=36, front=3)
pm(FA, "Trailer", -4350, 980)
sign(FA, -4350, 1250, "STAFF", "457B9D", "F8F9FA", wd=140, ht=36, front=3)
for k, (x, y) in enumerate(((-7350, 1350), (-6650, 2330), (-5350, 1300), (-4900, 1420), (-3900, 2250))):      # litter
    rect(FA, x, y, 30, 38, "F1FAEE", 0, f"hideIf Lit{k + 1}")
    rect(FA, x, y + 22, 34, 8, "E63946", 0.5, f"hideIf Lit{k + 1}")
BALLOONS = ((-7450, 2350), (-7450, 950), (-5950, 2400), (-3800, 1000), (-3750, 2300), (-5250, 1750))
for k, (x, y) in enumerate(BALLOONS):
    pm(FA, "Balloon", x, y, f"hideIf Bal{k + 1}", "color #FFD166" if k % 2 else "")

w(f'''
// ---------------------------------------------------------------- Barnaby, the owner: the jobs and the story
npc Barnaby in "{FA}" at (-5350, 1020) {{
    look {{ shirt = #9D0208; pants = #2B2D42; hair = #CED4DA; beard = #CED4DA; chubby = 0.7; shirtType = LongSleeve; }}
    bubble = true;
    dialogue {{
        if (FairRewarded) say "My favourite employee! The fair's staying for good, thanks to you. Go and ride something.";
        else if (FairSaved) {{
            set FairRewarded;
            give FairPass;
            give coins 500;
            give FairTicket 20;
            say "The <item>ringmaster</item>! Rudolfo! Twenty years I trusted that man and his ridiculous hat.";
            say "You saved the fair. Here: a <item>Lifetime Pass</item>, <price>500</price> coins and twenty tickets. The fair stays!";
        }}
        else if (OfficeOpen) say "The office is the trailer in the top right corner. I unlocked the fence. Find out where my money is going!";
        else if (StrongJob) {{
            if (StrongDone && FoundMagnet && ClueLedger) {{
                set OfficeOpen;
                say "A <item>magnet</item> in my ring toss? Pages <shake>torn out</shake> of the ledger? Somebody is robbing me blind!";
                say "The books are in the <item>office</item>. Here, I've unlocked the fence around it. Top right corner. Go and look.";
            }}
            else if (StrongDone) say "You were magnificent in there! But the takings are STILL short. Have a look around the <item>staff trailer</item>, would you?";
            else say "The <item>Big Top</item> is the striped tent, top left. Our strongman quit. The barbell is waiting for you.";
        }}
        else if (StallJob) {{
            if (Unrigged) {{
                set StrongJob;
                give coins 80;
                say "The ring toss is paying out and people are <shake>queueing</shake>! Whatever you did, here's <price>80</price> coins.";
                say "One more job. Our strongman quit this morning. Go to the <item>Big Top</item> and lift the barbell. You have the arms for it.";
            }}
            else say "The <item>ring toss</item> needs someone watching it. Top left stall. Nobody ever wins, and I can't work out why.";
        }}
        else if (LitterJob) {{
            if (Lit1 && Lit2 && Lit3 && Lit4 && Lit5) {{
                set StallJob;
                give coins 60;
                say "Spotless! Here's <price>60</price> coins. You're promoted.";
                say "Go and mind the <item>ring toss</item> stall, top left. Nobody ever wins it, the customers are grumbling, and I can't work out why.";
            }}
            else say "Five bits of <item>litter</item> around the fair. Cups, mostly. Pick them all up and I'll pay you.";
        }}
        else {{
            set MetBarnaby;
            set LitterJob;
            say "Welcome to <item>Barnaby's Travelling Fair</item>! I'm Barnaby. You're tall. Are you looking for work?";
            say "We're short-staffed and, between us, short of money. The takings keep coming up <shake>light</shake>.";
            say "Start small: there are five bits of <item>litter</item> around the fair. Pick them up and come back.";
        }}
    }}
}}''')
for k, (x, y) in enumerate(((-7350, 1350), (-6650, 2330), (-5350, 1300), (-4900, 1420), (-3900, 2250))):
    w(f'''spot Litter_{k + 1} in "{FA}" at ({x}, {y - 60}) {{
    bubble = false;
    dialogue {{
        if (Lit{k + 1}) say "Nice clean grass.";
        else if (LitterJob) {{ set Lit{k + 1}; say "You pick up a squashed <item>cup</item>. Litter {k + 1} of 5."; }}
        else say "A squashed cup. Somebody should pick that up. Maybe <item>Barnaby</item> pays for that sort of thing.";
    }}
}}''')
for k, (x, y) in enumerate(BALLOONS):
    w(f'''spot Balloon_{k + 1} in "{FA}" at ({x}, {y - 50}) {{
    bubble = false;
    dialogue {{
        if (Bal{k + 1}) say "Just a bit of string in the grass now.";
        else {{ set Bal{k + 1}; say "A lost <item>balloon</item>! You untie it. That's one. There are six around the fair."; }}
    }}
}}''')

# ---- the stalls
keeper("Toss_Keeper", FA, -7150, 2110, "2A9D8F")
keeper("Pond_Keeper", FA, -6200, 2110, "3A86FF")
keeper("Prize_Keeper", FA, -4750, 2110, "9B5DE5", hair="#F15BB5")
keeper("Food_Keeper", FA, -7000, 1160, "F77F00", chubby="0.8")
w(f'''
spot Ring_Toss in "{FA}" at (-7150, 1880) {{
    dialogue {{
        if (Unrigged) {{
            choice "RING TOSS! Ten coins a go. Which bottle are you aiming at?" {{
                "The left one" => {{
                    if (coins >= 10) {{ take coins 10; say "It spins on the neck... and falls off. So close!"; }}
                    else say "Ten coins a go, friend.";
                }}
                "The middle one" => {{
                    if (coins >= 10) {{ take coins 10; give FairTicket 3; say "<shake>CLINK!</shake> Right over the top! Three <item>tickets</item>!"; }}
                    else say "Ten coins a go, friend.";
                }}
                "The right one" => {{
                    if (coins >= 10) {{ take coins 10; say "It bounces off the rim. The middle one looks wider, you know."; }}
                    else say "Ten coins a go, friend.";
                }}
                "Not now" => say "Come back when you're feeling lucky!";
            }}
        }}
        else if (FoundMagnet) {{
            choice "The magnet is still under the counter, pulling every ring sideways." {{
                "Pull the magnet out" => {{
                    set Unrigged;
                    say "You yank out a magnet the size of a dinner plate. The rings stop swerving.";
                    say "The stall is <item>fair</item> again. Barnaby will want to know about this.";
                }}
                "Leave it" => say "You leave it. The rings keep missing.";
            }}
        }}
        else if (StallJob) {{
            choice "RING TOSS! You're minding the stall now. Nobody has won all day." {{
                "Have a go yourself (10)" => {{
                    if (coins >= 10) {{ take coins 10; say "The ring flies straight... then <shake>swerves</shake> sideways in mid-air. That's not normal."; }}
                    else say "Even staff pay ten coins.";
                }}
                "Look under the counter" => {{
                    set FoundMagnet;
                    say "Taped under the counter: a huge <item>magnet</item>, pointed right at the bottles.";
                    say "Somebody <shake>rigged</shake> the ring toss. And it wasn't Barnaby: he's the one losing money.";
                }}
                "Just stand there" => say "You stand there. A child loses. You feel bad.";
            }}
        }}
        else {{
            choice "RING TOSS! Ten coins a go. Land a ring on a bottle, win tickets!" {{
                "Play (10)" => {{
                    if (coins >= 10) {{ take coins 10; say "The ring flies straight... then swerves at the last second. So unlucky! Every single time."; }}
                    else say "Ten coins a go, friend.";
                }}
                "Not now" => say "Suit yourself!";
            }}
        }}
    }}
}}
spot Duck_Pond in "{FA}" at (-6200, 1880) {{
    dialogue {{
        choice "DUCK POND! Five coins. One of these three ducks has a star underneath. Pick one!" {{
            "The red duck" => {{
                if (coins >= 5) {{
                    take coins 5;
                    if (DuckTurn1 && !DuckTurn2) {{ set DuckTurn2; give FairTicket 2; say "A <item>star</item>! Two tickets! The ducks shuffle round."; }}
                    else say "No star. The duck looks smug about it.";
                }} else say "Five coins a duck.";
            }}
            "The blue duck" => {{
                if (coins >= 5) {{
                    take coins 5;
                    if (DuckTurn2) {{ clear DuckTurn1; clear DuckTurn2; give FairTicket 2; say "A <item>star</item>! Two tickets! The ducks shuffle round."; }}
                    else say "No star. Just a damp duck.";
                }} else say "Five coins a duck.";
            }}
            "The yellow duck" => {{
                if (coins >= 5) {{
                    take coins 5;
                    if (!DuckTurn1) {{ set DuckTurn1; give FairTicket 2; say "A <item>star</item>! Two tickets! The ducks shuffle round."; }}
                    else say "No star. It was under there a minute ago, you're sure of it.";
                }} else say "Five coins a duck.";
            }}
            "Not now" => say "The ducks will wait. They have nowhere to be.";
        }}
    }}
}}
spot Strength_Tester in "{FA}" at (-5150, 1960) {{
    dialogue {{
        choice "TEST YOUR STRENGTH! Ten coins. Ring the bell, win five tickets. How do you swing?" {{
            "Politely" => {{
                if (coins >= 10) {{ take coins 10; say "The puck rises to <item>'Damp Sponge'</item> and slides back down."; }}
                else say "Ten coins a swing.";
            }}
            "Like a human" => {{
                if (coins >= 10) {{ take coins 10; say "The puck gets to <item>'Not Bad, Kid'</item>. No bell."; }}
                else say "Ten coins a swing.";
            }}
            "Like a sasquatch" => {{
                if (coins >= 10) {{ take coins 10; give FairTicket 5; say "<shake>DING!</shake> The bell flies off the top. Five <item>tickets</item>, and everyone is staring at you."; }}
                else say "Ten coins a swing.";
            }}
            "Not now" => say "The mallet stays on its hook.";
        }}
    }}
}}
spot Prize_Booth in "{FA}" at (-4750, 1880) {{
    dialogue {{
        choice "PRIZES! Tickets only, no coins. What'll it be?" {{
            "Gold Balloon (5 tickets)" => {{
                if (has(FairTicket, 5)) {{ take FairTicket 5; give PartyBalloon; say "One <item>gold balloon</item>. Hold on tight."; }}
                else say "That's five tickets. Go and win some!";
            }}
            "Giant Plush Duck (15 tickets)" => {{
                if (has(FairTicket, 15)) {{ take FairTicket 15; give PlushDuck; say "The <item>Giant Plush Duck</item>! The top prize! It's bigger than you'd think."; }}
                else say "The duck is fifteen tickets. He's worth it.";
            }}
            "I found your balloons" => {{
                if (BalloonPrize) say "You already brought them all back. The balloon man cried a little.";
                else if (Bal1 && Bal2 && Bal3 && Bal4 && Bal5 && Bal6) {{ set BalloonPrize; give FairTicket 10; say "All <item>six</item> lost balloons! Ten tickets for you, hero."; }}
                else say "Six balloons blew away this morning. Bring them all back and there's ten tickets in it.";
            }}
            "Bye" => say "Come back with tickets!";
        }}
    }}
}}
shop Food_Stand in "{FA}" at (-7000, 930) {{
    greeting = "Hot food! Fair prices! (They're not fair prices.)";
    sell CornDog for 35 as "Corn Dog";
    sell CandyFloss for 25 as "Candy Floss";
    sell FairPopcorn for 20 as "Popcorn";
    thanks = "Eat it before the seagulls see.";
    broke = "No coins, no corn dog.";
    bye = "Mind the mustard!";
}}
npc Madame_Zelda in "{FA}" at (-6250, 1060) {{
    look {{ shirt = #6A4C93; pants = #240046; hair = #F8F9FA; skin = #C68642; shirtType = LongSleeve; }}
    bubble = true;
    dialogue {{
        choice "I am <item>Madame Zelda</item>. For ten coins, the spirits will tell you something useful." {{
            "Tell my fortune (10)" => {{
                if (coins >= 10) {{
                    take coins 10;
                    set FortuneTold;
                    if (FairSaved) say "The spirits say... you already did it. They're a bit embarrassed. No refunds.";
                    else if (FoundSafe) say "The spirits see a man in a <item>tall hat</item>, running. Confront him in the Big Top. Then follow him UP.";
                    else if (OfficeOpen) say "The spirits say the truth is locked in a <item>safe</item>, in the trailer in the corner.";
                    else if (FoundMagnet && ClueLedger) say "The spirits say: you hold two clues. Do the strong man's job, then take them both to <item>Barnaby</item>.";
                    else if (FoundMagnet) say "The spirits see <item>torn paper</item> in a trailer where the staff sleep. Bottom right.";
                    else if (StallJob) say "The spirits say: look <shake>under</shake> things. Counters, especially.";
                    else say "The spirits say an old man by the gate needs help, and that the <item>middle</item> is always widest.";
                }}
                else say "The spirits do not work for free.";
            }}
            "No thanks" => say "The spirits saw that coming.";
        }}
    }}
}}
spot Staff_Trailer in "{FA}" at (-4350, 880) {{
    dialogue {{
        if (ClueLedger) say "The torn ledger. The missing pages were all in the same handwriting, signed <item>R.</item>";
        else if (StallJob) {{
            set ClueLedger;
            say "A <item>ledger</item> lies open on the trailer step. The pages for this month have been <shake>torn out</shake>.";
            say "What's left is signed with a big, swirly <item>R.</item> Barnaby should hear about this.";
        }}
        else say "The staff trailer. A sign says <item>STAFF ONLY</item>. You're not staff. Yet.";
    }}
}}
npc Wheel_Operator in "{FA}" at (-4640, 1640) {{
    look {{ shirt = #457B9D; pants = #1D3557; hair = #FFB703; }}
    bubble = true;
    dialogue {{
        if (FairSaved) say "Wheel's running fine. Nobody hiding in it today. I checked. Twice.";
        else if (Confronted) {{
            if (WheelStopped) say "She's stopped, with the top car right at the bottom. Whoever's in there is all yours.";
            else {{
                choice "A man in a top hat just jumped into a gondola with a suitcase! He's going round and round!" {{
                    "Stop the wheel!" => {{
                        set WheelStopped;
                        say "<shake>CLUNK.</shake> I've brought his car right down to the platform. He's not going anywhere.";
                    }}
                    "Let him ride" => say "Fair enough. He did pay. I think.";
                }}
            }}
        }}
        else say "The <item>Ferris wheel</item>. Eight cars, one speed, great views of the airport car park.";
    }}
}}
spot Bottom_Gondola in "{FA}" at (-4350, 1620) {{
    bubble = false;
    dialogue {{
        if (FairSaved) say "An empty gondola. It still smells faintly of moustache wax.";
        else if (WheelStopped) {{
            set FairSaved;
            say "The gondola door opens. <item>Ringmaster Rudolfo</item>, a suitcase full of coins, and a train ticket for tonight.";
            say "'It was only ever a <shake>little</shake> off the top!' The suitcase says otherwise.";
            say "You carry the suitcase out. Rudolfo walks himself to the gate. Go and tell <item>Barnaby</item>.";
        }}
        else if (Confronted) say "The gondolas whizz past. He's in the red one. Somebody needs to <item>stop the wheel</item>.";
        else say "The gondolas go round. Very relaxing.";
    }}
}}
npc Kid_With_Floss in "{FA}" at (-6600, 1580) {{
    look {{ shirt = #F15BB5; pants = #3A86FF; }}
    dialogue {{ say "I've had four candy flosses. I can see through time."; }}
    patrol {{ (-6600, 1580); wait 2; (-5900, 1580); wait 2; }}
}}
npc Unlucky_Dad in "{FA}" at (-6850, 1900) {{
    look {{ shirt = #6C757D; pants = #343A40; }}
    dialogue {{
        if (Unrigged) say "I WON! Three tickets! It only took me ninety coins to get here!";
        else say "Forty coins on the ring toss. Forty! The ring swerves, I swear it swerves.";
    }}
}}
npc Balloon_Man in "{FA}" at (-5900, 1300) {{
    look {{ shirt = #FFD166; pants = #D62828; hair = #FF7F11; }}
    dialogue {{
        if (BalloonPrize) say "All six, home safe. You're a good egg.";
        else say "I sneezed and let go of <item>six balloons</item>. They're scattered all over the fair. The prize booth has a reward.";
    }}
}}
''')

# ================================================================= THE BIG TOP   x -6000..-3600, y 807..2207
floor(FB, -6000, 807, 2400, 1400, "E0C097", 3)
place(FB, CIRCLE, -4800, 1500, "size (840, 620)", "color #D62828", "front 0")
place(FB, CIRCLE, -4800, 1500, "size (780, 560)", "color #EBD3A8", "front 0.2")
for k in range(3):                                               # bleachers on both sides
    rect(FB, -5700, 1250 + k * 120, 300, 80, "6C757D", 0)
    rect(FB, -3900, 1250 + k * 120, 300, 80, "6C757D", 0)
sign(FB, -4800, 2292, "THE BIG TOP", "D62828", "FFD166", wd=420, ht=60, front=14)
poster(FB, -5600, 2292, "TONIGHT: THE STRONGMAN", "1D3557", "FFD166", wd=360, ht=40)
poster(FB, -4000, 2292, "NO REFUNDS", "2B2D42", wd=200, ht=40)
pm(FB, "TentFlap", -4800, 807)
sign(FB, -4800, 1010, "FAIR", "D62828", "F8F9FA", wd=120, ht=34, front=3)
pm(FB, "Barbell", -4800, 1400)
pm(FB, "Lights", -4800, 2180, "front 14")
w(f'''
npc Ringmaster_Rudolfo in "{FB}" at (-4800, 1800) {{
    look {{ shirt = #D62828; pants = #000000; hair = #000000; beard = #000000; shirtType = LongSleeve; shoeType = KneeBoot; gloves = #F8F9FA; }}
    scale = 1.1;
    bubble = true;
    hideIf = Confronted;                 // he runs for it
    dialogue {{
        if (FoundSafe) {{
            choice "Ah. You've been in the office. I can explain the suitcase. I can explain the train ticket." {{
                "You rigged the ring toss" => {{
                    set Confronted;
                    say "'Rigged' is such an ugly word. I prefer <item>'improved'</item>.";
                    say "...you're very large. Is that the time? <shake>I must dash!</shake>";
                    say "He grabs his hat and bolts out of the tent, towards the <item>Ferris wheel</item>.";
                }}
                "Where's Barnaby's money?" => {{
                    set Confronted;
                    say "Safe! Very safe! In a suitcase! Which I am now going to <shake>take with me!</shake>";
                    say "He sprints out of the tent, towards the <item>Ferris wheel</item>.";
                }}
                "Never mind" => say "Quite right. Nothing to see. Enjoy the show.";
            }}
        }}
        else if (StrongJob) say "So you're Barnaby's new strongman. The <item>barbell</item> is in the ring. Try not to drop it on anyone important.";
        else say "<item>Ringmaster Rudolfo</item>, at your service. The show is for paying customers and staff. You are, at present, neither.";
    }}
}}
spot Strongman_Act in "{FB}" at (-4800, 1290) {{
    dialogue {{
        if (StrongDone) say "The barbell. You bent it a little. Nobody has mentioned it.";
        else if (StrongJob) {{
            choice "The crowd goes quiet. The barbell says 500. How do you lift it?" {{
                "With both hands" => {{
                    set StrongDone;
                    give coins 100;
                    give FairTicket 5;
                    say "Up it goes. The crowd <shake>ROARS</shake>. Somebody throws a hat.";
                    say "You take a bow. <price>100</price> coins and five tickets are pressed into your hand.";
                }}
                "With one hand" => {{
                    set StrongDone;
                    give coins 100;
                    give FairTicket 5;
                    say "One hand. Over your head. You hold it there and <shake>yawn</shake>.";
                    say "A man in the front row faints. <price>100</price> coins and five tickets. A star is born.";
                }}
                "Not yet" => say "You step back from the bar. The crowd mutters.";
            }}
        }}
        else say "A barbell marked 500. It's for the <item>strongman</item>, and Barnaby hasn't hired you for that. Yet.";
    }}
}}
spot Dropped_Hat in "{FB}" at (-4800, 1700) {{
    bubble = false;
    dialogue {{
        if (FairSaved) say "A top hat on the sawdust, slightly crushed. Nobody has claimed it.";
        else if (Confronted) say "His hat fell off as he ran. The tent flap is still swinging. He went towards the <item>Ferris wheel</item>!";
        else say "Sawdust. Lots of it.";
    }}
}}
npc Front_Row_Fan in "{FB}" at (-5500, 1150) {{
    look {{ shirt = #8AC926; pants = #386641; }}
    dialogue {{
        if (StrongDone) say "ONE HAND. I'm going to tell my grandchildren about that. I don't have any yet. I'll get some.";
        else say "They said there'd be a strongman. There's just a barbell. I've been looking at a barbell for an hour.";
    }}
}}
npc Popcorn_Seller in "{FB}" at (-4050, 1150) {{
    look {{ shirt = #F8F9FA; pants = #D62828; }}
    dialogue {{ say "Popcorn's at the food stand outside. In here I just hold the tray. It's a living."; }}
}}
''')

# ================================================================= THE OFFICE   x -4800..-3600, y 807..1507
floor(FO, -4800, 807, 1200, 700, "CDB79E", 3)
sign(FO, -4200, 1592, "BARNABY'S OFFICE", "457B9D", "F8F9FA", wd=340, ht=50, front=14)
door_mat(FO, -4200, 807, "FAIR", up=False, bg="D62828", fg="F8F9FA")
prop(FO, "Stripmall", "Room Reception/Desk", -4450, 1380)
prop(FO, "Town", "Bank/bank bookshelf", -4680, 1400)
prop(FO, "Town", "Town Hall/plantpotted_townhall", -3680, 880)
pm(FO, "Safe", -3900, 1300)
rect(FO, -3900, 1250, 110, 60, "5B3A29", 1, "showIf FoundSafe")          # the suitcase next to it
w(f'''
spot Office_Safe in "{FO}" at (-3900, 1190) {{
    dialogue {{
        if (FoundSafe) say "The open safe. Empty, apart from one of <item>Rudolfo's</item> white gloves.";
        else {{
            set FoundSafe;
            say "The safe is open. Inside: the <item>torn ledger pages</item>, a <item>train ticket</item> for tonight...";
            say "...and a single white glove. Only one person at this fair wears white gloves.";
            say "<shake>The ringmaster.</shake> He's skimming the takings and leaving tonight. He'll be in the <item>Big Top</item>.";
        }}
    }}
}}
spot Office_Desk in "{FO}" at (-4450, 1260) {{
    dialogue {{ say "Barnaby's desk. A photo of the fair in better days, and a mug that says <item>WORLD'S OKAYEST BOSS</item>."; }}
}}
''')

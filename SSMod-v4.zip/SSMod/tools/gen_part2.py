# Airport Part 2 (rewritten 2026-10-01) - exec'd by gen_airport.py just before the file is written.
#
# Only mechanisms that are PROVEN in game are used here (the first version's sideways door did nothing):
#   * doors only on the top / bottom wall (facing North / South), like the terminal and cabin doors
#   * every room keeps its right wall at x = -3600, like the terminal and the cabin
#   * gates are wall pieces with hideIf (like the security barrier), never a door that appears/disappears
#
#   Terminal (south wall, by the cafe)  -> Baggage_Claim -> Customs --stamp--> VIP_Lounge
#                                                                    \-------> Runway -> Control_Tower
PB, PC, PR, PT, PV = "Baggage_Claim", "Customs", "Runway", "Control_Tower", "VIP_Lounge"
GLASS = ("Town", "Office Tower/INTERIOR/Wall Glass")

w("// ================================================================ AIRPORT PART 2")
w('''
area Baggage_Claim from "TownHall_Floor_B1" named "Baggage Claim" {
    room (-6200, 807) to (-3600, 1607);
    door North at (-3900, 1607);                 // up to the terminal
    door South at (-5000, 807);                  // down to customs
    connect North to "Airport_Terminal" SouthAlt;
    connect South to "Customs" North;
}
area Customs from "TownHall_Floor_B1" named "Customs" {
    room (-6600, 807) to (-3600, 1807);
    door North at (-5000, 1807);                 // back to baggage claim
    door South at (-5500, 807);                  // VIP lounge (behind the passport gate)
    door SouthAlt at (-3900, 807);               // runway (behind the passport gate)
    connect North to "Baggage_Claim" South;
    connect South to "VIP_Lounge" North;
    connect SouthAlt to "Runway" North;
}
area Runway from "TownHall_Floor_B1" named "Runway 09" {
    room (-6600, 807) to (-3600, 1907);
    door North at (-3900, 1907);                 // back to customs
    door NorthAlt at (-6200, 1907);              // control tower
    door South at (-5200, 807);                  // hangar
    connect North to "Customs" SouthAlt;
    connect NorthAlt to "Control_Tower" South;
    connect South to "Hangar" North;
}
area Control_Tower from "TownHall_Floor_B1" named "Control Tower" {
    room (-5000, 807) to (-3600, 2207);
    door South at (-4300, 807);
    connect South to "Runway" NorthAlt;
}
area VIP_Lounge from "TownHall_Floor_B1" named "VIP Lounge" {
    room (-5600, 807) to (-3600, 1607);
    door North at (-4600, 1607);
    connect North to "Customs" South;
}
''')
for _room in (PB, PC, PR, PT, PV):                 # the Town Hall basement's wall board doesn't belong here
    w(f'hide "townhall_dailychallenge_board" in "{_room}";')
    w(f'hide "sign" in "{_room}";')


def door_mat(scene, x, y, words, up, bg="FFD166", fg="1D3557"):
    """The name plate over a door (the door itself - frame, open door, exit zone - is made by `door`).
    up: the door is in the top wall; otherwise the bottom wall."""
    wd = max(110, 15 * len(words) + 40)
    if up:                                               # on the lintel of the door frame
        sign(scene, x, y + 118, words, bg, fg, wd=92, ht=22, front=56)   # the frame sorts 45 in front of its y
    else:
        sign(scene, x, y + 178, words, bg, fg, wd=wd, ht=30, front=2)


def jet(scene, x, y, tail):
    """A parked jet seen from above, nose to the east; every part is drawn at the fuselage's depth."""
    import math

    def part(px, py, wd, ht, color, f, rot=0, shape=RECT):
        place(scene, shape, px, py, f"size ({wd:.0f}, {ht:.0f})", f"color #{color}",
              f"rotate {rot}" if rot else "", f"front {f + 0.1 * (py - y):.2f}")
    part(x + 25, y - 40, 900, 96, "1B1C1F", 0)                       # shadow
    for side in (1, -1):
        dx, dy = -math.sin(math.radians(25)), side * math.cos(math.radians(25))
        part(x + 40 + dx * 110, y + side * 45 + dy * 110, 150, 230, "D5DBE1", 1, side * 25)
        part(x - 400 + dx * 55, y + side * 35 + dy * 55, 70, 120, "D5DBE1", 1, side * 30)
        part(x + 20, y + side * 150, 90, 36, "495057", 1.5)          # engines
    part(x, y, 900, 100, "F8F9FA", 2)
    part(x + 450, y, 120, 100, "F8F9FA", 2, shape=CIRCLE)
    part(x - 450, y, 100, 88, "F8F9FA", 2, shape=CIRCLE)
    part(x + 465, y, 20, 62, "2B2D42", 2.6)                          # windshield
    part(x - 10, y + 36, 880, 9, tail, 2.5)
    part(x - 10, y - 36, 880, 9, tail, 2.5)
    part(x - 395, y, 190, 20, tail, 2.7)                             # tail fin


def carousel(scene, cx, cy, wd, number, bags):
    """A luggage belt: dark belt, rim, end caps, a solid base and some bags riding on it."""
    rect(scene, cx, cy, wd, 100, "1E1E22", 1)
    rect(scene, cx, cy + 52, wd, 12, "4A4A52", 1.5)
    rect(scene, cx, cy - 52, wd, 12, "4A4A52", 1.5)
    for ex in (cx - wd / 2, cx + wd / 2):
        rect(scene, ex, cy, 56, 150, "33333A", 1.2)
    wall_h(scene, cx - wd / 2, cx + wd / 2, cy - 8)                  # so you can't walk through the belt
    for dx, bw, bh, col in bags:
        rect(scene, cx + dx, cy + 14, bw, bh, col, 5)
    rect(scene, cx, cy + 140, 70, 70, "FFD166", 3)
    text(scene, cx, cy + 132, str(number), "1D3557", sx=1.0, sy=1.3, front=4)


# ---------------------------------------------------------------- the way in (terminal, south wall by the cafe)
door_mat("Airport_Terminal", -3900, 807, "BAGGAGE CLAIM", up=False)
sign("Airport_Terminal", -3695, 1012, "ARRIVALS", "1D3557", "FFFFFF", wd=170, ht=40, front=2)
sign("Airport_Terminal", -3695, 964, "VIP - RUNWAY", "B8860B", "FFFFFF", wd=170, ht=36, front=2)

# ---------------------------------------------------------------- BAGGAGE CLAIM   x -6200..-3600, y 807..1607
floor(PB, -6200, 807, 2600, 800, "8A8F98", 3)
floor(PB, -6200, 807, 2600, 40, "5C6168", 4)
sign(PB, -5300, 1692, "BAGGAGE CLAIM", "1D3557", "FFFFFF", wd=420, ht=60, front=14)
door_mat(PB, -3900, 1607, "TERMINAL", up=True, bg="2A9D8F", fg="FFFFFF")
door_mat(PB, -5000, 807, "CUSTOMS", up=False)
carousel(PB, -5450, 1300, 900, 1, [(-360, 70, 50, "B03A2E"), (-150, 90, 60, "2E5C9E"), (60, 60, 46, "2E7D4F"),
                                   (330, 80, 54, "6B4A2B")])
carousel(PB, -4450, 1060, 700, 2, [(-250, 80, 52, "6A4C93"), (-40, 60, 44, "D4A72C"), (220, 90, 58, "B03A2E")])
rect(PB, -5200, 1318, 96, 64, "FFB703", 6)                          # the unclaimed bag (bright so you spot it)
rect(PB, -5200, 1354, 30, 10, "2B2D42", 10)
for x, y, bw, bh, col in ((-6080, 1500, 130, 90, "6B4A2B"), (-5960, 1480, 100, 70, "2E5C9E"),
                          (-6020, 1420, 90, 60, "B03A2E")):          # the lost luggage pile
    rect(PB, x, y, bw, bh, col, 1)
sign(PB, -6010, 1570, "LOST LUGGAGE", "6D1F1F", "FFFFFF", wd=220, ht=36, front=4)
for x in (-6050, -5850):
    prop(PB, "Stripmall", "Room Reception/Hospital Bench", x, 900)
prop(PB, "Town", "Grocery Store/GroceryCart", -5600, 1010)
prop(PB, "Town", "Grocery Store/GroceryCart", -5520, 1000)
prop(PB, "Town", "Grocery Store/GroceryCart", -3700, 1130)
prop(PB, "Stripmall", "TrashCanTown (1)", -4720, 880)
prop(PB, "Town", "Town Hall/plantpotted_townhall", -6140, 880)
prop(PB, "Town", "Town Hall/plantpotted_townhall", -3660, 1250)
prop(PB, "Stripmall", "VendingMachine", -4250, 1420)
w('''
spot LostBag in "Baggage_Claim" at (-5200, 1190) {
    dialogue {
        if (!TookBag) {
            say "An unclaimed suitcase, going round and round all alone. Nobody is watching...";
            set TookBag;
            give Passport;
            give coins 50;
            say "Inside: a <item>Passport</item>, <price>50</price> coins and one very sad sock.";
            say "Customs is through the door at the bottom. A passport gets you <item>stamped</item>.";
        } else {
            say "Just a sad sock in here now.";
        }
    }
}
npc Baggage_Handler in "Baggage_Claim" at (-4450, 1230) {
    look { shirt = #FF8C00; pants = #2B2D42; }
    bubble = true;
    dialogue {
        if (BagJobDone) { say "Best temp I ever had. Wear that <item>Staff Badge</item> with pride."; end; }
        if (!BagJob) {
            say "I lost <shake>four hundred</shake> bags today. Personal best!";
            say "Three of them matter: a <item>red</item>, a <item>blue</item> and a <item>green</item> suitcase with big tags.";
            say "Red: by the <item>gate seats</item> upstairs. Blue: out on the <item>runway</item>. Green: in the <item>hangar</item>. Find all three and come back!";
            set BagJob;
            end;
        }
        if (BagA && BagB && BagC) {
            set BagJobDone;
            give coins 200;
            give StaffBadge;
            say "All three! Here's <price>200</price> coins and an honorary <item>Airport Staff Badge</item>.";
        } else {
            say "Still looking? Red: <item>gate seats</item>. Blue: <item>runway</item>. Green: <item>hangar</item>.";
        }
    }
}
npc Waiting_Tourist in "Baggage_Claim" at (-5750, 1130) {
    look { shirt = #B5838D; pants = #6D6875; }
    dialogue {
        say "My bag went to Cancun. I went to Zurich. We're growing apart.";
    }
}
''')

# ---------------------------------------------------------------- CUSTOMS   x -6600..-3600, y 807..1807
floor(PC, -6600, 807, 3000, 1000, "9AA0A8", 3)
floor(PC, -6600, 807, 3000, 443, "C3CAD1", 4)                        # past the gate
sign(PC, -5800, 1892, "CUSTOMS - DOUANES", "1D3557", "FFFFFF", wd=460, ht=60, front=14)
door_mat(PC, -5000, 1807, "BAGGAGE", up=True, bg="2A9D8F", fg="FFFFFF")
# the passport gate: a wall across the room with one gap, closed until you're stamped
wall_h(PC, -6600, -5160, 1250)
wall_h(PC, -4840, -3600, 1250)
wall_h(PC, -5160, -4840, 1250, "hideIf Stamped")
for x in (-5090, -5000, -4910):
    place(PC, ("Town", "Bank/rope front"), x, 1240, "hideIf Stamped")
rect(PC, -5172, 1325, 14, 150, "9AA5B1", 1)                          # gate posts + light
rect(PC, -4828, 1325, 14, 150, "9AA5B1", 1)
rect(PC, -5000, 1400, 358, 18, "9AA5B1", 1.2)
rect(PC, -5000, 1400, 44, 8, "2A9D8F", 1.4, "showIf Stamped")
rect(PC, -5000, 1400, 44, 8, "E63946", 1.4, "hideIf Stamped")
prop(PC, "Town", "Town Hall/townhall_counter", -5400, 1340)
prop(PC, "Town", "Town Hall/townhall_counter", -4600, 1340)
sign(PC, -5400, 1470, "PASSPORTS", "6D1F1F", "FFFFFF", wd=200, ht=40, front=2)
sign(PC, -4600, 1470, "PASSPORTS", "6D1F1F", "FFFFFF", wd=200, ht=40, front=2)
for x in (-5700, -4250):
    place(PC, ("Town", "Bank/rope front"), x, 1560)
    place(PC, ("Town", "Bank/rope front"), x + 80, 1560)
prop(PC, "Town", "Gas Station/gas_shelf_a", -6300, 1420)
sign(PC, -6300, 1520, "CONFISCATED", "3A3A3A", "FFD166", wd=220, ht=36, front=2)
prop(PC, "Town", "Town Hall/plantpotted_townhall", -6520, 1300)
prop(PC, "Town", "Town Hall/plantpotted_townhall", -3680, 1300)
# past the gate
door_mat(PC, -5500, 807, "VIP LOUNGE", up=False, bg="B8860B", fg="FFFFFF")
door_mat(PC, -3900, 807, "RUNWAY", up=False, bg="3A3A3A", fg="FFD166")
sign(PC, -5500, 1010, "VIP LOUNGE", "B8860B", "FFFFFF", wd=220, ht=40, front=2)
sign(PC, -3900, 1010, "STAFF ONLY - RUNWAY", "3A3A3A", "FFD166", wd=280, ht=40, front=2)
prop(PC, "Stripmall", "Room Reception/Hospital Bench", -4700, 900)
prop(PC, "Stripmall", "TrashCanTown (1)", -6500, 880)
w('''
npc Customs_Officer in "Customs" at (-4780, 1300) {
    look { shirt = #1D3557; pants = #14213D; }
    bubble = true;
    dialogue {
        if (has(SmuggledCheese)) {
            say "<shake>Sniff sniff.</shake> What is that smell?";
            choice {
                "It's my feet" => say "...Fair enough. You ARE a sasquatch. Carry on.";
                "It's definitely not cheese" => { take SmuggledCheese; say "It's <item>cheese</item>! Confiscated. Honestly."; }
            }
        }
        if (Stamped) { say "You're stamped. VIP Lounge on the left, runway on the right. Try not to chew anything."; end; }
        if (has(Passport)) {
            take Passport;
            say "Passport... hm. The photo looks <shake>nothing</shake> like you.";
            set Stamped;
            say "<shake>KA-CHUNK!</shake> Stamped anyway. The gate is open.";
        } else {
            say "Passport, please. No passport, no gate.";
            say "Lost yours? <item>Baggage Claim</item> is full of sad, unclaimed luggage. I didn't say that.";
        }
    }
}
npc Booth_Officer in "Customs" at (-5400, 1440) { look { shirt = #1D3557; pants = #14213D; } bubble = false; }
npc Nervous_Traveler in "Customs" at (-5750, 1450) {
    look { shirt = #E9C46A; pants = #264653; }
    bubble = true;
    dialogue {
        if (CheeseDone) { say "You're a legend. I'm down to thirty-seven cheeses."; end; }
        if (has(SmuggledCheese)) { say "Shh! Take it to the fancy guest in the <item>VIP Lounge</item>. Don't let customs smell it."; end; }
        say "I do NOT have forty cheeses in my bag.";
        say "...Thirty-nine. Listen. A guest in the <item>VIP Lounge</item> ordered one. Could you carry it through customs for me?";
        choice {
            "Sure, hand it over" => { set CheeseJob; give SmuggledCheese; say "It hums a little. That's normal. <shake>Act natural.</shake>"; }
            "Absolutely not" => say "Wise. Very wise.";
        }
    }
}
npc Welcome_Officer in "Customs" at (-4650, 1060) {
    look { shirt = #1D3557; pants = #14213D; }
    dialogue { say "Welcome to Canada. Again. You never actually left the building."; }
}
''')

# ---------------------------------------------------------------- VIP LOUNGE   x -5600..-3600, y 807..1607
floor(PV, -5600, 807, 2000, 800, "6B2737", 3)
floor(PV, -5600, 807, 2000, 30, "B8860B", 4)
floor(PV, -4850, 1000, 500, 300, "8A3447", 4)                        # a rug
sign(PV, -4130, 1692, "VIP LOUNGE", "B8860B", "FFFFFF", wd=300, ht=56, front=14)
door_mat(PV, -4600, 1607, "CUSTOMS", up=True, bg="B8860B", fg="FFFFFF")
place(PV, GLASS, -4330, 1610, "scale (0.95, 1)", "front 4")
rect(PV, -5250, 1700, 330, 110, "2B2D42", 12)                        # the TV on the back wall
rect(PV, -5250, 1700, 310, 92, "1D3557", 12.5)
text(PV, -5250, 1692, "SASQUATCH NEWS", "FFFFFF", sx=1.9, sy=1.1, front=13)
prop(PV, "Town", "Coffee Shop/Front Counter", -5250, 1300)
prop(PV, "Town", "Coffee Shop/Fridge", -5500, 1390)
sign(PV, -5250, 1500, "FREE BAR", "2E7D4F", "FFFFFF", wd=180, ht=36, front=2)
prop(PV, "Town", "Diner/SeatsTable_Diner", -5350, 950)
prop(PV, "Town", "Diner/SeatsTable_Diner", -5150, 950)
for x in (-4150, -3750):
    for y in (1000, 1200):
        prop(PV, "Town", "Town Hall/BlackCouch", x, y, "flip" if x == -3750 else "")
prop(PV, "Town", "Coffee Shop/CoffeeTableHigh", -3950, 1060)
prop(PV, "Town", "Gas Station/gas_shelf_a", -3990, 1440)
prop(PV, "Town", "Gas Station/gas_shelf_a", -3760, 1440)
sign(PV, -3875, 1540, "BUFFET", "2E7D4F", "FFFFFF", wd=160, ht=36, front=2)
prop(PV, "Town", "Town Hall/plantpotted_townhall", -5540, 880)
prop(PV, "Town", "Town Hall/plantpotted_townhall", -3660, 880)
w('''
npc Bartender in "VIP_Lounge" at (-5250, 1420) { look { shirt = #F1FAEE; pants = #14213D; } bubble = false; }
spot Free_Bar in "VIP_Lounge" at (-5250, 1200) {
    dialogue {
        say "Welcome to the <item>VIP Lounge</item>! Everything is free and nobody checks who you are.";
        choice {
            "A mini quiche, please" => { give MiniQuiche; say "Take six. The guy in the corner won't notice."; }
            "A free latte" => { give MapleLatte; say "On the house. Out there it's 55 coins. Heh."; }
            "Any gossip?" => say "The control tower is bored. Somebody might pay you to help with the radar.";
            "Nothing" => say "Enjoy the lounge!";
        }
    }
}
spot Buffet in "VIP_Lounge" at (-3875, 1340) {
    dialogue {
        if (!LoungeSnack) {
            set LoungeSnack;
            give coins 100;
            give MiniQuiche 3;
            say "You 'accidentally' fill your pockets. A tip jar under the quiches holds <price>100</price> coins. Finders keepers.";
        } else {
            say "The quiches are gone. You look around nervously.";
        }
    }
}
npc Fancy_Guest in "VIP_Lounge" at (-3950, 930) {
    look { shirt = #2B2D42; pants = #2B2D42; }
    bubble = true;
    dialogue {
        if (has(SmuggledCheese)) {
            take SmuggledCheese;
            set CheeseDone;
            give coins 120;
            give MiniQuiche 2;
            say "My cheese! It's still humming. <shake>Divine.</shake>";
            say "Here's <price>120</price> coins and some quiches. You were never here.";
            end;
        }
        say "I've been in this lounge for three days. My flight left on Tuesday.";
        say "Don't tell them. The quiches are too good.";
    }
}
''')

# ---------------------------------------------------------------- RUNWAY   x -6600..-3600, y 807..1907
floor(PR, -6600, 807, 3000, 1100, "2B2D31", 3)
floor(PR, -6600, 1400, 3000, 507, "3A3D42", 4)                       # the apron
floor(PR, -6600, 1392, 3000, 10, "FFD166", 5)
rect(PR, -5100, 900, 2900, 10, "F1FAEE", 1)
rect(PR, -5100, 1340, 2900, 10, "F1FAEE", 1)
for i in range(10):
    rect(PR, -6400 + i * 290, 1120, 160, 12, "F1FAEE", 1)
text(PR, -6350, 1000, "09", "F1FAEE", sx=2.6, front=1)
jet(PR, -5100, 1640, "E63946")
jet(PR, -4450, 1120, "1D7CF2")
door_mat(PR, -3900, 1907, "CUSTOMS", up=True, bg="2A9D8F", fg="FFFFFF")
door_mat(PR, -6200, 1907, "TOWER", up=True)
door_mat(PR, -5200, 807, "HANGAR", up=False, bg="F77F00", fg="FFFFFF")
prop(PR, "Town", "Grocery Store/GroceryCart", -4300, 1560)
prop(PR, "Town", "Grocery Store/GroceryCart", -4220, 1570)
rect(PR, -5850, 1500, 14, 44, "FF8C00", 1)                            # marshalling wands on the ground
rect(PR, -5820, 1500, 14, 44, "FF8C00", 1)
w('''
npc Ground_Crew_A in "Runway" at (-5950, 1560) {
    look { shirt = #FF8C00; pants = #2B2D42; }
    bubble = true;
    dialogue { say "Careful, sasquatch. These planes have no brakes for bigfoot."; say "Why are you on the runway? Never mind. I don't get paid enough to ask."; }
}
npc Ground_Crew_B in "Runway" at (-4050, 1500) {
    look { shirt = #FF8C00; pants = #2B2D42; }
    bubble = true;
    dialogue { say "I wave glowing sticks all day. Best job in the world."; say "The control tower is at the far end. They love visitors. Nobody visits."; }
}
spot Wands in "Runway" at (-5835, 1430) {
    dialogue {
        if (!Marshalled) {
            say "Two glowing <item>marshalling wands</item>. You pick them up and wave confidently.";
            say "A jet turns left, then right, then gives up and parks. <shake>Perfect.</shake>";
            set Marshalled;
            give coins 40;
            say "The ground crew tips you <price>40</price> coins. 'Never do that again.'";
        } else {
            say "The wands have been taken away from you. Fair.";
        }
    }
}
spot Parked_Jet in "Runway" at (-5100, 1460) {
    dialogue { say "A parked <item>Sasquatch Air</item> jet. You consider sneaking aboard."; say "Then you remember the cargo hold has no snacks."; }
}
''')

# ---------------------------------------------------------------- CONTROL TOWER   x -5000..-3600, y 807..2207
floor(PT, -5000, 807, 1400, 1400, "56606B", 3)
floor(PT, -4650, 1100, 700, 600, "3D4650", 4)
door_mat(PT, -4300, 807, "RUNWAY", up=False)
rect(PT, -4300, 2292, 1320, 96, "A8DADC", 12)                         # the big windows
for i in range(11):
    rect(PT, -4950 + i * 130, 2292, 8, 96, "2B2D42", 13)
rect(PT, -4050, 2300, 120, 16, "F8F9FA", 12.6)                        # a jet far away
rect(PT, -4080, 2308, 30, 26, "1D4E89", 12.6)
sign(PT, -4300, 2140, "CONTROL TOWER", "1D3557", "FFFFFF", wd=440, ht=60, front=2)
for x in (-4650, -3950):
    prop(PT, "Town", "Town Hall/townhall_counter", x, 1850)
    rect(PT, x, 1965, 190, 110, "0B3D0B", 2)
    rect(PT, x, 1965, 6, 96, "39FF14", 2.5)
    rect(PT, x, 1965, 150, 4, "1F7A1F", 2.4)
    text(PT, x, 2032, "RADAR", "39FF14", sx=0.9, front=4)
rect(PT, -3950, 1905, 30, 22, "E63946", 5)                            # the red button
prop(PT, "Town", "Town Hall/plantpotted_townhall", -4940, 880)
prop(PT, "Town", "Town Hall/plantpotted_townhall", -3660, 880)
prop(PT, "Stripmall", "Room Reception/Watercooler", -4900, 1500)
w('''
npc Controller in "Control_Tower" at (-4300, 1900) {
    look { shirt = #F1FAEE; pants = #2B2D42; }
    bubble = true;
    dialogue {
        if (TowerChainDone) { say "The tower has never run smoother. Well. It has. But thanks."; end; }
        if (TowerDone && PADone && RunwayLights) {
            set TowerChainDone;
            give coins 200;
            give TowerTrophy;
            say "Radar, announcement AND runway lights? You're hired. Unofficially.";
            say "Here's <price>200</price> coins and a <item>Junior Controller Trophy</item>.";
            end;
        }
        say "Shh. I'm guiding a hundred planes. Want to help? Three jobs:";
        if (TowerDone) say "1. Radar: done."; else say "1. Check the <item>left radar desk</item>.";
        if (PADone) say "2. Announcement: done."; else say "2. Say something on the <item>microphone</item> behind you.";
        if (RunwayLights) say "3. Runway lights: on."; else say "3. Flip the <item>runway light switch</item>, in the bottom-left corner of the runway.";
    }
}
spot Radar_Desk in "Control_Tower" at (-4650, 1740) {
    dialogue {
        if (!TowerDone) {
            say "Blip... blip... a suspicious blip labelled <item>BIGFOOT</item> is heading straight for the tower.";
            say "You grab the radio: 'All planes, please ignore the sasquatch.'";
            set TowerDone;
            give coins 150;
            say "The airline sends you <price>150</price> coins for excellent air traffic control.";
        } else {
            say "All quiet. Every plane is safe from you. For now.";
        }
    }
}
spot Red_Button in "Control_Tower" at (-3950, 1740) {
    dialogue {
        say "A big red button. A sticky note says <shake>DO NOT PRESS</shake>.";
        choice {
            "Press it" => { say "Every light on the runway turns pink."; say "Somewhere far away, a pilot says 'huh'."; }
            "Leave it" => say "Probably wise.";
        }
    }
}
npc Trainee in "Control_Tower" at (-3780, 1450) {
    look { shirt = #8ECAE6; pants = #2B2D42; }
    dialogue { say "I pressed the red button once. We don't talk about it."; }
}
''')
w("")

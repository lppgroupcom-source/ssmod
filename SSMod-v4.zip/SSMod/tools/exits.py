"""List the exits (AreaExitTrigger) of scenes: id, position, target scene."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ssmodlang.game import load, Catalog, script_name, world_position, transform_of
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IDS = {0: "Main", 1: "North", 2: "South", 3: "East", 4: "West", 11: "NorthAlt", 12: "SouthAlt", 13: "EastAlt", 14: "WestAlt"}
cat = Catalog(os.path.join(HERE, "base"), os.path.join(HERE, "catalog_cache.json"))
_ld = {}
def ld_name(f, pp):
    try:
        return pp.read().m_Name if hasattr(pp, "read") else "?"
    except Exception:
        return "?"
for scene in sys.argv[1:]:
    level = cat.scene_file(scene, None, None)
    src = os.path.join(HERE, "base", level)
    env, f = load(level, src=src if os.path.exists(src) else None)
    print(f"== {scene} ({level})")
    for p, o in f.objects.items():
        if o.type.name == "MonoBehaviour" and script_name(env, f, o) == "AreaExitTrigger":
            r = o.read()
            t = o.read_typetree()
            go = f.objects[t["m_GameObject"]["m_PathID"]].read()
            x, y, _ = world_position(f, transform_of(f, go).path_id)
            tl = t["targetLevel"]
            name = "-"
            if tl["m_PathID"]:
                try:
                    name = r.targetLevel.read().m_Name
                except Exception:
                    name = f"#{tl['m_PathID']}"
            print(f"  {IDS.get(t['id'], t['id']):9} ({x:.0f}, {y:.0f})  -> {name} [{IDS.get(t['targetID'], t['targetID'])}]  active={go.m_IsActive}  '{go.m_Name}'")

"""Check every ssmod dialogue / script graph in the installed game (see ssmodlang/validate.py).

    python3 tools/validate_graphs.py        (also runs by itself after ./ssmod install, and in ./ssmod doctor)
"""
import collections
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ssmodlang.validate import validate  # noqa: E402

n, bad = validate()
if n is None:
    sys.exit(bad)
print("ssmod graphs scanned:", n)
for nm in sorted(bad):
    print("--", nm)
    for k, v in collections.Counter(bad[nm]).items():
        print(f"     {v}x {k}")
sys.exit(1 if bad else 0)

#!/bin/zsh
# Double-click to build and install every mod in SSMod/mods/ into your game copy.
cd "$(dirname "$0")"
if [[ -x .venv/bin/python3 ]]; then .venv/bin/python3 ./ssmod install; else ./ssmod install; fi
echo
read -k1 "?Press any key to close..."

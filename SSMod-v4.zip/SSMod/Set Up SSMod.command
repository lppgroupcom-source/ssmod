#!/bin/zsh
# Set Up SSMod: double-click once. It gets SSMod ready on this Mac and installs the mods in mods/.
#
#   1. finds Python 3 (on a fresh Mac, macOS offers to install the Command Line Tools: click Install, then run this again)
#   2. installs UnityPy into SSMod/.venv (only SSMod uses it; nothing system-wide changes)
#   3. asks for YOUR COPY of Sneaky Sasquatch (never the one in Applications)
#   4. backs up your saves and installs the mods (ssmod install)
#
# Works on macOS 13 and later, including macOS Tahoe 26, with game versions 2.1.9 and 2.2.
# It never touches the Apple Arcade check, the app's signature or the copy in /Applications.
cd "$(dirname "$0")" || exit 1
SSMOD_DIR="$PWD"
chmod +x ssmod "Install Mods.command" 2>/dev/null

say_step() { print -P "\n%B== $1%b"; }
finish() { echo; read -k1 "?Press any key to close..."; exit "${1:-0}"; }

# ---------------------------------------------------------------- 1. Python
say_step "1/4  Python"
PY=""
for p in /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/bin/python3; do
  if [[ -x "$p" ]] && "$p" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' 2>/dev/null; then
    PY="$p"; break
  fi
done
if [[ -z "$PY" ]]; then
  echo "Python 3 isn't installed yet."
  echo "macOS will now offer to install the Command Line Tools (from Apple). Click Install, wait for it to finish,"
  echo "then double-click \"Set Up SSMod.command\" again."
  xcode-select --install 2>/dev/null
  finish 1
fi
echo "Using $("$PY" -V) at $PY"

# ---------------------------------------------------------------- 2. UnityPy
say_step "2/4  UnityPy (the library that reads Unity game files)"
if [[ ! -x .venv/bin/python3 ]] || ! .venv/bin/python3 -c 'import UnityPy, TypeTreeGeneratorAPI' 2>/dev/null; then
  rm -rf .venv
  "$PY" -m venv .venv || { echo "Couldn't make SSMod/.venv"; finish 1; }
  .venv/bin/python3 -m pip install --quiet --upgrade pip
  .venv/bin/python3 -m pip install --quiet "UnityPy[ttgen]==1.25.3" pillow || { echo "Installing UnityPy failed (are you online?)"; finish 1; }
fi
echo "UnityPy $(.venv/bin/python3 -c 'import UnityPy; print(UnityPy.__version__)') is ready."

# ---------------------------------------------------------------- 3. the game copy
say_step "3/4  Your copy of Sneaky Sasquatch"
GAME=""
if [[ -f ssmod.json ]]; then
  GAME="$(.venv/bin/python3 -c 'import json; print(json.load(open("ssmod.json")).get("game", ""))' 2>/dev/null)"
  [[ -d "$GAME" ]] && echo "Last time you used: $GAME" && read -q "?Use it again? (y/n) " && echo || GAME=""
  echo
fi
while [[ -z "$GAME" ]]; do
  cat <<'EOF'
SSMod changes a COPY of the game, so the real one stays untouched. To make the copy:
  1. In Finder, make a folder, e.g. Downloads/Sasquatch Modded
  2. Open Applications, hold Option and drag Sneaky Sasquatch into that folder (Option = copy, not move)
  3. Drag the copied app from that folder into this Terminal window and press Return
EOF
  read -r "?Game copy: " GAME
  # a dragged path comes with backslash-escaped spaces and a trailing space
  GAME="$(print -r -- "$GAME" | sed -e 's/\\\(.\)/\1/g' -e 's/^ *//' -e 's/ *$//' -e "s/^'//" -e "s/'$//" -e 's:/$::')"
  if [[ ! -d "$GAME/Contents/Resources/Data" ]]; then
    echo "That isn't the game app. Try again."; GAME=""; continue
  fi
  if [[ "$GAME" == /Applications/* ]]; then
    echo "That's the one in Applications. Please use a copy (step 2 above)."; GAME=""; continue
  fi
  BID="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$GAME/Contents/Info.plist" 2>/dev/null)"
  if [[ "$BID" != com.rac7.SneakySasquatch* ]]; then
    echo "That app isn't Sneaky Sasquatch ($BID). Try again."; GAME=""; continue
  fi
done
VER="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$GAME/Contents/Info.plist" 2>/dev/null)"
echo "Game copy: $GAME (version $VER)"
[[ "$VER" != "2.1.9" && "$VER" != "2.2" ]] && echo "Note: SSMod was tested with 2.1.9 and 2.2. It finds what it needs by name, so it will tell you if this version is missing anything."
.venv/bin/python3 - "$GAME" <<'EOF'
import json, os, sys
p = "ssmod.json"
c = json.load(open(p)) if os.path.exists(p) else {}
c["game"] = sys.argv[1]
json.dump(c, open(p, "w"), indent=2)
EOF

# macOS 13+ (and Tahoe 26) protect apps from being changed by other programs ("App Management")
TEST="$GAME/Contents/Resources/Data/.ssmod_write_test"
if ! ( : > "$TEST" ) 2>/dev/null; then
  cat <<'EOF'

macOS blocked Terminal from changing the game copy. To allow it:
  System Settings > Privacy & Security > App Management > turn on Terminal
  (macOS may ask you to quit and reopen Terminal). Then double-click "Set Up SSMod.command" again.
EOF
  open "x-apple.systempreferences:com.apple.preference.security?Privacy_AppBundles" 2>/dev/null
  finish 1
fi
rm -f "$TEST"

# ---------------------------------------------------------------- 4. install
say_step "4/4  Installing the mods"
echo "Close the game first. If macOS asks whether Terminal may access data from other apps, click Allow:"
echo "that's SSMod backing up your saves before it changes anything."
.venv/bin/python3 ./ssmod install
STATUS=$?
if [[ $STATUS -eq 0 ]]; then
  echo
  echo "Done. Open the game COPY (not the one in Applications) to play with mods."
  echo "Later: put .ssmod files in mods/ and double-click \"Install Mods.command\". Undo everything: ./ssmod uninstall"
fi
finish $STATUS

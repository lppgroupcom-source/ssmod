"""Check every ssmod NodeCanvas graph in an installed game against the decompiled task classes.

A field whose C# type is a UnityEngine.Object must be written as an index into _objectReferences; writing {}
there makes FullSerializer throw and the whole graph is lost (the dialogue then shows nothing and the player is
stuck). Also flags fields that don't exist and BBParameters that aren't objects.
"""
import collections
import json
import os
import re

from .config import decompiled_sources, game_data

FIELD = re.compile(r'^\s*public\s+([A-Za-z0-9_\.<>,\[\] ]+?)\s+([A-Za-z_][A-Za-z0-9_]*)\s*;')


class _Classes:
    def __init__(self, src):
        self.src, self._fields, self._uo = src, {}, {}

    def fields(self, cls):
        if cls not in self._fields:
            p = os.path.join(self.src, cls + ".cs")
            out = None
            if os.path.exists(p):
                out = {}
                for line in open(p, errors="ignore"):
                    m = FIELD.match(line)
                    if m:
                        out[m.group(2)] = m.group(1).strip()
            self._fields[cls] = out
        return self._fields[cls]

    def is_unity_object(self, t):
        t = t.strip()
        if t not in self._uo:
            r = False
            if not (t.startswith(("BBParameter", "List", "System.")) or t in ("int", "float", "bool", "string")):
                base = t.split(".")[0]
                p = os.path.join(self.src, base + ".cs")
                if os.path.exists(p):
                    head = open(p, errors="ignore").read(4000)
                    r = bool(re.search(r'class\s+' + re.escape(base) + r'\s*:\s*\w*(ScriptableObject|MonoBehaviour|Data\b)', head))
            self._uo[t] = r
        return self._uo[t]


def validate(data_dir=None):
    """Returns (graphs scanned, {graph name: [problems]}), or (None, reason) when it can't run here."""
    src = decompiled_sources()
    if not src:
        return None, "the decompiled game classes aren't on this machine, so graphs can't be checked"
    from .game import load
    classes = _Classes(src)
    env, f = load("resources.assets", src=os.path.join(data_dir or game_data(), "resources.assets"))
    bad = collections.defaultdict(list)

    def walk(o, name):
        if isinstance(o, dict):
            t = o.get("$type")
            if isinstance(t, str) and "." not in t:
                fl = classes.fields(t)
                if fl is not None:
                    for k, v in o.items():
                        if k == "$type":
                            continue
                        if k not in fl:
                            bad[name].append(f"{t}.{k}: the game has no such field")
                        elif classes.is_unity_object(fl[k]) and isinstance(v, dict):
                            bad[name].append(f"{t}.{k} ({fl[k]}) is written as {{}} but must be an object index")
                        elif fl[k].startswith("BBParameter") and not isinstance(v, dict):
                            bad[name].append(f"{t}.{k} ({fl[k]}) must be an object, not {type(v).__name__}")
            for v in o.values():
                walk(v, name)
        elif isinstance(o, list):
            for v in o:
                walk(v, name)

    n = 0
    for _, o in f.objects.items():
        if o.type.name != "MonoBehaviour":
            continue
        try:
            t = o.read_typetree()
        except Exception:
            continue
        nm = t.get("m_Name", "")
        g = t.get("_serializedGraph")
        if "ssmod" not in nm or not isinstance(g, str) or len(g) < 20:
            continue
        n += 1
        try:
            walk(json.loads(g), nm)
        except ValueError as e:
            bad[nm].append("not valid JSON: " + str(e))
    return n, dict(bad)

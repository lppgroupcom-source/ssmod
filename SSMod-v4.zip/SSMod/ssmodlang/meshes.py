"""Custom meshes: turn polygons (or a simple SVG file) into triangles the game can draw.

The game's flat shapes are Sprites with their own vertex and index buffers and no texture (the white square the
`box` shorthand uses is one: 4 vertices, 2 triangles, coloured by its SpriteRenderer). A custom mesh is the same
thing with our own triangles: one sprite per colour, stacked in drawing order.
"""
import math
import os
import re
import struct
import xml.etree.ElementTree as ET

MAX_VERTS = 65000            # the index buffer is 16-bit


class MeshError(Exception):
    pass


# ---------------------------------------------------------------- triangulation (ear clipping)
def _area2(p):
    return sum(p[i][0] * p[(i + 1) % len(p)][1] - p[(i + 1) % len(p)][0] * p[i][1] for i in range(len(p)))


def _cross(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _inside(p, a, b, c):
    return _cross(a, b, p) >= 0 and _cross(b, c, p) >= 0 and _cross(c, a, p) >= 0


def triangulate(points):
    """Triangles (index triples into `points`) of a simple polygon; concave is fine, self-crossing is not."""
    pts = [tuple(map(float, p)) for p in points]
    clean = []                                       # drop repeated points (and a closing point equal to the first)
    for p in pts:
        if not clean or (abs(p[0] - clean[-1][0]) > 1e-6 or abs(p[1] - clean[-1][1]) > 1e-6):
            clean.append(p)
    if len(clean) > 1 and abs(clean[0][0] - clean[-1][0]) < 1e-6 and abs(clean[0][1] - clean[-1][1]) < 1e-6:
        clean.pop()
    if len(clean) < 3:
        raise MeshError("a polygon needs at least 3 different points")
    n = len(clean)
    if n <= 1500:                                     # edges that cross each other = a bow-tie, not a shape
        for i in range(n):
            a1, a2 = clean[i], clean[(i + 1) % n]
            for j in range(i + 2, n):
                if i == 0 and j == n - 1:
                    continue                          # neighbours share a corner
                b1, b2 = clean[j], clean[(j + 1) % n]
                if (_cross(a1, a2, b1) * _cross(a1, a2, b2) < -1e-9 and _cross(b1, b2, a1) * _cross(b1, b2, a2) < -1e-9):
                    raise MeshError(f"this polygon crosses itself: the edge after point {i + 1} cuts the edge after "
                                    f"point {j + 1}. List the points in order around the outline.")
    order = list(range(len(clean)))
    if _area2(clean) < 0:
        order.reverse()                               # work counter-clockwise
    tris, guard = [], 0
    while len(order) > 3:
        n, cut = len(order), False
        for k in range(n):
            i0, i1, i2 = order[k - 1], order[k], order[(k + 1) % n]
            a, b, c = clean[i0], clean[i1], clean[i2]
            if _cross(a, b, c) <= 1e-9:
                continue                              # reflex or flat corner: not an ear
            if any(_inside(clean[j], a, b, c) for j in order if j not in (i0, i1, i2)):
                continue
            tris.append((i0, i1, i2))
            order.pop(k)
            cut = True
            break
        if not cut:
            flat = [k for k in range(len(order)) if abs(_cross(clean[order[k - 1]], clean[order[k]], clean[order[(k + 1) % len(order)]])) <= 1e-9]
            if not flat:
                raise MeshError("this polygon crosses itself (or its points are out of order)")
            order.pop(flat[0])                        # a point on a straight edge adds nothing
        guard += 1
        if guard > 200000:
            raise MeshError("polygon too complicated")
    if len(order) == 3 and abs(_cross(clean[order[0]], clean[order[1]], clean[order[2]])) > 1e-9:
        tris.append(tuple(order))
    return clean, tris


def circle(cx, cy, r, steps=None):
    steps = steps or max(12, min(64, int(abs(r) / 2.5) + 12))
    return [(cx + r * math.cos(2 * math.pi * k / steps), cy + r * math.sin(2 * math.pi * k / steps)) for k in range(steps)]


def rect(x, y, w, h):
    return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]


def build_parts(shapes):
    """[(colour, [points])] in drawing order -> [(colour, vertices, indices)], one part per run of one colour."""
    parts = []
    for colour, pts in shapes:
        verts, tris = triangulate(pts)
        if not tris:
            continue
        if parts and parts[-1][0] == colour and len(parts[-1][1]) + len(verts) <= MAX_VERTS:
            base = len(parts[-1][1])
            parts[-1][1].extend(verts)
            parts[-1][2].extend(i + base for t in tris for i in t)
        else:
            parts.append((colour, list(verts), [i for t in tris for i in t]))
    if not parts:
        raise MeshError("the mesh has no shapes with any area")
    for _, verts, _ in parts:
        if len(verts) > MAX_VERTS:
            raise MeshError(f"one colour has {len(verts)} points; the limit is {MAX_VERTS}")
    return parts


def bounds(parts):
    xs = [v[0] for _, verts, _ in parts for v in verts]
    ys = [v[1] for _, verts, _ in parts for v in verts]
    return min(xs), min(ys), max(xs), max(ys)


def sprite_buffers(verts, indices, cx, cy, uv=(0.0, 0.0)):
    """(vertex bytes, index bytes) in the white square's layout: stream 0 = xyz floats, stream 1 = uv floats.
    Every vertex gets the same uv: one white texel, so the shape is a flat colour."""
    pos = b"".join(struct.pack("<3f", x - cx, y - cy, 0.0) for x, y in verts)
    pos += b"\0" * (-len(pos) % 16)
    uv = struct.pack("<2f", *uv) * len(verts)
    return pos + uv, struct.pack(f"<{len(indices)}H", *indices)


# ---------------------------------------------------------------- SVG (filled shapes only)
NAMED = {"black": "000000", "white": "FFFFFF", "red": "FF0000", "green": "008000", "blue": "0000FF", "yellow": "FFFF00",
         "orange": "FFA500", "purple": "800080", "pink": "FFC0CB", "brown": "A52A2A", "gray": "808080", "grey": "808080",
         "cyan": "00FFFF", "magenta": "FF00FF", "lime": "00FF00", "navy": "000080", "teal": "008080", "gold": "FFD700"}
_NUM = r"[-+]?(?:\d*\.\d+|\d+\.?)(?:[eE][-+]?\d+)?"


def _colour(v):
    v = (v or "").strip().lower()
    if not v or v == "none" or v.startswith("url"):
        return None
    if v.startswith("#"):
        h = v[1:]
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return h[:6].upper() if len(h) >= 6 else None
    m = re.match(r"rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)", v)
    if m:
        return "%02X%02X%02X" % tuple(min(255, int(g)) for g in m.groups())
    return NAMED.get(v)


def _mul(a, b):
    return (a[0] * b[0] + a[2] * b[1], a[1] * b[0] + a[3] * b[1], a[0] * b[2] + a[2] * b[3], a[1] * b[2] + a[3] * b[3],
            a[0] * b[4] + a[2] * b[5] + a[4], a[1] * b[4] + a[3] * b[5] + a[5])


def _transform(s):
    m = (1, 0, 0, 1, 0, 0)
    for name, args in re.findall(r"(\w+)\s*\(([^)]*)\)", s or ""):
        v = [float(x) for x in re.findall(_NUM, args)]
        if name == "translate":
            t = (1, 0, 0, 1, v[0], v[1] if len(v) > 1 else 0)
        elif name == "scale":
            t = (v[0], 0, 0, v[1] if len(v) > 1 else v[0], 0, 0)
        elif name == "rotate":
            a = math.radians(v[0]); c, sn = math.cos(a), math.sin(a)
            t = (c, sn, -sn, c, 0, 0)
            if len(v) == 3:
                t = _mul(_mul((1, 0, 0, 1, v[1], v[2]), t), (1, 0, 0, 1, -v[1], -v[2]))
        elif name == "matrix" and len(v) == 6:
            t = tuple(v)
        else:
            continue
        m = _mul(m, t)
    return m


def _path(d):
    """Sub-paths of an SVG path as point lists (curves flattened, arcs drawn as straight lines)."""
    toks = re.findall(r"[MmLlHhVvCcSsQqTtAaZz]|" + _NUM, d)
    subs, cur, i, cmd = [], [], 0, None
    x = y = sx = sy = 0.0
    last_c = None

    def num():
        nonlocal i
        v = float(toks[i]); i += 1
        return v

    def curve(p0, p1, p2, p3, n=10):
        for k in range(1, n + 1):
            t = k / n
            u = 1 - t
            cur.append((u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
                        u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]))
    while i < len(toks):
        if re.fullmatch(r"[A-Za-z]", toks[i]):
            cmd = toks[i]; i += 1
            if cmd in "Zz":
                if cur:
                    subs.append(cur)
                cur, x, y, last_c = [], sx, sy, None
                continue
        rel = cmd.islower()
        c = cmd.upper()
        if c == "M":
            if cur:
                subs.append(cur)
            x, y = (x + num(), y + num()) if rel else (num(), num())
            sx, sy, cur = x, y, [(x, y)]
            cmd = "l" if rel else "L"
        elif c == "L":
            x, y = (x + num(), y + num()) if rel else (num(), num()); cur.append((x, y))
        elif c == "H":
            x = x + num() if rel else num(); cur.append((x, y))
        elif c == "V":
            y = y + num() if rel else num(); cur.append((x, y))
        elif c in "CS":
            if c == "C":
                x1, y1 = num(), num()
                if rel: x1, y1 = x + x1, y + y1
            else:
                x1, y1 = (2 * x - last_c[0], 2 * y - last_c[1]) if last_c else (x, y)
            x2, y2, x3, y3 = num(), num(), num(), num()
            if rel: x2, y2, x3, y3 = x + x2, y + y2, x + x3, y + y3
            curve((x, y), (x1, y1), (x2, y2), (x3, y3))
            last_c, x, y = (x2, y2), x3, y3
            continue
        elif c in "QT":
            if c == "Q":
                x1, y1 = num(), num()
                if rel: x1, y1 = x + x1, y + y1
            else:
                x1, y1 = (2 * x - last_c[0], 2 * y - last_c[1]) if last_c else (x, y)
            x3, y3 = num(), num()
            if rel: x3, y3 = x + x3, y + y3
            curve((x, y), (x + 2 / 3 * (x1 - x), y + 2 / 3 * (y1 - y)), (x3 + 2 / 3 * (x1 - x3), y3 + 2 / 3 * (y1 - y3)), (x3, y3))
            last_c, x, y = (x1, y1), x3, y3
            continue
        elif c == "A":
            for _ in range(5):
                num()
            x, y = (x + num(), y + num()) if rel else (num(), num()); cur.append((x, y))
        else:
            raise MeshError(f"unsupported SVG path command '{cmd}'")
        last_c = None
    if cur:
        subs.append(cur)
    return subs


def load_svg(path, scale=1.0):
    """Filled shapes of an SVG as [(colour, points)], centred on the drawing and with y pointing up."""
    try:
        root = ET.parse(path).getroot()
    except (OSError, ET.ParseError) as e:
        raise MeshError(f"can't read {os.path.basename(path)}: {e}")
    shapes = []

    def style_of(el, inherited):
        st = dict(inherited)
        for part in (el.get("style") or "").split(";"):
            if ":" in part:
                k, v = part.split(":", 1)
                st[k.strip()] = v.strip()
        for k in ("fill", "display", "visibility"):
            if el.get(k) is not None:
                st[k] = el.get(k)
        return st

    def walk(el, m, st):
        tag = el.tag.split("}")[-1]
        if tag in ("defs", "clipPath", "mask", "symbol", "metadata", "title", "desc", "style"):
            return
        st = style_of(el, st)
        m = _mul(m, _transform(el.get("transform")))
        if st.get("display") == "none" or st.get("visibility") == "hidden":
            return
        f = lambda k, d=0.0: float(re.findall(_NUM, el.get(k) or str(d))[0])   # noqa: E731
        polys = []
        if tag == "rect":
            polys = [rect(f("x"), f("y"), f("width"), f("height"))]
        elif tag == "circle":
            polys = [circle(f("cx"), f("cy"), f("r"))]
        elif tag == "ellipse":
            rx, ry = f("rx"), f("ry")
            polys = [[(f("cx") + rx * math.cos(a), f("cy") + ry * math.sin(a)) for a in (2 * math.pi * k / 32 for k in range(32))]]
        elif tag in ("polygon", "polyline"):
            v = [float(n) for n in re.findall(_NUM, el.get("points") or "")]
            polys = [list(zip(v[0::2], v[1::2]))]
        elif tag == "path":
            polys = _path(el.get("d") or "")
        col = _colour(st.get("fill", "#000000"))
        if col:
            for p in polys:
                if len(p) >= 3:
                    shapes.append((col, [(m[0] * x + m[2] * y + m[4], m[1] * x + m[3] * y + m[5]) for x, y in p]))
        for ch in el:
            walk(ch, m, st)

    walk(root, (1, 0, 0, 1, 0, 0), {})
    if not shapes:
        raise MeshError(f"{os.path.basename(path)} has no filled shapes (only fills are imported: no strokes, text or images)")
    xs = [x for _, p in shapes for x, _ in p]
    ys = [y for _, p in shapes for _, y in p]
    cx, cy = (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
    return [(c, [((x - cx) * scale, (cy - y) * scale) for x, y in p]) for c, p in shapes]

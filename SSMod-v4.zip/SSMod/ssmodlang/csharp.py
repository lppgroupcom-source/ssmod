"""Mods written in C#: a .cs file is translated into SSMod's own language and built exactly like a .ssmod file.

It's real C# syntax (classes, attributes, methods, var/int/float/bool/string, if/else, while, for, ++, properties,
new Vector3(...), operators on positions), but not compiled C#: the game can't run new code, so only what SSMod can
turn into the game's own scripts is allowed, and anything else is an error that points at your line. Every piece of
output is put on the same line number as the C# it came from, so errors from the rest of SSMod point there too.

    [Mod("Hello", Author = "Me", Version = "1.0")]
    public class Hello : Mod {
        bool Waved;                                            // a flag (saved with the game)
        [Sound("sounds/whistle.wav")] Sound Whistle;
        [Hud("Town", 0, 200, Color = "#FFFFFF")] Text Msg = "";

        [OnKey("h", "Town")]
        void Wave() {
            Whistle.Play();
            Msg.text = "Hello!";
            Waved = true;
        }
    }
"""
import re

from .syntax import SSModError, Tok
from . import calls

# ------------------------------------------------------------------------------------------------ tokens
SYMS = ["==", "!=", "<=", ">=", "&&", "||", "+=", "-=", "*=", "/=", "++", "--", "=>", "??"]
PRIM = {"float": "System.Single", "double": "System.Single", "int": "System.Int32", "long": "System.Int32",
        "bool": "System.Boolean", "string": "System.String", "Vector2": "UnityEngine.Vector2",
        "Vector3": "UnityEngine.Vector3"}
NUM = ("System.Single", "System.Int32")
VEC = ("UnityEngine.Vector2", "UnityEngine.Vector3")
PY = {"System.Single": "0.0", "System.Int32": "0", "System.Boolean": "false", "System.String": '""'}


class T:
    __slots__ = ("kind", "value", "line", "col")

    def __init__(self, kind, value, line, col):
        self.kind, self.value, self.line, self.col = kind, value, line, col

    def __repr__(self):
        return f"{self.kind}:{self.value!r}@{self.line}"


def lex(src, path):
    out, i, line, col, n = [], 0, 1, 1, len(src)

    def err(msg):
        raise SSModError(msg, Tok("sym", "", line, col), path)

    while i < n:
        c = src[i]
        if c == "\n":
            i, line, col = i + 1, line + 1, 1
            continue
        if c in " \t\r":
            i, col = i + 1, col + 1
            continue
        if src.startswith("//", i):
            while i < n and src[i] != "\n":
                i += 1
            continue
        if src.startswith("/*", i):
            j = src.find("*/", i + 2)
            if j < 0:
                err("unclosed comment (missing */)")
            line += src.count("\n", i, j)
            i = j + 2
            continue
        start_line, start_col = line, col
        if c == "@" and i + 1 < n and src[i + 1] == '"':           # verbatim string: "" is a quote
            j, buf = i + 2, []
            while True:
                if j >= n:
                    err("unclosed string")
                if src[j] == '"':
                    if j + 1 < n and src[j + 1] == '"':
                        buf.append('"')
                        j += 2
                        continue
                    break
                if src[j] == "\n":
                    line += 1
                buf.append(src[j])
                j += 1
            out.append(T("str", "".join(buf), start_line, start_col))
            col += j + 1 - i
            i = j + 1
            continue
        if c in "\"'":
            j, buf = i + 1, []
            while j < n and src[j] != c:
                if src[j] == "\n":
                    err("unclosed string")
                if src[j] == "\\" and j + 1 < n:
                    buf.append({"n": "\n", "t": "\t", '"': '"', "'": "'", "\\": "\\"}.get(src[j + 1], src[j + 1]))
                    j += 2
                    continue
                buf.append(src[j])
                j += 1
            if j >= n:
                err("unclosed string")
            out.append(T("str", "".join(buf), start_line, start_col))
            col += j + 1 - i
            i = j + 1
            continue
        if c.isdigit() or (c == "." and i + 1 < n and src[i + 1].isdigit()):
            m = re.match(r"\d*\.?\d+([eE][-+]?\d+)?[fFdDmM]?|\d+[fFdDmM]?", src[i:])
            text = m.group(0)
            body = text.rstrip("fFdDmM")
            isfloat = "." in body or "e" in body.lower() or text[-1:] in "fFdDmM"
            out.append(T("num", float(body) if isfloat else int(body), start_line, start_col))
            out[-1].kind = "num"
            out[-1].value = (float(body), True) if isfloat else (int(body), False)
            i += len(text)
            col += len(text)
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            out.append(T("id", src[i:j], start_line, start_col))
            col += j - i
            i = j
            continue
        two = src[i:i + 2]
        if two in SYMS:
            out.append(T("sym", two, start_line, start_col))
            i, col = i + 2, col + 2
            continue
        if c in "{}()[];,.=<>!+-*/%?:&|":
            out.append(T("sym", c, start_line, start_col))
            i, col = i + 1, col + 1
            continue
        err(f"C# mods can't use {c!r} here")
    out.append(T("eof", None, line, col))
    return out


def q(s):
    """A string in SSMod's language."""
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'


def fmt_num(v, isfloat):
    if isfloat:
        r = repr(float(v))
        return r if "e" not in r else f"{float(v):.6f}"
    return str(int(v))


# ------------------------------------------------------------------------------------------------ the translator
class Translator:
    def __init__(self, toks, path):
        self.t, self.i, self.path = toks, 0, path
        self.lines = {}                 # line -> [text pieces]
        self.tmp = 0
        self.flags, self.sounds, self.images, self.texts = set(), set(), set(), set()
        self.funcs = {}                 # helper method name -> parameter names
        self.types = {}                 # variable -> C# type, for the method being translated
        self.declared = set()           # variables already declared (var ...) in this method
        self.mode = "script"            # script | dialogue | behavior | world

    # ---- token helpers
    @property
    def cur(self):
        return self.t[self.i]

    def peek(self, k=1):
        return self.t[min(self.i + k, len(self.t) - 1)]

    def err(self, msg, tok=None):
        tok = tok or self.cur
        return SSModError(msg, Tok("sym", "", tok.line, tok.col), self.path)

    def at(self, kind, value=None, k=0):
        t = self.peek(k)
        return t.kind == kind and (value is None or t.value == value)

    def sym(self, s):
        if not self.at("sym", s):
            raise self.err(f"expected {s!r} here, found {self.cur.value!r}")
        self.i += 1

    def ident(self, what="a name"):
        if self.cur.kind != "id":
            raise self.err(f"expected {what}, found {self.cur.value!r}")
        v = self.cur.value
        self.i += 1
        return v

    def accept(self, kind, value=None):
        if self.at(kind, value):
            self.i += 1
            return True
        return False

    # ---- output: every piece goes on the line of the C# it came from
    def out(self, line, text):
        self.lines.setdefault(line, []).append(text)

    def text(self):
        last = max(self.lines) if self.lines else 1
        return "\n".join(" ".join(self.lines.get(k, [])) for k in range(1, last + 1)) + "\n"

    def newtmp(self):
        self.tmp += 1
        return f"cs_t{self.tmp}"

    LIT = re.compile(r'-?[\d.]+|"(?:[^"\\]|\\.)*"|true|false')

    def declare(self, name, code, typ):
        """SSMod's `var` takes a plain value only: declare with one, then work the expression out into it."""
        if self.LIT.fullmatch(code):
            return f"var {name} = {code};"
        start = PY.get(typ or "System.Single", "0.0")
        return f"var {name} = {start}; {name} = {code};"

    # ------------------------------------------------------------------------------------------------ top level
    def translate(self):
        while self.accept("id", "using"):
            while not self.accept("sym", ";"):
                self.i += 1
        attrs = self.attributes()
        while self.cur.kind == "id" and self.cur.value in ("public", "sealed", "partial", "internal"):
            self.i += 1
        tok = self.cur
        if not self.accept("id", "class"):
            raise self.err("a C# mod is one class with a [Mod(\"Name\")] attribute: [Mod(\"My Mod\")] public class MyMod : Mod { ... }")
        self.ident("the mod's class name")
        if self.accept("sym", ":"):
            self.ident("Mod")
        mod = attrs.get("Mod")
        if not mod:
            raise self.err('put [Mod("My Mod", Author = "Me", Version = "1.0")] above the class', tok)
        a, kw = mod
        name = a[0] if a else "C# Mod"
        self.out(tok.line, f"mod {q(name)} by {q(kw.get('Author', 'Unknown'))} version {kw.get('Version', '1.0')};")
        self.sym("{")
        members_start = self.i
        self.scan_helpers()
        self.i = members_start
        while not self.accept("sym", "}"):
            self.member()
        return self.text()

    def attributes(self):
        """[Name(args, Key = value)] ... -> {Name: (positional values, {key: value})}"""
        found = {}
        while self.at("sym", "["):
            self.i += 1
            while True:
                name = self.ident("an attribute name")
                pos, kw = [], {}
                if self.accept("sym", "("):
                    while not self.accept("sym", ")"):
                        if self.cur.kind == "id" and self.at("sym", "=", 1):
                            key = self.ident()
                            self.sym("=")
                            kw[key] = self.literal()
                        else:
                            pos.append(self.literal())
                        self.accept("sym", ",")
                found[name] = (pos, kw)
                if not self.accept("sym", ","):
                    break
            self.sym("]")
        return found

    def literal(self):
        neg = self.accept("sym", "-")
        t = self.cur
        self.i += 1
        if t.kind == "num":
            v, isf = t.value
            return fmt_num(-v if neg else v, isf)
        if t.kind == "str":
            return t.value
        if t.kind == "id":
            # Enum.Value, a constant name, true/false
            v = t.value
            while self.accept("sym", "."):
                v = self.ident()
            return v
        raise self.err("expected a value here", t)

    def scan_helpers(self):
        """Collect helper methods first, so they can be called before they're written."""
        depth = 0
        while not (depth == 0 and self.at("sym", "}")) and not self.at("eof"):
            if self.at("sym", "{"):
                depth += 1
            elif self.at("sym", "}"):
                depth -= 1
            elif depth == 0 and self.at("id", "void") and self.at("id", None, 1) and self.at("sym", "(", 2):
                name = self.peek(1).value
                j, params = self.i + 3, []
                while not (self.t[j].kind == "sym" and self.t[j].value == ")"):
                    if self.t[j].kind == "id" and self.t[j + 1].kind == "sym" and self.t[j + 1].value in (",", ")"):
                        params.append(self.t[j].value)
                    j += 1
                self.funcs[name] = params
            self.i += 1

    def member(self):
        attrs = self.attributes()
        while self.cur.kind == "id" and self.cur.value in ("public", "private", "protected", "static", "readonly"):
            self.i += 1
        tok = self.cur
        if self.at("id", "class"):
            return self.nested_class(attrs)
        if self.at("id", "void"):
            self.i += 1
            name = self.ident("a method name")
            return self.method(name, attrs, tok)
        typ = self.ident("a field type (bool, Sound, Image, Text) or a method")
        name = self.ident("a field name")
        init = None
        if self.accept("sym", "="):
            init = self.literal()
        self.sym(";")
        self.field(typ, name, init, attrs, tok)

    def field(self, typ, name, init, attrs, tok):
        L = tok.line
        if typ in ("bool", "Flag"):
            self.flags.add(name)
            self.out(L, f"flag {name};")
        elif typ == "Sound":
            a = attrs.get("Sound") or self._need(tok, f'[Sound("sounds/{name.lower()}.wav")] above {name}')
            vol = f" volume {a[1]['Volume']}" if "Volume" in a[1] else ""
            self.sounds.add(name)
            self.out(L, f"sound {name} from {q(a[0][0])}{vol};")
        elif typ == "Image":
            a = attrs.get("Image") or self._need(tok, f'[Image("art/{name.lower()}.png", width, height)] above {name}')
            size = f" size ({a[0][1]}, {a[0][2]})" if len(a[0]) >= 3 else ""
            self.images.add(name)
            self.out(L, f"image {name} from {q(a[0][0])}{size};")
        elif typ == "Text":
            a = attrs.get("Hud") or self._need(tok, f'[Hud("Scene", x, y)] above {name}')
            (scene, x, y), kw = a[0][:3], a[1]
            extra = (f" color {kw['Color']}" if "Color" in kw else "") + (f" scale {kw['Scale']}" if "Scale" in kw else "")
            self.texts.add(name)
            self.out(L, f"hud {name} {q(init or '')} in {q(scene)} at ({x}, {y}){extra};")
        else:
            raise self.err(f"a mod's fields can be bool (a flag), Sound, Image or Text (on-screen text), not {typ}", tok)

    def _need(self, tok, what):
        raise self.err(f"add {what}", tok)

    def nested_class(self, attrs):
        tok = self.cur
        self.i += 1
        name = self.ident("a name")
        if self.accept("sym", ":"):
            self.ident()
        kind = "npc" if "Npc" in attrs else "spot" if "Spot" in attrs else None
        if not kind:
            raise self.err('a class inside the mod is a character or a spot: put [Npc("Scene", x, y)] or [Spot("Scene", x, y)] above it', tok)
        pos, kw = attrs["Npc" if kind == "npc" else "Spot"]
        scene = pos[0]
        if len(pos) >= 4:                                   # ("Scene", "Landmark", dx, dy)
            loc = f"{q(pos[1])} + ({pos[2]}, {pos[3]})"
        elif len(pos) == 3:
            loc = f"({pos[1]}, {pos[2]})"
        else:
            raise self.err(f'[{kind.title()}("Scene", x, y)] needs a scene and a position', tok)
        base = f" from {kw['Template']}" if "Template" in kw else ""
        self.out(tok.line, f"{kind} {name}{base} in {q(scene)} at {loc} {{")
        self.sym("{")
        while not self.at("sym", "}"):
            mtok = self.cur
            self.attributes()
            while self.cur.kind == "id" and self.cur.value in ("public", "private", "protected", "override"):
                self.i += 1
            if self.at("id", "Look"):                       # Look Look = new Look { Shirt = "#FF0000", ... };
                self.i += 1
                self.ident()
                self.sym("=")
                self.accept("id", "new")
                self.accept("id", "Look")
                self.accept("sym", "(") and self.sym(")")
                self.sym("{")
                parts = []
                while not self.accept("sym", "}"):
                    k = self.ident("a look part (Shirt, Pants, Hair, Skin...)")
                    self.sym("=")
                    parts.append(f"{k[0].lower() + k[1:]} = {self.literal()};")
                    self.accept("sym", ",")
                self.sym(";")
                self.out(mtok.line, "look { " + " ".join(parts) + " }")
                continue
            if self.at("id", "string") or self.at("id", "float") or self.at("id", "int"):
                typ = self.ident()                          # simple properties: string Actor = "Ranger";
                key = self.ident()
                self.sym("=")
                self.out(mtok.line, f"{key[0].lower() + key[1:]} = {q(self.literal()) if typ == 'string' else self.literal()};")
                self.sym(";")
                continue
            self.sym_word("void")
            which = self.ident("Dialogue() or Behavior()")
            self.sym("(")
            self.sym(")")
            if which not in ("Dialogue", "Behavior"):
                raise self.err(f"a character's methods are Dialogue() and Behavior(), not {which}()", mtok)
            self.begin_method([])
            self.mode = "dialogue" if which == "Dialogue" else "behavior"
            self.out(mtok.line, "dialogue" if which == "Dialogue" else "behavior")
            self.block()
            self.mode = "script"
        self.sym("}")
        self.out(self.t[self.i - 1].line, "}")

    def sym_word(self, w):
        if not self.accept("id", w):
            raise self.err(f"expected {w}")

    def begin_method(self, params):
        self.types = {p: None for p in params}
        self.declared = set(params)

    def method(self, name, attrs, tok):
        self.sym("(")
        params, ptypes = [], {}
        while not self.accept("sym", ")"):
            ptype = None
            if self.at("id") and self.at("id", None, 1):
                ptype = self.ctype(self.ident())            # the parameter's type
            params.append(self.ident("a parameter name"))
            ptypes[params[-1]] = ptype
            self.accept("sym", ",")
        self.begin_method(params)
        self.types.update(ptypes)
        L = tok.line
        if "Script" in attrs:
            pos, kw = attrs["Script"]
            by = f" by {kw['By']}" if "By" in kw else ""
            self.out(L, f"script {name} in {q(pos[0] if pos else 'everywhere')}{by}")
            self.block()
        elif "OnKey" in attrs:
            pos, kw = attrs["OnKey"]
            if len(pos) < 2:
                raise self.err('[OnKey("c", "Scene")] needs the key and the scene', tok)
            self.out(L, f"on key {q(pos[0])} in {q(pos[1])}")
            self.block()
        elif "World" in attrs or name == "World":
            self.mode = "world"
            self.sym("{")
            while not self.accept("sym", "}"):
                self.world_statement()
            self.mode = "script"
        else:                                               # a helper: copied in where it's used
            self.out(L, f"function {name}({', '.join(params)})")
            self.block()

    # ------------------------------------------------------------------------------------------------ the world
    def world_statement(self):
        tok = self.cur
        name = self.ident("Place(...), PlaceImage(...) or SSMod.Raw(...)")
        if name == "SSMod" and self.accept("sym", "."):
            name = self.ident()
        args, kw = self.call_literals()
        self.sym(";")
        L = tok.line
        if name == "Raw":
            self.out(L, args[0])
        elif name == "PlaceImage":                          # PlaceImage(Pic, "Scene", x, y, Animate: Anim, As: "Name", ShowIf: Flag)
            img, scene, x, y = args[:4]
            self.out(L, f"place image {img} in {q(scene)} at ({x}, {y}){self.place_opts(kw)};")
        elif name == "Place":                               # Place("Object", "FromScene", "InScene", x, y, ...)
            obj, src, scene, x, y = args[:5]
            self.out(L, f"place {q(obj)} from {q(src)} in {q(scene)} at ({x}, {y}){self.place_opts(kw)};")
        else:
            raise self.err(f"in World() you can use PlaceImage, Place and SSMod.Raw (not {name})", tok)

    def place_opts(self, kw):
        out = ""
        for k, v in kw.items():
            key = {"Animate": "animate", "As": "as", "ShowIf": "showIf", "HideIf": "hideIf", "Scale": "scale",
                   "Rotate": "rotate", "Front": "front", "Color": "color"}.get(k)
            if not key:
                raise self.err(f"unknown option {k} (Animate, As, ShowIf, HideIf, Scale, Rotate, Front, Color)")
            out += f" {key} {v}"
        return out

    def call_literals(self):
        self.sym("(")
        args, kw = [], {}
        while not self.accept("sym", ")"):
            if self.cur.kind == "id" and self.at("sym", ":", 1):
                key = self.ident()
                self.sym(":")
                kw[key] = self.literal()
            else:
                args.append(self.literal())
            self.accept("sym", ",")
        return args, kw

    # ------------------------------------------------------------------------------------------------ statements
    def block(self):
        open_tok = self.cur
        self.sym("{")
        self.out(open_tok.line, "{")
        while not self.at("sym", "}"):
            self.statement()
        self.out(self.cur.line, "}")
        self.i += 1

    def body(self):
        """A block, or one statement without braces."""
        if self.at("sym", "{"):
            self.block()
        else:
            self.out(self.cur.line, "{")
            self.statement()
            self.out(self.t[self.i - 1].line, "}")

    def statement(self):
        tok = self.cur
        L = tok.line
        if self.accept("sym", ";"):
            return
        if self.at("sym", "{"):
            return self.block()
        w = tok.value if tok.kind == "id" else None
        if w == "if":
            self.i += 1
            self.sym("(")
            pre, cond = self.condition()
            self.sym(")")
            for s in pre:
                self.out(L, s)
            self.out(L, f"if ({cond})")
            self.body()
            if self.accept("id", "else"):
                self.out(self.t[self.i - 1].line, "else")
                if self.at("id", "if"):
                    self.out(self.cur.line, "{")
                    self.statement()
                    self.out(self.t[self.i - 1].line, "}")
                else:
                    self.body()
            return
        if w == "while":
            self.i += 1
            self.sym("(")
            if self.at("id", "true") and self.at("sym", ")", 1):
                self.i += 2
                self.out(L, "forever")
                return self.body()
            pre, cond = self.condition()
            self.sym(")")
            for s in pre:
                self.out(L, s)
            self.out(L, f"while ({cond})")
            self.loop_body(pre, L)
            return
        if w == "for":                                      # for (int i = 0; i < n; i++)
            self.i += 1
            self.sym("(")
            self.statement()                                # the start (ends with ;)
            pre, cond = self.condition()
            self.sym(";")
            step_start = self.i
            depth = 0
            while not (depth == 0 and self.at("sym", ")")):
                depth += self.at("sym", "(") - self.at("sym", ")")
                self.i += 1
            step_end = self.i
            self.sym(")")
            for s in pre:
                self.out(L, s)
            self.out(L, f"while ({cond})")
            self.out(self.cur.line, "{")
            self.inner_body()
            save = self.i
            self.i = step_start
            self.simple_statement(L, end=step_end)
            self.i = save
            for s in pre:
                self.out(L, s)
            self.out(self.t[self.i - 1].line, "}")
            return
        if w == "switch":
            return self.switch()
        if w in ("return", "break", "continue"):
            raise self.err(f"'{w}' isn't available in mods yet (the game's scripts have no way to jump out)", tok)
        self.simple_statement(L)
        self.sym(";")

    def loop_body(self, pre, L):
        """A while loop's body, ending by re-working its condition (the game checks it after each pass)."""
        self.out(self.cur.line, "{")
        self.inner_body()
        for s in pre:
            self.out(self.t[self.i - 1].line, s)
        self.out(self.t[self.i - 1].line, "}")

    def inner_body(self):
        if self.at("sym", "{"):
            self.i += 1
            while not self.at("sym", "}"):
                self.statement()
            self.i += 1
        else:
            self.statement()

    def simple_statement(self, L, end=None):
        """Declarations, assignments, ++/--, and calls (no trailing ;)."""
        tok = self.cur
        # typed declaration: float x = 1; Vector2 p = ...; var x = ...;
        if tok.kind == "id" and (tok.value == "var" or tok.value in PRIM or self.is_type_name(tok.value)) \
                and self.at("id", None, 1) and (self.at("sym", "=", 2) or self.at("sym", ";", 2)):
            typ = tok.value
            self.i += 1
            name = self.ident()
            if self.accept("sym", "="):
                return self.assign(name, L, declare=True, ctype=None if typ == "var" else self.ctype(typ))
            ct = self.ctype(typ)
            self.types[name] = ct
            if ct in PY:
                self.out(L, f"{'var ' if name not in self.declared else ''}{name} = {PY[ct]};")
                self.declared.add(name)
            return
        if tok.kind == "id" and self.at("sym", None, 1) and self.peek(1).value in ("++", "--"):
            name = self.ident()
            op = self.cur.value
            self.i += 1
            self.out(L, f"{name} {'+=' if op == '++' else '-='} 1;")
            return
        if tok.kind == "id" and tok.value in self.flags and self.at("sym", "=", 1):
            self.i += 2
            v = self.cur
            if not (v.kind == "id" and v.value in ("true", "false")):
                raise self.err(f"{tok.value} is a flag: set it to true or false", v)
            self.i += 1
            self.out(L, f"{'set' if v.value == 'true' else 'clear'} {tok.value};")
            return
        if tok.kind == "id" and tok.value in self.declared | set(self.types) and self.at("sym", None, 1) \
                and self.peek(1).value in ("=", "+=", "-=", "*=", "/="):
            name = self.ident()
            op = self.cur.value
            self.i += 1
            if op == "=":
                return self.assign(name, L)
            pre, code, typ = self.expr()
            for s in pre:
                self.out(L, s)
            if self.types.get(name) in VEC:
                fn = {"+=": "op_Addition", "-=": "op_Subtraction", "*=": "op_Multiply"}.get(op)
                if not fn:
                    raise self.err("positions can be added to, taken from or multiplied", tok)
                self.out(L, f"call {self.types[name]}.{fn}({name}, {self.arg(code, typ, L)}) -> {name};")
            else:
                self.out(L, f"{name} {op} {code};")
            return
        if tok.kind == "id" and tok.value in self.funcs and self.at("sym", "(", 1):
            name = self.ident()
            args = self.args(L)
            self.out(L, f"{name}({', '.join(args)});")
            return
        if self.builtin(L):
            return
        # anything else: a call, or a property being set (thing.position = v)
        pre, target, last = self.access(L, statement=True)
        for s in pre:
            self.out(L, s)
        if last == "set":
            return
        if target is None:
            raise self.err("this line doesn't do anything a mod can run", tok)
        self.out(L, target + ";")

    def is_type_name(self, name):
        return name[:1].isupper() and name not in self.flags | self.sounds | self.images | self.texts \
            and name not in self.types and calls.full_class(name) is not None and self.at("id", None, 1)

    def ctype(self, typ):
        return PRIM.get(typ) or calls.full_class(typ) or typ

    def assign(self, name, L, declare=False, ctype=None):
        tok = self.cur
        direct = ctype is None or ctype not in VEC          # a typed position may need converting first
        pre, code, typ = self.expr(target=name if direct else None)
        for st in pre:
            self.out(L, st)
        want = ctype or typ
        if code is None:                                     # a call put its result straight into `name`
            self.types[name] = typ
            self.declared.add(name)
            return
        if want in VEC:
            if typ in VEC and typ != want:
                self.out(L, f"call UnityEngine.Vector2.op_Implicit({self.arg(code, typ, L)}) -> {name};")
            else:                                            # a literal (x, y) or another position: copy it
                self.out(L, f"call {want}.op_Multiply({self.arg(code, typ, L)}, 1.0) -> {name};")
        elif typ and typ not in NUM + ("System.String", "System.Boolean"):
            raise self.err(f"copying a {typ.split('.')[-1]} into another variable isn't supported: use the first one", tok)
        else:
            if want == "System.Single" and re.fullmatch(r"-?\d+", code):
                code += ".0"
            if declare and name not in self.declared:
                self.out(L, self.declare(name, code, want))
            else:
                self.out(L, f"{name} = {code};")
        self.types[name] = want
        self.declared.add(name)

    # ---- the game's own commands, written as C# methods
    def builtin(self, L):
        tok = self.cur
        if tok.kind != "id":
            return False
        name = tok.value
        nxt = self.peek(1)
        # Sound.Play()
        if name in self.sounds and nxt.value == ".":
            self.i += 2
            if self.ident() != "Play":
                raise self.err(f"a Sound can only Play(): {name}.Play()")
            self.sym("(")
            self.sym(")")
            self.out(L, f"play {name};")
            return True
        # Text.text = "..."
        if name in self.texts and nxt.value == ".":
            self.i += 2
            prop = self.ident()
            self.sym("=")
            pre, code, typ = self.expr()
            for s in pre:
                self.out(L, s)
            arg = self.arg(code, typ, L)
            self.out(L, f"call TMP_Text({q(name)}).set_{prop}({arg});")
            return True
        if name == "Debug" and nxt.value == ".":
            self.i += 2
            self.ident()
            args = self.args(L, raw=True)
            self.out(L, f"log {args[0]};")
            return True
        if name == "Time" and nxt.value == "." and self.peek(2).value == "timeScale" and self.peek(3).value == "=":
            self.i += 4
            pre, code, _ = self.expr()
            for s in pre:
                self.out(L, s)
            self.out(L, f"timescale {code};")
            return True
        if name == "Game" and nxt.value == ".":
            self.i += 2
            what = self.ident()
            args = self.args(L, raw=True)
            simple = {"SetWeather": "weather {0};", "GiveCoins": "give coins {0};", "TakeCoins": "take coins {0};",
                      "GiveItem": "give item {0};", "TakeItem": "take item {0};"}
            if what not in simple:
                raise self.err(f"Game.{what} isn't a command (Game.SetWeather, GiveCoins, TakeCoins, GiveItem, TakeItem)")
            a0 = args[0].split(".")[-1] if what == "SetWeather" else args[0]
            self.out(L, simple[what].format(a0))
            return True
        if name in ("Wait", "WaitUntil", "WaitRandom", "Log", "Say", "Speak", "Parallel", "Wander", "WalkTo", "RunTo",
                    "SSMod", "Raw") and nxt.value in ("(", "."):
            if name == "SSMod":
                self.i += 2
                name = self.ident()
                if name != "Raw":
                    raise self.err("SSMod.Raw(@\"...\") is the only SSMod.* command")
            else:
                self.i += 1
            if name == "Raw":
                self.sym("(")
                s = self.cur
                self.i += 1
                self.sym(")")
                self.out(L, s.value)
                return True
            if name == "Parallel":
                self.sym("(")
                self.out(L, "parallel {")
                while not self.accept("sym", ")"):
                    self.sym("(")
                    self.sym(")")
                    self.sym("=>")
                    self.block()
                    self.accept("sym", ",")
                self.out(self.t[self.i - 1].line, "}")
                return True
            if name == "WaitUntil":
                self.sym("(")
                if self.at("sym", "(") and self.at("sym", ")", 1) and self.at("sym", "=>", 2):
                    self.i += 3
                pre, cond = self.condition()
                self.sym(")")
                for s in pre:
                    self.out(L, s)
                self.out(L, f"waitUntil ({cond});")
                return True
            args = self.args(L, raw=True)
            if name == "Wait":
                self.out(L, f"wait {args[0]};")
            elif name == "WaitRandom":
                self.out(L, f"wait random {args[0]} to {args[1]};")
            elif name == "Log":
                self.out(L, f"log {args[0]};")
            elif name == "Say":
                self.out(L, f"{'say' if self.mode == 'dialogue' else 'speak'} {args[0]};")
            elif name == "Speak":
                self.out(L, f"speak {args[0]};")
            elif name == "Wander":
                self.out(L, f"wander {args[0]};")
            elif name in ("WalkTo", "RunTo"):
                verb = "walk" if name == "WalkTo" else "run"
                if len(args) >= 2 and re.fullmatch(r"-?[\d.]+", args[0]):
                    self.out(L, f"{verb} to ({args[0]}, {args[1]});")
                elif args[0] == "player":
                    self.out(L, f"{verb} to player;")
                elif args[0].startswith('"'):
                    self.out(L, f"{verb} to {args[0]};")
                else:
                    self.out(L, f"{verb} to {args[0]}{' nowait' if 'nowait' in args[1:] else ''};")
            return True
        return False

    def switch(self):
        """switch (Choice("Question?", "A", "B")) { case "A": ...; break; ... } -> a dialogue choice."""
        tok = self.cur
        self.i += 1
        self.sym("(")
        if not self.accept("id", "Choice"):
            raise self.err('a switch in a mod picks a dialogue choice: switch (Choice("Question?", "Yes", "No"))', tok)
        args = self.args(tok.line, raw=True)
        self.sym(")")
        self.sym("{")
        self.out(tok.line, f"choice {args[0]} {{")
        while not self.accept("sym", "}"):
            ctok = self.cur
            self.sym_word("case")
            label = self.cur
            self.i += 1
            self.sym(":")
            self.out(ctok.line, f"{q(label.value)} => {{")
            while not (self.at("id", "case") or self.at("sym", "}") or self.at("id", "break")):
                self.statement()
            self.accept("id", "break") and self.sym(";")
            self.out(self.t[self.i - 1].line, "}")
        self.out(self.t[self.i - 1].line, "}")

    # ------------------------------------------------------------------------------------------------ expressions
    def args(self, L, raw=False):
        """( a, b, ... ) -> SSMod arguments; anything more than a value is worked out into a temporary first."""
        self.sym("(")
        out = []
        while not self.accept("sym", ")"):
            if self.cur.kind == "id" and self.at("sym", ":", 1):     # named argument (for WalkTo(..., nowait: true))
                key = self.ident()
                self.sym(":")
                self.expr()
                out.append(key)
            else:
                pre, code, typ = self.expr()
                for s in pre:
                    self.out(L, s)
                out.append(code if raw else self.arg(code, typ, L))
            self.accept("sym", ",")
        return out

    def arg(self, code, typ, L):
        """A call argument must be a plain value or a variable name."""
        if re.fullmatch(r'-?[\d.]+|"(?:[^"\\]|\\.)*"|true|false|null|[A-Za-z_][A-Za-z0-9_]*|\(\s*-?[\d.]+(\s*,\s*-?[\d.]+)*\s*\)', code):
            return code
        t = self.newtmp()
        self.out(L, self.declare(t, code, typ))
        self.types[t] = typ
        return t

    def condition(self):
        """An if/while condition: (statements to run first, condition text)."""
        pre, code, typ = self.expr(cond=True)
        return pre, code

    # precedence climbing over C# operators
    BIN = [("||",), ("&&",), ("==", "!="), ("<", ">", "<=", ">="), ("+", "-"), ("*", "/", "%")]

    def expr(self, target=None, cond=False, level=0):
        """-> (statements to run first, SSMod expression text or None if put into target, C# type)."""
        if level == len(self.BIN):
            return self.unary(target)
        pre, code, typ = self.expr(target, cond, level + 1)
        if code is None and target is not None:            # the first value went straight into the target
            code = target
            self.declared.add(target)
            if self.at("sym") and self.cur.value in self.BIN[level]:
                pass
            else:
                return pre, None, typ
        ops = self.BIN[level]
        while self.at("sym") and self.cur.value in ops:
            op = self.cur.value
            optok = self.cur
            self.i += 1
            p2, c2, t2 = self.expr(None, cond, level + 1)
            pre += p2
            if typ in VEC or t2 in VEC:
                code, typ = self.vector_op(op, code, typ, c2, t2, pre, optok)
            else:
                code = f"{code} {op} {c2}"
                if op in ("==", "!=", "<", ">", "<=", ">=", "&&", "||"):
                    typ = "System.Boolean"
                elif "System.String" in (typ, t2):
                    typ = "System.String"
                elif "System.Single" in (typ, t2) or op == "/":
                    typ = "System.Single"
        if target is not None and level == 0 and code is not None and typ in VEC and \
                re.fullmatch(r"cs_t\d+", code or "") and pre and pre[-1].endswith(f"-> {code};"):
            pre[-1] = pre[-1][: -len(f"-> {code};")] + f"-> {target};"   # the last step writes straight into it
            return pre, None, typ
        return pre, code, typ

    def vector_op(self, op, a, ta, b, tb, pre, tok):
        vt = ta if ta in VEC else tb
        L = tok.line
        A = self.arg(a, ta, L) if ta else a
        B = self.arg(b, tb, L) if tb else b
        t = self.newtmp()
        if op in ("+", "-") and ta in VEC and tb in VEC:
            if ta != tb:
                raise self.err("adding a Vector2 and a Vector3: convert one first, like (Vector2)v", tok)
            pre.append(f"call {vt}.{'op_Addition' if op == '+' else 'op_Subtraction'}({A}, {B}) -> {t};")
        elif op == "*":
            v, k = (A, B) if ta in VEC else (B, A)
            pre.append(f"call {vt}.op_Multiply({v}, {self.float_arg(k, pre)}) -> {t};")
        elif op == "/" and ta in VEC:
            inv = self.newtmp()
            pre.append(self.declare(inv, f"1.0 / {B}", "System.Single"))
            pre.append(f"call {vt}.op_Multiply({A}, {inv}) -> {t};")
        else:
            raise self.err(f"positions can't use {op!r} that way", tok)
        self.types[t] = vt
        return t, vt

    def float_arg(self, k, pre):
        if re.fullmatch(r"-?\d+", k):
            return k + ".0"
        if re.fullmatch(r"-?[\d.]+|[A-Za-z_]\w*", k):
            return k
        t = self.newtmp()
        pre.append(self.declare(t, k, "System.Single"))
        return t

    def unary(self, target):
        tok = self.cur
        if self.accept("sym", "!"):
            pre, code, typ = self.unary(None)
            return pre, f"!{code}", "System.Boolean"
        if self.accept("sym", "-"):
            pre, code, typ = self.unary(None)
            if typ in VEC:
                t = self.newtmp()
                pre.append(f"call {typ}.op_Multiply({code}, -1.0) -> {t};")
                return pre, t, typ
            return pre, f"-{code}", typ
        if self.at("sym", "(") and self.at("id", None, 1) and self.at("sym", ")", 2) and \
                self.peek(1).value in ("Vector2", "Vector3", "float", "int"):        # a cast
            to = self.peek(1).value
            self.i += 3
            pre, code, typ = self.unary(None)
            if to in ("Vector2", "Vector3") and typ in VEC and PRIM[to] != typ:
                t = target or self.newtmp()
                pre.append(f"call UnityEngine.Vector2.op_Implicit({self.arg(code, typ, tok.line)}) -> {t};")
                self.types[t] = PRIM[to]
                return (pre, None, PRIM[to]) if target else (pre, t, PRIM[to])
            return pre, code, PRIM.get(to, typ)
        if self.accept("sym", "("):
            pre, code, typ = self.expr()
            self.sym(")")
            return pre, f"({code})", typ
        if tok.kind == "num":
            self.i += 1
            v, isf = tok.value
            return [], fmt_num(v, isf), "System.Single" if isf else "System.Int32"
        if tok.kind == "str":
            self.i += 1
            return [], q(tok.value), "System.String"
        if tok.kind == "id" and tok.value in ("true", "false", "null"):
            self.i += 1
            return [], tok.value, "System.Boolean"
        if tok.kind == "id" and tok.value == "new":
            return self.new_struct(target)
        if tok.kind == "id" and tok.value in self.flags and not self.at("sym", ".", 1):
            self.i += 1
            return [], tok.value, "System.Boolean"
        pre, code, typ = self.access(tok.line, target=target)
        return pre, code, typ

    def new_struct(self, target):
        tok = self.cur
        self.i += 1
        typ = self.ident("Vector2 or Vector3")
        if typ not in ("Vector2", "Vector3"):
            raise self.err(f"mods can make new Vector2/Vector3 values, not new {typ}", tok)
        L = tok.line
        self.sym("(")
        parts = []
        while not self.accept("sym", ")"):
            pre, code, t = self.expr()
            parts.append((pre, code))
            self.accept("sym", ",")
        ct = PRIM[typ]
        if all(not p and re.fullmatch(r"-?[\d.]+", c) for p, c in parts):
            return [], "(" + ", ".join(c for _, c in parts) + ")", ct
        # built from variables: right * x + up * y (+ forward * z)
        pre = []
        axes = ["right", "up", "forward"]
        acc = None
        for k, (p, c) in enumerate(parts):
            pre += p
            ax, term = self.newtmp(), self.newtmp()
            pre.append(f"call {ct}.get_{axes[k]}() -> {ax};")
            pre.append(f"call {ct}.op_Multiply({ax}, {self.float_arg(c, pre)}) -> {term};")
            if acc is None:
                acc = term
            else:
                s = self.newtmp()
                pre.append(f"call {ct}.op_Addition({acc}, {term}) -> {s};")
                acc = s
        self.types[acc] = ct
        return pre, acc, ct

    def access(self, L, target=None, statement=False):
        """a.b.c(...) chains: variables, the player, the game's classes, Find<T>("Name"), properties and calls.
        -> (statements first, final value text, its C# type). For a statement ending in a call, the value is the
        call itself (without -> ...)."""
        tok = self.cur
        pre = []
        name = self.ident("a value")
        # the head
        if name == "Player":
            cur, typ = "player", "GameActor"
        elif name == "Find" and self.at("sym", "<"):
            self.i += 1
            t = self.ident("a component type")
            self.sym(">")
            self.sym("(")
            obj = self.cur
            self.i += 1
            self.sym(")")
            full = calls.full_class(t) or t
            # a name in quotes, or a helper's parameter (filled in where the helper is used)
            what = obj.value if obj.kind == "id" else q(obj.value)
            cur, typ = f"{full if t not in ('GameActor',) else 'GameActor'}({what})", "obj:" + full
        elif name in self.types or name in self.declared:
            cur, typ = name, self.types.get(name)
        elif name in self.texts and self.at("sym", "."):
            cur, typ = f"TMP_Text({q(name)})", "obj:TMPro.TMP_Text"
        else:
            # a class (possibly with a namespace): UnityEngine.Vector2, Vector2, NodeCanvasBridge
            cls = name
            while self.at("sym", ".") and self.at("id", None, 1) and calls.full_class(cls) is None:
                self.i += 1
                cls += "." + self.ident()
            full = calls.full_class(cls)
            if full is None:
                if self.at("sym", "("):                     # a game function with no class (NodeCanvasBridge)
                    args = self.args(L)
                    call = f"call {name}({', '.join(args)})"
                    rtype = calls.lookup(calls.DEFAULT_CLASS, name, len(args), Tok("sym", "", tok.line, tok.col), self.path,
                                         args=self.argtuples(args))[2]["ret"]
                    return self.finish_call(pre, call, rtype, target, statement, L)
                raise self.err(f"there's no variable or game class called {cls}", tok)
            cur, typ = full, "class:" + full
        # the chain
        while self.accept("sym", "."):
            mtok = self.cur
            member = self.ident("a property or method")
            if self.at("sym", "("):                         # a method call
                args = self.args(L)
                call = self.call_text(cur, typ, member, args, mtok)
                rtype = self.result(cur, typ, member, args, mtok)
                if self.at("sym", "."):                     # more to come: keep it in a temporary
                    t = self.newtmp()
                    pre.append(f"{call} -> {t};")
                    cur, typ = t, rtype
                    self.types[t] = rtype
                    continue
                return self.finish_call(pre, call, rtype, target, statement, L)
            # a property: being set, or read
            if statement and self.at("sym", "=") and not self.at("sym", ".", 1):
                self.i += 1
                p2, code, t2 = self.expr()
                pre += p2
                arg = self.arg(code, t2, L)
                pre.append(self.call_text(cur, typ, "set_" + member, [arg], mtok) + ";")
                return pre, None, "set"
            if typ and typ.startswith("class:") and calls.api()["enums"].get(typ[6:]) is not None:
                return pre, member, typ[6:]               # an option of an enum: Weather.Snowy -> Snowy
            if typ in VEC and member in ("x", "y", "z"):
                axis = {"x": "right", "y": "up", "z": "forward"}[member]
                ax, t = self.newtmp(), self.newtmp()
                pre.append(f"call {typ}.get_{axis}() -> {ax};")
                pre.append(f"call {typ}.Dot({cur}, {ax}) -> {t};")
                cur, typ = t, "System.Single"
                self.types[t] = typ
                continue
            if cur == "player" and member == "body":
                t = target if (target and not self.at("sym", ".")) else self.newtmp()
                pre.append(f"player.body -> {t};")
                cur, typ = t, "UnityEngine.Rigidbody2D"
                self.types[t] = typ
                if t == target:
                    return pre, None, typ
                continue
            call = self.call_text(cur, typ, "get_" + member, [], mtok)
            rtype = self.result(cur, typ, "get_" + member, [], mtok)
            t = target if (target and not self.at("sym", ".")) else self.newtmp()
            pre.append(f"{call} -> {t};")
            cur, typ = t, rtype
            self.types[t] = rtype
            if t == target:
                return pre, None, rtype
        if typ and (typ.startswith("class:") or typ.startswith("obj:")):
            raise self.err(f"{name} on its own isn't a value: use one of its properties or methods", tok)
        return pre, cur, typ

    def finish_call(self, pre, call, rtype, target, statement, L):
        if statement:
            return pre, call, "call"
        if rtype in (None, "System.Void"):
            raise self.err("this call doesn't give anything back")
        if target is not None:
            pre.append(f"{call} -> {target};")
            self.types[target] = rtype
            return pre, None, rtype
        t = self.newtmp()
        pre.append(f"{call} -> {t};")
        self.types[t] = rtype
        return pre, t, rtype

    def call_text(self, cur, typ, member, args, tok):
        if typ and typ.startswith("class:"):
            return f"call {typ[6:]}.{member}({', '.join(args)})"
        return f"call {cur}.{member}({', '.join(args)})"

    def argtuples(self, args):
        out = []
        for a in args:
            if re.fullmatch(r"-?[\d.]+", a):
                out.append(("num", float(a) if "." in a else int(a), None))
            elif a.startswith('"'):
                out.append(("str", a[1:-1], None))
            elif a.startswith("("):
                out.append(("vec", tuple(float(x) for x in a[1:-1].split(",")), None))
            elif a in ("true", "false"):
                out.append(("bool", a == "true", None))
            elif self.types.get(a):
                out.append(("typed", a, None, self.types[a]))
            else:
                out.append(("ident", a, None))
        return out

    def result(self, cur, typ, member, args, tok):
        """The C# type a call gives back (so the next step knows what it's working with)."""
        if typ is None:
            return None                                     # e.g. a helper's parameter: SSMod checks it when it's used
        if typ.startswith("class:"):
            cls, inst = typ[6:], False
        elif typ.startswith("obj:"):
            cls, inst = typ[4:], True
        else:
            cls, inst = typ, True
        _, _, sig = calls.lookup(cls, member, len(args), Tok("sym", "", tok.line, tok.col), self.path,
                                 instance=inst, args=self.argtuples(args))
        return sig["ret"]


class _Ctx:
    """The little bit of the scripts' context calls.result_type needs (variable types)."""
    def __init__(self, tr):
        self.tr = tr

    def var(self, name):
        t = self.tr.types.get(name)
        return (t, {}) if t else None


def translate(src, path):
    return Translator(lex(src, path), path).translate()

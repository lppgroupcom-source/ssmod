"""The game objects SSMod copies from, found by NAME so they survive game updates.

Path ids change whenever the game is rebuilt (2.2 moved 21 of the 22 that SSMod used), names and hierarchy don't.
anchors.json holds a fingerprint for each one, taken from 2.1.9 (tools/make_anchors.py):

  game object   scene + its path of names from the root ("Duck Dialog", "Bank/Door (1)") + its component list
  component     the game object's fingerprint + the script class + which one of that class on the object
  asset         file + type/script + m_Name (ScriptableObjects in resources.assets, sprites, actor data)

When several objects share a fingerprint, "index" picks one in path-id order. resolve() turns a fingerprint into
(file, path id) for the installed game; results are cached per game build in anchor_cache.json.
"""
import hashlib
import json
import os
import struct

from .unity import script_name, mb_name

HERE = os.path.dirname(os.path.abspath(__file__))
ANCHORS = os.path.join(HERE, "anchors.json")


class AnchorError(Exception):
    pass


# ------------------------------------------------------------------ describing objects
def _comp_sig(env, f, o):
    return script_name(env, f, o) if o.type.name == "MonoBehaviour" else o.type.name


class Tree:
    """Names, parents and components of every GameObject in one file."""

    def __init__(self, env, f):
        self.env, self.f = env, f
        self.name, self.parent, self.comps = {}, {}, {}
        tr_go = {}
        trs = {}
        for pid, o in f.objects.items():
            if o.type.name == "GameObject":
                go = o.read()
                self.name[pid] = go.m_Name
                cl = []
                for c in go.m_Component:
                    p = (c.component if hasattr(c, "component") else c)
                    if p.m_FileID == 0 and p.m_PathID in f.objects:
                        cl.append(p.m_PathID)
                self.comps[pid] = cl
            elif o.type.name in ("Transform", "RectTransform"):
                t = o.read()
                trs[pid] = t
                tr_go[pid] = t.m_GameObject.m_PathID
        for tp, t in trs.items():
            father = t.m_Father.m_PathID if t.m_Father else 0
            self.parent[tr_go[tp]] = tr_go.get(father) if father else None
        self._paths = {}
        self._sigs = {}

    def path(self, go):
        if go not in self._paths:
            p = self.parent.get(go)
            self._paths[go] = (self.path(p) if p else ()) + (self.name.get(go, "?"),)
        return self._paths[go]

    def sig(self, go):
        if go not in self._sigs:
            self._sigs[go] = sorted(_comp_sig(self.env, self.f, self.f.objects[c]) for c in self.comps.get(go, []))
        return self._sigs[go]

    def owner(self, comp_pid):
        for go, cl in self.comps.items():
            if comp_pid in cl:
                return go
        return None


def _asset_name(o):
    if o.type.name == "MonoBehaviour":
        return mb_name(o)
    try:
        b = o.get_raw_data()
        n = struct.unpack_from("<i", b, 0)[0]
        return b[4:4 + n].decode("utf-8", "replace") if 0 <= n < 512 else None
    except Exception:
        return None


def fingerprint(env, f, pid, where, tree=None):
    """where = {"scene": name} for a level file, {"file": name} for an asset file."""
    o = f.objects[pid]
    t = o.type.name
    if t == "GameObject":
        tree = tree or Tree(env, f)
        path = tree.path(pid)
        sig = tree.sig(pid)
        same = sorted(g for g in tree.name if tree.path(g) == path and tree.sig(g) == sig)
        return dict(where, kind="go", path=list(path), comps=sig, index=same.index(pid))
    if t == "MonoBehaviour":
        tree = tree or Tree(env, f)
        go = tree.owner(pid)
        if go:
            cls = script_name(env, f, o)
            mine = [c for c in tree.comps[go] if _comp_sig(env, f, f.objects[c]) == cls]
            return dict(where, kind="component", go=fingerprint(env, f, go, where, tree), script=cls, cindex=mine.index(pid))
        cls, name = script_name(env, f, o), mb_name(o)
        same = sorted(p for p, x in f.objects.items() if x.type.name == "MonoBehaviour" and mb_name(x) == name
                      and script_name(env, f, x) == cls)
        return dict(where, kind="asset", type=t, script=cls, name=name, index=same.index(pid))
    name = _asset_name(o)
    same = sorted(p for p, x in f.objects.items() if x.type.name == t and _asset_name(x) == name)
    return dict(where, kind="asset", type=t, name=name, index=same.index(pid))


def find(env, f, fp, tree=None):
    """The path id in (env, f) matching a fingerprint, or raise AnchorError."""
    k = fp["kind"]
    if k == "go":
        tree = tree or Tree(env, f)
        path = tuple(fp["path"])
        cands = sorted(g for g in tree.name if tree.name[g] == path[-1] and tree.path(g) == path)
        exact = [g for g in cands if tree.sig(g) == fp["comps"]]
        pick = exact if exact else cands
        if not pick:
            raise AnchorError("no object called " + "/".join(path))
        return pick[min(fp["index"], len(pick) - 1)] if exact else pick[0]
    if k == "component":
        tree = tree or Tree(env, f)
        go = find(env, f, fp["go"], tree)
        mine = [c for c in tree.comps[go] if _comp_sig(env, f, f.objects[c]) == fp["script"]]
        if not mine:
            raise AnchorError(f"{'/'.join(fp['go']['path'])} has no {fp['script']}")
        return mine[min(fp["cindex"], len(mine) - 1)]
    t, name = fp["type"], fp["name"]
    if t == "MonoBehaviour":
        cands = sorted(p for p, x in f.objects.items() if x.type.name == t and mb_name(x) == name
                       and script_name(env, f, x) == fp["script"])
    else:
        cands = sorted(p for p, x in f.objects.items() if x.type.name == t and _asset_name(x) == name)
    if not cands:
        raise AnchorError(f'no {fp.get("script") or t} called "{name}"')
    return cands[min(fp["index"], len(cands) - 1)]


# ------------------------------------------------------------------ resolving for the installed game
def load_fingerprints():
    with open(ANCHORS) as fh:
        return json.load(fh)


def build_id(data_dir):
    """Identifies a game build: hash of its global-metadata (changes with every release)."""
    meta = os.path.join(data_dir, "il2cpp_data", "Metadata", "global-metadata.dat")
    h = hashlib.sha1()
    with open(meta, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()[:16]


def resolve_all(open_file, scene_level, data_dir, cache_path):
    """{anchor name: (file name, path id)} for this game. open_file(fname) -> (env, f); scene_level(scene) -> levelN."""
    bid = build_id(data_dir)
    if os.path.exists(cache_path):
        try:
            with open(cache_path) as fh:
                c = json.load(fh)
            if c.get("build") == bid:
                return {k: tuple(v) for k, v in c["anchors"].items()}
        except (OSError, ValueError):
            pass
    fps = load_fingerprints()
    out, errors, trees = {}, [], {}
    for name, fp in fps.items():
        fname = scene_level(fp["scene"]) if "scene" in fp else fp["file"]
        if fname is None:
            errors.append(f'{name}: scene "{fp["scene"]}" is not in this version of the game')
            continue
        try:
            env, f = open_file(fname)
            if fp["kind"] != "asset" and fname not in trees:
                trees[fname] = Tree(env, f)
            out[name] = (fname, find(env, f, fp, trees.get(fname)))
        except AnchorError as e:
            errors.append(f"{name}: {e}")
    if errors:
        raise AnchorError("this version of the game is missing things SSMod copies from:\n  " + "\n  ".join(errors))
    with open(cache_path, "w") as fh:
        json.dump({"build": bid, "anchors": out}, fh, indent=1)
    return out

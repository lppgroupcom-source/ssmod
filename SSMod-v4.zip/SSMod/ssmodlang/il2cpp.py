"""Type and method names from a game's global-metadata.dat (IL2CPP metadata v29 or v31, Unity 2021.3).

Only names and parameter counts: enough to check that a method still exists in this version of the game.
  python3 -m ssmodlang.il2cpp "/path/Game.app" > names.tsv
"""
import os
import struct
import sys


def read(meta_path):
    b = open(meta_path, "rb").read()
    sanity, version = struct.unpack_from("<Ii", b, 0)
    assert sanity == 0xFAB11BAF, "not an IL2CPP metadata file"
    pair = lambda i: struct.unpack_from("<ii", b, 8 + 8 * i)
    s_off, _ = pair(2)
    m_off, m_size = pair(5)
    p_off, p_size = pair(10)
    t_off, t_size = pair(19)

    def string(i):
        e = b.index(b"\0", s_off + i)
        return b[s_off + i:e].decode("utf-8", "replace")

    # v31 added returnParameterToken after returnType
    fmt = "<iiiiiiIHHHH" if version >= 31 else "<iiiiiIHHHH"
    MSZ, TSZ = struct.calcsize(fmt), 88
    FLAGS, NPARAM = (7, 10) if version >= 31 else (6, 9)
    assert m_size % MSZ == 0 and t_size % TSZ == 0, (version, m_size % MSZ, t_size % TSZ)
    methods = [struct.unpack_from(fmt, b, m_off + k * MSZ) for k in range(m_size // MSZ)]
    for k in range(t_size // TSZ):
        o = t_off + k * TSZ
        name_i, ns_i = struct.unpack_from("<ii", b, o)
        method_start = struct.unpack_from("<i", b, o + 9 * 4)[0]
        method_count = struct.unpack_from("<H", b, o + 16 * 4)[0]
        declaring = struct.unpack_from("<i", b, o + 3 * 4)[0]
        name, ns = string(name_i), string(ns_i)
        for m in methods[method_start:method_start + method_count] if method_start >= 0 else []:
            yield ns, name, declaring, string(m[0]), m[NPARAM], bool(m[FLAGS] & 0x10)     # flags 0x10 = static


if __name__ == "__main__":
    app = sys.argv[1]
    meta = os.path.join(app, "Contents", "Resources", "Data", "il2cpp_data", "Metadata", "global-metadata.dat")
    for ns, t, decl, m, n, static in read(meta):
        print(f"{ns}\t{t}\t{m}\t{n}\t{'static' if static else 'instance'}")

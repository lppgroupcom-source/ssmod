"""Reading and editing the game's Unity files (scenes and asset files), for any version of the game.

Started as the 2.1.9 helpers (sslevel.py); now the game folder comes from config.py and the class layouts come
from the player's own copy of the game (its GameAssembly + global-metadata), so nothing from the game ships with
SSMod and a game update just works.
"""
import os
import struct
import UnityPy
from UnityPy.helpers.TypeTreeGenerator import TypeTreeGenerator

from .config import clean_data, game_app, layout_dlls

UNITY_VERSION = "2021.3.40f1"
UnityPy.config.FALLBACK_UNITY_VERSION = UNITY_VERSION


def data_dir():
    """Where untouched game files are read from: the clean copy if ssmod.json names one, else the game itself."""
    return (clean_data() or os.path.join(game_app(), "Contents", "Resources", "Data")).rstrip("/") + "/"


class _BinaryLayouts(TypeTreeGenerator):
    """Layouts read from the game binary name assemblies without ".dll"; UnityPy asks with it."""
    def get_nodes(self, assembly, fullname):
        return super().get_nodes(assembly[:-4] if assembly.endswith(".dll") else assembly, fullname)


def _thin(dylib):
    """The slice of a universal Mach-O binary for this Mac's CPU (or the only slice)."""
    import platform
    b = open(dylib, "rb").read()
    if struct.unpack_from(">I", b, 0)[0] != 0xCAFEBABE:
        return b
    want = 0x0100000C if platform.machine() == "arm64" else 0x01000007
    n = struct.unpack_from(">I", b, 4)[0]
    slices = [struct.unpack_from(">iiIII", b, 8 + 20 * k) for k in range(n)]
    cpu, _, off, size, _ = next((s for s in slices if s[0] == want), slices[0])
    return b[off:off + size]


_generator = None


def layouts():
    """One generator for the whole run (building it takes ~20 s from the binary)."""
    global _generator
    if _generator is None:
        dlls = layout_dlls()
        if dlls:
            _generator = TypeTreeGenerator(UNITY_VERSION)
            _generator.load_local_dll_folder(dlls)
        else:
            app = game_app()
            ga = os.path.join(app, "Contents", "Frameworks", "GameAssembly.dylib")
            meta = os.path.join(app, "Contents", "Resources", "Data", "il2cpp_data", "Metadata", "global-metadata.dat")
            _generator = _BinaryLayouts(UNITY_VERSION)
            _generator.load_il2cpp(_thin(ga), open(meta, "rb").read())
    return _generator


def load(level, src=None):
    D = data_dir()
    first = UnityPy.load(src or D + level)
    f0 = list(first.files.values())[0]
    ext = [D + e.path.split("/")[-1] for e in f0.externals]
    ext = [p for p in ext if os.path.exists(p)]
    cwd = os.getcwd(); os.chdir(D)
    try:
        env = UnityPy.load(src or level, *[os.path.basename(p) for p in ext])
    finally:
        os.chdir(cwd)
    env.typetree_generator = layouts()
    f = [x for k, x in env.files.items() if k.endswith(level)][0]
    return env, f

import struct
_script_cache = {}
def script_name(env, f, obj):
    """Class name of a MonoBehaviour, resolved by hand from its raw m_Script pointer."""
    raw = obj.get_raw_data()
    fid, pid = struct.unpack_from("<iq", raw, 16)
    key = (f, fid, pid)          # the file itself (not id(f)): ids of freed files get reused
    if key in _script_cache:
        return _script_cache[key]
    try:
        tf = f if fid == 0 else next(x for k, x in env.files.items()
                                     if os.path.basename(k).lower() == f.externals[fid - 1].path.split("/")[-1].lower())
        name = tf.objects[pid].read().m_ClassName
    except Exception:
        name = "?"
    _script_cache[key] = name
    return name


import copy as _copy


def transform_of(f, go):
    for c in go.m_Component:
        p = c.component if hasattr(c, "component") else c
        if f.objects[p.m_PathID].type.name in ("Transform", "RectTransform"):
            return f.objects[p.m_PathID]


def hierarchy_ids(f, go_pid):
    """Path IDs of a GameObject, its components and all descendants."""
    ids = []

    def walk(pid):
        ids.append(pid)
        go = f.objects[pid].read()
        for c in go.m_Component:
            p = c.component if hasattr(c, "component") else c
            ids.append(p.m_PathID)
        for ch in transform_of(f, go).read().m_Children:
            walk(f.objects[ch.m_PathID].read().m_GameObject.m_PathID)

    walk(go_pid)
    return ids


def world_position(f, tr_pid):
    x = y = z = 0.0
    while tr_pid:
        t = f.objects[tr_pid].read()
        p, s = t.m_LocalPosition, t.m_LocalScale
        x, y, z = x * s.x + p.x, y * s.y + p.y, z + p.z
        tr_pid = t.m_Father.m_PathID
    return x, y, z


def remap_pptrs(node, m):
    if isinstance(node, dict):
        if set(node) == {"m_FileID", "m_PathID"}:
            if node["m_FileID"] == 0 and node["m_PathID"] in m:
                return {"m_FileID": 0, "m_PathID": m[node["m_PathID"]]}
            return node
        return {k: remap_pptrs(v, m) for k, v in node.items()}
    if isinstance(node, list):
        return [remap_pptrs(v, m) for v in node]
    return node


def clone_hierarchy(f, go_pid, edit):
    """Clone a GameObject hierarchy into f with fresh path IDs.

    edit(orig_pid, tree, mapping) may modify each cloned object's tree in place.
    Returns the mapping {orig_pid: new_pid}."""
    ids = hierarchy_ids(f, go_pid)
    nxt = max(f.objects) + 1
    m = {i: nxt + k for k, i in enumerate(ids)}
    for i in ids:
        clone = _copy.copy(f.objects[i])
        clone.path_id = m[i]
        try:
            tree = remap_pptrs(_copy.deepcopy(f.objects[i].read_typetree()), m)
        except Exception:
            # No usable layout (e.g. [SerializeReference] fields): patch local pointers in the raw bytes.
            clone.set_raw_data(remap_raw(f.objects[i].get_raw_data(), m))
        else:
            edit(i, tree, m)
            clone.save_typetree(tree)
        f.objects[m[i]] = clone
    return m


def remap_raw(data, m):
    """Rewrite every 4-byte-aligned local PPtr (fileID 0 + pathID in m) found in raw object bytes."""
    import struct
    b = bytearray(data)
    for off in range(0, len(b) - 11, 4):
        fid, pid = struct.unpack_from("<iq", b, off)
        if fid == 0 and pid in m:
            struct.pack_into("<q", b, off + 4, m[pid])
    return bytes(b)


def _ext_name(e):
    return e.path.split("/")[-1].lower()


class CrossFileCloner:
    """Clone a hierarchy from one serialized file into another, remapping local pointers,
    external file ids, serialized types and script references."""

    def __init__(self, src_env, src, dst_env, dst):
        self.se, self.s, self.de, self.d = src_env, src, dst_env, dst
        self.ext = {}
        self.types = {}

    def ext_id(self, fid):
        if fid == 0:
            return 0
        if fid not in self.ext:
            name = _ext_name(self.s.externals[fid - 1])
            for k, e in enumerate(self.d.externals, 1):
                if _ext_name(e) == name:
                    self.ext[fid] = k
                    break
            else:
                self.d.externals.append(_copy.copy(self.s.externals[fid - 1]))
                self.ext[fid] = len(self.d.externals)
        return self.ext[fid]

    def add_external(self, name):
        for k, e in enumerate(self.d.externals, 1):
            if _ext_name(e) == name.lower():
                return k
        e = _copy.copy(self.d.externals[-1])
        e.path = name
        self.d.externals.append(e)
        return len(self.d.externals)

    def type_id(self, tid):
        if tid in self.types:
            return self.types[tid]
        st = self.s.types[tid]
        script = None
        if st.script_type_index >= 0:
            ref = self.s.script_types[st.script_type_index]
            script = (self.ext_id(ref.local_serialized_file_index), ref.local_identifier_in_file)
        for k, dt in enumerate(self.d.types):
            if dt.class_id != st.class_id or dt.script_id != st.script_id:
                continue
            if script is None and dt.script_type_index < 0:
                self.types[tid] = k
                return k
            if script is not None and dt.script_type_index >= 0:
                r = self.d.script_types[dt.script_type_index]
                if (r.local_serialized_file_index, r.local_identifier_in_file) == script:
                    self.types[tid] = k
                    return k
        nt = _copy.copy(st)
        if script is not None:
            for k, r in enumerate(self.d.script_types):
                if (r.local_serialized_file_index, r.local_identifier_in_file) == script:
                    nt.script_type_index = k
                    break
            else:
                ref = _copy.copy(self.s.script_types[st.script_type_index])
                ref.local_serialized_file_index, ref.local_identifier_in_file = script
                self.d.script_types.append(ref)
                nt.script_type_index = len(self.d.script_types) - 1
        self.d.types.append(nt)
        self.types[tid] = len(self.d.types) - 1
        return self.types[tid]

    def _remap(self, node, m):
        if isinstance(node, dict):
            if set(node) == {"m_FileID", "m_PathID"}:
                fid, pid = node["m_FileID"], node["m_PathID"]
                if fid == 0:
                    return {"m_FileID": 0, "m_PathID": m.get(pid, 0) if pid else 0}
                return {"m_FileID": self.ext_id(fid), "m_PathID": pid}
            return {k: self._remap(v, m) for k, v in node.items()}
        if isinstance(node, list):
            return [self._remap(v, m) for v in node]
        return node

    def _remap_raw(self, data, m):
        import struct
        b = bytearray(data)
        files = {os.path.basename(k).lower(): x for k, x in self.se.files.items() if hasattr(x, "objects")}
        n = len(self.s.externals)
        for off in range(0, len(b) - 11, 4):
            fid, pid = struct.unpack_from("<iq", b, off)
            if fid == 0 and pid in m:
                struct.pack_into("<q", b, off + 4, m[pid])
            elif 1 <= fid <= n and pid > 0:
                tf = files.get(_ext_name(self.s.externals[fid - 1]))
                if tf is not None and pid in tf.objects:
                    struct.pack_into("<i", b, off, self.ext_id(fid))
        return bytes(b)

    ASSET_TYPES = {"Mesh", "Material", "Texture2D", "Sprite", "AnimationClip", "PhysicsMaterial2D", "Font",
                   "RenderTexture", "Cubemap", "AudioClip", "AnimatorController", "AnimatorOverrideController"}

    def _local_refs(self, pid):
        """Path ids of objects in the same file that this object points to."""
        out = set()
        o = self.s.objects[pid]
        try:
            tree = o.read_typetree()
        except Exception:
            import struct
            b = o.get_raw_data()
            for off in range(0, len(b) - 11, 4):
                fid, p = struct.unpack_from("<iq", b, off)
                if fid == 0 and p > 0 and p in self.s.objects:
                    out.add(p)
            return out

        def walk(n):
            if isinstance(n, dict):
                if set(n) == {"m_FileID", "m_PathID"}:
                    if n["m_FileID"] == 0 and n["m_PathID"]:
                        out.add(n["m_PathID"])
                    return
                for v in n.values():
                    walk(v)
            elif isinstance(n, list):
                for v in n:
                    walk(v)
        walk(tree)
        return out

    def clone_ids(self, go_pid):
        """The source objects a clone of go_pid copies: its hierarchy plus the local assets it uses."""
        ids = hierarchy_ids(self.s, go_pid)
        seen, queue = set(ids), list(ids)
        while queue:
            for p in self._local_refs(queue.pop()):
                if p not in seen and p in self.s.objects and self.s.objects[p].type.name in self.ASSET_TYPES:
                    seen.add(p)
                    ids.append(p)
                    queue.append(p)
        return ids

    def clone(self, go_pid, edit, extra=None):
        """extra: {source pid: destination pid} for pointers to objects outside this hierarchy.
        Local assets the hierarchy uses (meshes, materials, ...) are copied along, or they'd be lost.
        New ids are max(existing) + 1, + 2, ... in clone_ids order."""
        ids = self.clone_ids(go_pid)
        nxt = max(self.d.objects) + 1
        m = {i: nxt + k for k, i in enumerate(ids)}
        created = dict(m)
        m.update(extra or {})
        for i in ids:
            src = self.s.objects[i]
            new = _copy.copy(src)
            new.assets_file = self.d
            new.path_id = m[i]
            new.type_id = self.type_id(src.type_id)
            try:
                tree = _copy.deepcopy(src.read_typetree())
            except Exception:
                data = self._remap_raw(src.get_raw_data(), m)
            else:
                # The generated layout can misread m_Script (it comes back byte-swapped), so
                # leave it alone here and re-point it from the raw bytes after saving.
                script = tree.pop("m_Script", None)
                tree = self._remap(tree, m)
                edit(i, tree, m)
                if script is not None:
                    ordered = {}
                    for k, v in src.read_typetree().items():
                        ordered[k] = script if k == "m_Script" else tree[k]
                    tree = ordered
                data = _copy.copy(src).save_typetree(tree)
                if script is not None:
                    import struct
                    b = bytearray(data)
                    fid, pid = struct.unpack_from("<iq", src.get_raw_data(), 16)
                    struct.pack_into("<iq", b, 16, self.ext_id(fid), pid)
                    data = bytes(b)
            new.set_raw_data(data)
            self.d.objects[m[i]] = new
        return created


def mb_name(obj):
    """m_Name of a MonoBehaviour straight from its raw bytes (no layout lookup needed)."""
    import struct
    b = obj.get_raw_data()
    n = struct.unpack_from("<i", b, 28)[0]
    return b[32:32 + n].decode("utf-8", "replace")

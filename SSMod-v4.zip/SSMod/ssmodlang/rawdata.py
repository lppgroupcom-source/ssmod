"""Raw (de)serialisers for MonoBehaviours UnityPy can't read (ItemData, ShopItemData) in 2.1.9.

A layout is a list of (field, kind) with kind in: pptr, bool, i32, f32, str, color, raw:N.
parse() returns {field: (offset, value)} plus "_end"; build() writes a new blob from a parsed
dict and a {field: new value} patch, copying everything after the last parsed field verbatim.
"""
import struct

HEAD = [("m_GameObject", "pptr"), ("m_Enabled", "bool"), ("m_Script", "pptr"), ("m_Name", "str"), ("id", "str")]

SHOP_ITEM = HEAD + [
    ("hasCustomLabel", "bool"), ("customLabel", "pptr"), ("customString", "str"), ("customStringKey", "str"),
    ("price", "i32"), ("currency", "pptr"), ("worldObjectPrefab", "pptr"), ("tool", "pptr"), ("disguise", "pptr"),
    ("equipment", "pptr"), ("item", "pptr"), ("vehicleCargo", "pptr"), ("vehicleCargoQuantity", "i32"),
    ("furniture", "pptr"), ("flag", "pptr"), ("shoppingBonanza", "bool"), ("extendedWarrantyCost", "i32"),
    ("expressDeliveryCost", "i32"), ("requiresDelivery", "bool"), ("allowBuyMultiple", "bool"), ("buyMultiple", "bool"),
    ("buyQuantity", "i32"), ("limitPerDay", "i32"), ("warrantyFlag", "pptr"), ("customDialog", "pptr"),
    ("postBuyDialog", "pptr"), ("condition", "pptr"), ("confirmPurchaseCondition", "pptr"), ("confirmPurchaseDialog", "pptr"),
]

ITEM = HEAD + [
    ("label", "str"), ("labelLocKey", "str"), ("englishSingularMode", "i32"), ("englishPluralMode", "i32"),
    ("englishCustomPlural", "str"), ("description", "str"), ("descriptionLocKey", "str"), ("receiveDialog", "pptr"),
    ("isDebug", "bool"), ("type", "i32"), ("category", "i32"), ("unique", "bool"), ("showInInventory", "bool"),
    ("eligibleForDailyChallenges", "bool"), ("allowOnTVShop", "bool"), ("containerItemPrefab", "pptr"),
    ("replaceSprite", "bool"), ("mainSprite", "pptr"), ("worldSprite", "pptr"),
]


def _align(p):
    return (p + 3) & ~3


def parse(b, layout):
    out, p = {}, 0
    for name, kind in layout:
        start = p
        if kind == "pptr":
            v = struct.unpack_from("<iq", b, p); p += 12
        elif kind == "bool":
            v = b[p]; p = _align(p + 1)
        elif kind == "i32":
            v = struct.unpack_from("<i", b, p)[0]; p += 4
        elif kind == "f32":
            v = struct.unpack_from("<f", b, p)[0]; p += 4
        elif kind == "str":
            n = struct.unpack_from("<i", b, p)[0]
            if not 0 <= n < 1 << 20:
                raise ValueError(f"bad string length {n} at {p} ({name})")
            v = b[p + 4:p + 4 + n].decode("utf-8"); p = _align(p + 4 + n)
        else:
            raise ValueError(kind)
        out[name] = (start, v)
    out["_end"] = (p, None)
    return out


def _enc(kind, v):
    if kind == "pptr":
        return struct.pack("<iq", *v)
    if kind == "bool":
        return bytes([1 if v else 0, 0, 0, 0])
    if kind == "i32":
        return struct.pack("<i", v)
    if kind == "f32":
        return struct.pack("<f", v)
    if kind == "str":
        e = v.encode("utf-8")
        return struct.pack("<i", len(e)) + e + b"\0" * (_align(len(e)) - len(e))
    raise ValueError(kind)


def build(b, layout, patch):
    parsed = parse(b, layout)
    out = bytearray()
    for name, kind in layout:
        out += _enc(kind, patch.get(name, parsed[name][1]))
    out += b[parsed["_end"][0]:]
    return bytes(out)


def append_to_library(b, pptrs):
    """LevelLibrary / ItemLibrary / ShopItemLibrary: name, then int count + 12-byte PPtrs."""
    n = struct.unpack_from("<i", b, 28)[0]
    off = 32 + _align(n)
    count = struct.unpack_from("<i", b, off)[0]
    end = off + 4 + count * 12
    b = bytearray(b)
    b[end:end] = b"".join(struct.pack("<iq", *p) for p in pptrs)
    struct.pack_into("<i", b, off, count + len(pptrs))
    return bytes(b), count + len(pptrs)

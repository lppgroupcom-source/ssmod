"""Where the game is. One place for every tool, so SSMod works on a machine that isn't the author's.

Order: the SSMOD_GAME environment variable, then "game" in ssmod.json next to the ssmod script, then the default
(a Finder duplicate of the game in ~/Downloads/Sasquatch_2.1.9). The value is the .app; mods go into its Data folder.
"""
import json
import os

HOME = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG = os.path.join(HOME, "ssmod.json")
DEFAULT_APP = "~/Downloads/Sasquatch_2.1.9/Sasquatch Hidden Content.app"


def load_config():
    if os.path.exists(CONFIG):
        try:
            with open(CONFIG) as fh:
                return json.load(fh)
        except (OSError, ValueError):
            return {}
    return {}


def game_app():
    app = os.environ.get("SSMOD_GAME") or load_config().get("game") or DEFAULT_APP
    return os.path.abspath(os.path.expanduser(app))


def game_data():
    return os.path.join(game_app(), "Contents", "Resources", "Data")


def decompiled_sources():
    """The decompiled C# classes (only needed by the graph validator); None if they aren't on this machine."""
    p = os.path.expanduser(load_config().get("sources") or
                           "~/Downloads/SneakySasquatch_Decompiled/csharp_projects/Assembly-CSharp")
    return p if os.path.isdir(p) else None


def game_version():
    """The game's version from its Info.plist ("2.1.9", "2.2", ...); None if it can't be read."""
    import plistlib
    try:
        with open(os.path.join(game_app(), "Contents", "Info.plist"), "rb") as fh:
            return plistlib.load(fh).get("CFBundleShortVersionString")
    except (OSError, ValueError):
        return None


def _per_version(key):
    """ssmod.json values that only fit one game version: {"clean": {"2.1.9": "path"}, ...}."""
    v = load_config().get(key)
    if isinstance(v, dict):
        v = v.get(game_version() or "")
    if not v:
        return None
    p = os.path.expanduser(v)
    return p if os.path.isdir(p) else None


def clean_data():
    """An untouched copy of this version's Data folder to read templates from (optional; the author's machine has
    one because the game copy carries mods from before SSMod). Without it the game's own files are used."""
    return _per_version("clean")


def layout_dlls():
    """A folder of Il2CppDumper DummyDlls for this version (optional; without it the layouts are read from the
    game binary itself)."""
    return _per_version("dlls")

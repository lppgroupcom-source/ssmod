"""Sounds for mods: a WAV (or anything ffmpeg can read) -> an FMOD FSB5 sound bank with 16-bit PCM, the format
Unity stores AudioClips in (inside .resource files). SSMod writes its sounds to its own Data/ssmod.resource.

FSB5 layout (version 1):
  "FSB5", version, sample count, sample headers size, name table size, data size, mode (2 = PCM16),
  8 zero bytes, 16-byte hash, 8 bytes  (60 bytes)
  per sample, one 64-bit header: bit 0 more chunks follow | bits 1-4 frequency code | bit 5 stereo |
  bits 6-33 data offset / 16 | bits 34-63 sample frames
  then the sample data (interleaved little-endian int16).
"""
import array
import os
import shutil
import struct
import subprocess
import tempfile
import wave

FREQ_CODES = {8000: 1, 11000: 2, 11025: 3, 16000: 4, 22050: 5, 24000: 6, 32000: 7, 44100: 8, 48000: 9}
MAX_SECONDS = 300


class AudioError(Exception):
    pass


def _resample(samples, channels, src, dst):
    """Linear resampling of interleaved int16 samples (only used when the file isn't at a rate FMOD stores)."""
    frames = len(samples) // channels
    out_frames = int(frames * dst / src)
    out = array.array("h", bytes(out_frames * channels * 2))
    step = src / dst
    for i in range(out_frames):
        p = i * step
        j = int(p)
        f = p - j
        j2 = min(j + 1, frames - 1)
        for c in range(channels):
            a, b = samples[j * channels + c], samples[j2 * channels + c]
            out[i * channels + c] = int(a + (b - a) * f)
    return out


def _read_wav(path):
    with wave.open(path, "rb") as w:
        channels, width, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    if width == 1:                                     # 8-bit wav is unsigned
        samples = array.array("h", ((b - 128) << 8 for b in raw))
    elif width == 2:
        samples = array.array("h", raw)
    elif width == 3:
        samples = array.array("h", (int.from_bytes(raw[i + 1:i + 3], "little", signed=True) for i in range(0, len(raw), 3)))
    elif width == 4:
        samples = array.array("h", (struct.unpack_from("<i", raw, i)[0] >> 16 for i in range(0, len(raw), 4)))
    else:
        raise AudioError(f"unsupported wav sample size ({width * 8} bits)")
    return samples, channels, rate


def load(path):
    """-> (int16 samples interleaved, channels, frequency). WAV directly; MP3/OGG/M4A/... through ffmpeg."""
    if not os.path.exists(path):
        raise AudioError(f"can't find {path}")
    if path.lower().endswith(".wav"):
        try:
            samples, channels, rate = _read_wav(path)
        except (wave.Error, EOFError) as e:
            raise AudioError(f"can't read {os.path.basename(path)} as a wav ({e}); save it as 16-bit PCM wav")
    else:
        ff = shutil.which("ffmpeg")
        if not ff:
            raise AudioError(f"{os.path.basename(path)} isn't a .wav and ffmpeg isn't installed; save it as a .wav")
        with tempfile.TemporaryDirectory() as tmp:
            out = os.path.join(tmp, "s.wav")
            r = subprocess.run([ff, "-y", "-v", "error", "-i", path, "-ar", "44100", "-sample_fmt", "s16", out],
                               capture_output=True)
            if r.returncode:
                raise AudioError(f"ffmpeg couldn't read {os.path.basename(path)}: {r.stderr.decode()[:200]}")
            samples, channels, rate = _read_wav(out)
    if channels > 2:
        raise AudioError("sounds can be mono or stereo, not more channels")
    if rate not in FREQ_CODES:
        samples, rate = _resample(samples, channels, rate, 44100), 44100
    if len(samples) // channels > MAX_SECONDS * rate:
        raise AudioError(f"sounds can be at most {MAX_SECONDS // 60} minutes long")
    if not samples:
        raise AudioError("the sound is empty")
    return samples, channels, rate


def fsb5(samples, channels, rate):
    """One-sample FSB5 bank with 16-bit PCM."""
    frames = len(samples) // channels
    if frames >= 1 << 30:
        raise AudioError("sound too long")
    data = samples.tobytes() if hasattr(samples, "tobytes") else bytes(samples)
    data += b"\0" * (-len(data) % 32)
    head = (FREQ_CODES[rate] << 1) | ((1 if channels == 2 else 0) << 5) | (0 << 6) | (frames << 34)
    sample_headers = struct.pack("<Q", head)
    header = b"FSB5" + struct.pack("<IIIIII", 1, 1, len(sample_headers), 0, len(data), 2) + b"\0" * 8 + b"\0" * 16 + b"\0" * 8
    return header + sample_headers + data


def length_seconds(samples, channels, rate):
    return len(samples) / channels / rate

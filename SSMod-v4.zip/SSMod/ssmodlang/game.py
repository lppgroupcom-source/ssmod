"""Backend: apply parsed .ssmod files to Sneaky Sasquatch's data files (written on 2.1.9, works on 2.2).

The objects it copies from are found by name for whichever version is installed (anchors.py); the numbers below
are what they were in 2.1.9. Techniques (unity.py, rawdata.py):
  flags        FlagVariable clones (resources.assets)
  items        raw ItemData clones registered in the Item Library
  dialogues    DialogueTree clones with a compiled NodeCanvas graph
  npc          Lake Maze camper (level53 #234, senses off) + a copy of Doctor Duck's talk object (level8 #130)
  spot         Town's "Check shoes" interaction (level118 #3085/#5077) with an office-computer sized trigger,
               optionally a "?" bubble (level8 #1013)
  pickup       the Campsite C/D ground item (level13 #3086) repointed to an item
Everything is written on top of a snapshot ("base") of the Hidden Content files, so installs are repeatable.
"""
import copy
import difflib
import hashlib
import json
import math
import os
import re
import struct
import sys
import uuid

import UnityPy  # noqa: E402

from .unity import load, transform_of, script_name, hierarchy_ids, clone_hierarchy, CrossFileCloner, world_position, mb_name  # noqa: E402
from . import rawdata  # noqa: E402
from . import anchors  # noqa: E402
from .config import clean_data  # noqa: E402
from . import calls  # noqa: E402

from .meshes import sprite_buffers
from .syntax import SSModError, EXIT_IDS, PlaceDecl, Loc, BLOCKS  # noqa: E402

# framed doors: the tree house's door frame and open door, scaled up a little
DOOR_SCENE, DOOR_FRAME, DOOR_PANEL = "Campground_TreeInterior", "Decoration/house_tree_door_frame", "Decoration/ShoddyDoor"
DOOR_SCALES = {"South": 1.6, "North": 1.3}             # a top-wall door has to fit on the wall face (about 133 high)
DOOR_ZONE_DEPTH = 240.0                   # the exit zone is as wide as the frame and this deep
DOOR_ZONE_IN_SOUTH, DOOR_ZONE_IN_NORTH = 95.0, 60.0    # how far the zone reaches into the room from the wall
DOOR_EXIT_IN, DOOR_ENTER_IN = 30.0, 190.0             # where you walk out to / arrive, measured in from the wall
from .dialogue import DialogueCompiler  # noqa: E402
from .bt import ScriptCompiler  # noqa: E402

FLAG_TEMPLATE, DIALOG_TEMPLATE = 114225, 114226
STRINGVAR_TEMPLATE, STRINGDATA_TEMPLATE = 118096, 119274
ITEM_LIBRARY = 115674
DEFAULT_ITEM_BASE = 115404                      # SodaCup: a plain carryable item
CAMPER_LEVEL, CAMPER = "level53", 234
TALK_LEVEL, TALK_GO = "level8", 130
PROP_LEVEL, PROP_ACTION_GO, PROP_DIALOG_GO = "level118", 3085, 5077
BUBBLE_LEVEL, BUBBLE_GO = "level8", 1013
PICKUP_LEVEL, PICKUP_GI = "level13", 3086
ACTION_AREA = ({"x": 155.8128, "y": 99.3722}, {"x": 0.3981, "y": -19.7110})
RES_SA0 = 3                                     # sharedassets0.assets as seen from resources.assets
SCRIPT_LEVEL, SCRIPT_HOST_GO, SCRIPT_BT = "level10", 15, 2431   # "Camper Inside RV Patrol AI Behaviour" + its tree
LEVEL_LIBRARY = 118650
TOWNHALL_ELEVATOR, PANEL_6 = 118568, 14451             # resources ElevatorData template, 6-button panel
ELEVATOR_LEVEL, ELEVATOR_GO = "level123", 344          # Office_Floor_2's self-contained elevator
ROUTE_LEVEL, ROUTE_GO = "level118", 1153                # "Camper (Cashier) Patrol Route (2)": PatrolRoute + ActionPlayer
ACTIVATOR_LEVEL, ACTIVATOR_MB = "level8", 4656            # hub "Sign Activator" (ConditionActivator)
DOOR_LEVEL, DOOR_GO = "level16", 99                          # Campground_TreeInterior "Exit South" (a walk-through door)
ROOM_ROOT = "Town Hall B1"                                   # rooms that `room` can resize (TownHall_Floor_B1 copies)
ROOM_KEEP = {"InteriorArea", "SearchLocation (1)", "SearchLocation (2)", "Interior Lights", "Wall (1)", "Floor",
             "InteriorWall_1x36 (1)", "InteriorWall_1x36", "InteriorWall_4x1", "InteriorWall_4x1 (1)"}
ROOT_KEEP = {"LevelController", "AreaBounds", "Custom Pathfind Area", "Custom Frame Bounds", ROOM_ROOT}
WEATHER = {"Clear": 118773, "Rainy": 118775, "Snowy": 118777, "SnowyHeavy": 118776}   # resources WeatherData
RANDOM_CAMPER_ACTOR, BEARD_LONG = 4101, 4157            # sharedassets0: Human_Camper_Random, Camper Beard Long
ANCHOR_CACHE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "anchor_cache.json")


def clean_load(name, base_dir):
    """A game file as it is without SSMod: the clean copy if configured, else our pre-install snapshot in base/,
    else the game's own (SSMod hasn't touched it)."""
    if not clean_data():
        own = os.path.join(base_dir, name)
        if os.path.exists(own):
            return load(name, src=own)
    return load(name)


def use_anchors(base_dir, scene_level):
    """Point the constants above at this game version's objects (found by name, cached per build)."""
    from .unity import data_dir
    files = {}

    def open_file(fn):
        if fn not in files:
            files[fn] = clean_load(fn, base_dir)
        return files[fn]

    found = anchors.resolve_all(open_file, scene_level, data_dir(), ANCHOR_CACHE)
    g = globals()
    for name, (fn, pid) in found.items():
        if name.startswith("WEATHER_"):
            WEATHER[name[8:]] = pid
            continue
        g[name] = pid
        level = {"CAMPER": "CAMPER_LEVEL", "TALK_GO": "TALK_LEVEL", "BUBBLE_GO": "BUBBLE_LEVEL",
                 "PROP_ACTION_GO": "PROP_LEVEL", "PICKUP_GI": "PICKUP_LEVEL", "SCRIPT_HOST_GO": "SCRIPT_LEVEL",
                 "ELEVATOR_GO": "ELEVATOR_LEVEL", "ROUTE_GO": "ROUTE_LEVEL", "ACTIVATOR_MB": "ACTIVATOR_LEVEL",
                 "DOOR_GO": "DOOR_LEVEL"}.get(name)
        if level:
            g[level] = fn


def call_blackboard_name(m, level):
    return f"SSMod_{m.slug}_{level}"


def carl_look(tree, beard):
    """Blaze-orange hunting vest and jeans (from the Cryptid Carl mod)."""
    def rgba(r, g, b):
        return {"r": r, "g": g, "b": b, "a": 1.0}
    tree.update(shirtColor=rgba(1.00, 0.42, 0.05), pantsColor=rgba(0.20, 0.30, 0.58),
                shoeColor=rgba(0.30, 0.18, 0.08), hairColor=rgba(0.72, 0.32, 0.12),
                beardColor=rgba(0.72, 0.32, 0.12), hasGloves=True, gloveColor=rgba(0.10, 0.10, 0.10),
                beard=beard, chubbiness=0.6)


def depth(y):
    return 374.0 + 0.1 * y


def pptr(p, fid=0):
    return {"m_FileID": fid, "m_PathID": p}


def norm(s):
    return re.sub(r"[^a-z0-9]", "", s.lower())


def slug(s):
    return re.sub(r"[^a-z0-9]+", "_", s.lower()).strip("_")[:24] or "mod"


def rgba(hexs):
    return {"r": int(hexs[0:2], 16) / 255, "g": int(hexs[2:4], 16) / 255, "b": int(hexs[4:6], 16) / 255, "a": 1.0}


# npc look { ... }: option -> CamperBaseLook field
LOOK_COLORS = {"shirt": "shirtColor", "pants": "pantsColor", "skin": "skinColor", "shoes": "shoeColor",
               "socks": "sockColor", "hair": "hairColor", "beard": "beardColor", "eyes": "eyeColor", "gloves": "gloveColor"}
LOOK_TYPE_NAMES = {"shirtType": {"None": 0, "NoSleeves": 1, "ShortSleeve": 2, "LongSleeve": 3},
                   "pantsType": {"None": 0, "Shorts": 1, "Full": 2, "Capri": 3},
                   "shoeType": {"None": 0, "Normal": 1, "Socks": 2, "Boot": 3, "KneeBoot": 4, "TallSocks": 5}}
LOOK_TYPES = {k: {norm(n): v for n, v in d.items()} for k, d in LOOK_TYPE_NAMES.items()}


def suggest(name, choices):
    m = difflib.get_close_matches(name, list(choices), n=3, cutoff=0.5)
    return f" Did you mean: {', '.join(m)}?" if m else ""


# ---------------------------------------------------------------- catalog
class Catalog:
    def __init__(self, base_dir, cache_path):
        self.base_dir = base_dir
        self.cache_path = cache_path
        self._scenes = None
        self._static = None

    def scenes(self):
        """scene name (lowercase) -> (display name, level file)."""
        if self._scenes is None:
            env = UnityPy.load(os.path.join(self.base_dir, "globalgamemanagers"))
            f = list(env.files.values())[0]
            bs = next(o for o in f.objects.values() if o.type.name == "BuildSettings").read_typetree()
            self._scenes = {}
            for i, p in enumerate(bs["scenes"]):
                name = os.path.splitext(os.path.basename(p))[0]
                self._scenes.setdefault(name.lower(), (name, f"level{i}"))
                self._scenes.setdefault(f"level{i}", (name, f"level{i}"))
        return self._scenes

    def add_scene(self, name, level):
        self.scenes()
        self._scenes[name.lower()] = (name, level)
        self._scenes[level] = (name, level)

    def scene_file(self, name, tok, path):
        s = self.scenes()
        key = name.lower()
        if key not in s:
            raise SSModError(f'unknown scene "{name}".' + suggest(name, [v[0] for v in s.values()]), tok, path)
        return s[key][1]

    def static(self):
        """Sprites, actor data (they don't change between installs): cached in a json file."""
        if self._static is None:
            from .unity import data_dir
            bid = anchors.build_id(data_dir())
            if os.path.exists(self.cache_path):
                with open(self.cache_path) as fh:
                    self._static = json.load(fh)
                if self._static.get("build", bid) != bid:          # another game version: build it again
                    self._static = None
            if self._static is None:
                sprites, actors = {}, {}
                global RES_SA0
                for fn in ("resources.assets", "sharedassets0.assets"):
                    env, f = clean_load(fn, self.base_dir)
                    if fn == "resources.assets":
                        fid = 0
                        RES_SA0 = next(i + 1 for i, e in enumerate(f.externals)
                                       if e.path.split("/")[-1].lower() == "sharedassets0.assets")
                    else:
                        fid = RES_SA0
                    for pid, o in f.objects.items():
                        if o.type.name == "Sprite":
                            b = o.get_raw_data()
                            n = struct.unpack_from("<i", b, 0)[0]
                            name = b[4:4 + n].decode("utf-8", "replace")
                            key = norm(re.sub(r"sprite$", "", name, flags=re.I))
                            sprites.setdefault(key, [fid, pid, name])
                        elif fn == "sharedassets0.assets" and o.type.name == "MonoBehaviour":
                            if script_name(env, f, o) == "ActorData":
                                actors.setdefault(norm(mb_name(o) or ""), [pid, mb_name(o)])
                self._static = {"sprites": sprites, "actors": actors, "build": bid}
                with open(self.cache_path, "w") as fh:
                    json.dump(self._static, fh)
        return self._static


# ---------------------------------------------------------------- builder
class Builder:
    def __init__(self, base_dir, out_dir, catalog, log=print):
        self.base, self.out, self.cat, self.log = base_dir, out_dir, catalog, log
        use_anchors(base_dir, lambda s: catalog.scenes().get(s.lower(), (None, None))[1])
        self.env, self.res = load("resources.assets", src=os.path.join(base_dir, "resources.assets"))
        self.R = self.res.objects
        global RES_SA0
        RES_SA0 = next(i + 1 for i, e in enumerate(self.res.externals)
                       if e.path.split("/")[-1].lower() == "sharedassets0.assets")
        self._libs = {}            # library path id -> its bytes with our additions (see library_add)
        self.items = self._game_items()
        self.disguises = {norm(mb_name(o) or ""): p for p, o in self.R.items()
                          if o.type.name == "MonoBehaviour" and (mb_name(o) or "").startswith("Disguise_")}
        self.written = set()
        self.new_scenes = {}       # level file -> info about an area created by a mod
        self.pending_areas = set()  # new areas whose LevelData isn't made yet

    def library_add(self, lib_pid, path_id):
        """Register an object in a library (ItemLibrary, LevelLibrary).

        get_raw_data() always returns the bytes that were on disk, NOT what set_raw_data() stored, so the
        library being built is kept here; reading it back from the object would drop every earlier entry.
        """
        cur = self._libs.get(lib_pid) or self.R[lib_pid].get_raw_data()
        self._libs[lib_pid], _ = rawdata.append_to_library(cur, [(0, path_id)])
        self.R[lib_pid].set_raw_data(self._libs[lib_pid])

    def _game_items(self):
        lib = self.R[ITEM_LIBRARY].get_raw_data()
        n = struct.unpack_from("<i", lib, 28)[0]
        off = 32 + ((n + 3) & ~3)
        items = {}
        for k in range(struct.unpack_from("<i", lib, off)[0]):
            fid, pid = struct.unpack_from("<iq", lib, off + 4 + 12 * k)
            if fid or pid not in self.R:
                continue
            try:
                d = rawdata.parse(self.R[pid].get_raw_data(), rawdata.ITEM)
            except Exception:
                continue
            info = {"pid": pid, "label": d["label"][1], "sprite": d["mainSprite"][1]}
            for key in (d["label"][1], d["m_Name"][1], d["id"][1]):
                if key:
                    items.setdefault(norm(key), info)
        return items

    def new_id(self):
        return max(self.R) + 1

    def same_file_copy(self, pid, edit_tree):
        src = self.R[pid]
        t = src.read_typetree()
        edit_tree(t)
        new = copy.copy(src)
        new.path_id = self.new_id()
        new.save_typetree(t)
        self.R[new.path_id] = new
        return new.path_id

    # ---- per mod: resources-level objects
    def build_mod(self, mf):
        m = ModState(mf, slug(mf.info.name))
        for fd in mf.flags:
            if fd.name in m.flags:
                raise SSModError(f"flag {fd.name} is declared twice", fd.tok, mf.path)
            m.flags[fd.name] = self.same_file_copy(FLAG_TEMPLATE, lambda t, n=fd.name: t.update(
                m_Name=f"FlagVariable - ssmod {m.slug} {n}", flagName=f"ssm_{m.slug}_{n}"))
        for it in mf.items:
            self.build_item(m, it)
        for sd in mf.sounds:
            self.build_sound(m, sd)
        for th in list(mf.things) + list(mf.overrides):
            if not th.dialogue:
                continue
            dc = DialogueCompiler(lambda kind, name, tok: self.resolve(m, kind, name, tok), mf.path,
                                  scene_object=lambda t, p, tok, th=th: self.scene_object(m, th, t, p, tok))
            graph, refs = dc.compile(th.dialogue)
            for t in dc.notes:
                self.log(f"  note: {th.name} (line {t.line}): a choice had no line of speech before it, so \"What'll it be?\" "
                         f"was added. Write  choice \"your question\" {{ ... }}  to pick the words.")
            key = th.name if type(th).__name__ == "ThingDecl" else "override:" + th.name
            m.dialogs[key] = self.same_file_copy(DIALOG_TEMPLATE, lambda t, n=th.name, g=graph, r=refs: t.update(
                m_Name=f"Dialog - ssmod {m.slug} {n}", _serializedGraph=g, _objectReferences=r, _deserializationFailed=False))
        return m

    AUDIO_FILE = "ssmod.resource"          # every mod's sounds, next to the game's own .resource files

    def build_sound(self, m, sd):
        """A new AudioClip (16-bit PCM in an FMOD bank, stored in Data/ssmod.resource) and an AudioAsset to play it,
        both copies of game objects with our own data."""
        from . import audio
        try:
            samples, channels, rate = audio.load(sd.path)
        except audio.AudioError as e:
            raise SSModError(f"sound {sd.name}: {e}", sd.tok, m.mf.path)
        bank = audio.fsb5(samples, channels, rate)
        blob = self.__dict__.setdefault("audio_blob", bytearray())
        blob += b"\0" * (-len(blob) % 32)
        offset = len(blob)
        blob += bank
        tmpl_clip = next((p_ for p_, o in self.R.items() if o.type.name == "AudioClip"), None)
        tmpl_asset = next((p_ for p_, o in self.R.items() if o.type.name == "MonoBehaviour"
                           and (mb_name(o) or "").startswith("sfx_") and script_name(self.env, self.res, o) == "AudioAsset"), None)
        if tmpl_clip is None or tmpl_asset is None:
            raise SSModError("this version of the game has no sounds to copy", sd.tok, m.mf.path)
        clip = self.same_file_copy(tmpl_clip, lambda t: t.update(
            m_Name=f"ssmod {m.slug} {sd.name}", m_LoadType=0, m_Channels=channels, m_Frequency=rate, m_BitsPerSample=16,
            m_Length=audio.length_seconds(samples, channels, rate), m_IsTrackerFormat=False, m_Ambisonic=False,
            m_SubsoundIndex=0, m_PreloadAudioData=True, m_LoadInBackground=False,
            m_Resource={"m_Source": self.AUDIO_FILE, "m_Offset": offset, "m_Size": len(bank)}, m_CompressionFormat=0))
        m.sounds[sd.name] = self.same_file_copy(tmpl_asset, lambda t: t.update(
            m_Name=f"sfx_ssmod {m.slug} {sd.name}", volume=float(sd.volume), clip=pptr(clip), randomizeOffset=0))

    def build_item(self, m, it):
        props = {k: v[0] for k, v in it.props.items() if isinstance(v, tuple)}
        tok = it.tok
        if it.name in m.items:
            raise SSModError(f"item {it.name} is declared twice", tok, m.mf.path)
        base_pid = DEFAULT_ITEM_BASE
        if "base" in props:
            base_pid = self.game_item(props["base"], tok, m.mf.path)["pid"]
        patch = {"m_Name": f"Item - ssmod {m.slug} {it.name}", "id": f"ssm_{m.slug}_{it.name}"[:40],
                 "label": props.get("name", it.name), "labelLocKey": "",
                 "description": props.get("description", ""), "descriptionLocKey": "", "isDebug": 0, "showInInventory": 1}
        icon = props.get("icon")
        if icon is not None:
            if isinstance(icon, tuple) and icon[0] == "call" and icon[1] == "sprite" and icon[2]:
                name = icon[2][0]
            elif isinstance(icon, str):
                name = icon
            else:
                raise SSModError('icon must be sprite("name") or "name"', tok, m.mf.path)
            sp = self.cat.static()["sprites"].get(norm(re.sub(r"sprite$", "", name, flags=re.I)))
            if not sp:
                raise SSModError(f'unknown sprite "{name}".' + suggest(norm(name), self.cat.static()["sprites"]), tok, m.mf.path)
            patch["mainSprite"] = (sp[0], sp[1])
        for key in ("price", "sellPrice"):
            if key in props:
                raise SSModError("items can't have a price directly; sell them in a dialogue with take coins / give", tok, m.mf.path)
        src = self.R[base_pid]
        data = rawdata.build(src.get_raw_data(), rawdata.ITEM, patch)
        new = copy.copy(src)
        new.path_id = self.new_id()
        new.set_raw_data(data)
        self.R[new.path_id] = new
        self.library_add(ITEM_LIBRARY, new.path_id)
        sprite = patch.get("mainSprite") or rawdata.parse(src.get_raw_data(), rawdata.ITEM)["mainSprite"][1]
        m.items[it.name] = {"pid": new.path_id, "label": patch["label"], "sprite": tuple(sprite)}

    def game_item(self, name, tok, path):
        it = self.items.get(norm(name))
        if not it:
            raise SSModError(f'unknown game item "{name}".' + suggest(norm(name), self.items), tok, path)
        return it

    def resolve(self, m, kind, name, tok):
        path = m.mf.path
        if kind == "flag":
            if name not in m.flags:
                raise SSModError(f"unknown flag '{name}'. Declare it at the top:  flag {name};", tok, path)
            return 0, m.flags[name]
        if kind == "item":
            if name in m.items:
                return 0, m.items[name]["pid"]
            return 0, self.game_item(name, tok, path)["pid"]
        if kind == "disguise":
            key = norm(name)
            pid = self.disguises.get(key) or self.disguises.get(norm("Disguise_" + name))
            if not pid:
                raise SSModError(f'unknown disguise "{name}".' + suggest(key, self.disguises), tok, path)
            return 0, pid
        if kind == "stringvar":
            if name not in m.strvars:
                m.strvars[name] = self.same_file_copy(STRINGVAR_TEMPLATE, lambda t: t.update(
                    m_Name=f"StringVariable - ssmod {m.slug} {name}", value="",
                    varName="s" + hashlib.sha1(f"{m.slug}/{name}".encode()).hexdigest()[:8], defaultValueObject=pptr(0)))
            return 0, m.strvars[name]
        if kind == "title":
            if name not in m.titles:
                m.titles[name] = self.same_file_copy(STRINGDATA_TEMPLATE, lambda t: t.update(
                    m_Name=f"StringData - ssmod {m.slug} title", value=name, localizationTag="ignore"))
            return 0, m.titles[name]
        if kind == "asset":
            return self.find_asset(name[0], name[1], tok, path)
        if kind == "sound":
            if name not in m.sounds:
                raise SSModError(f'unknown sound {name}. Declare it at the top:  sound {name} from "file.wav";', tok, path)
            return 0, m.sounds[name]
        if kind == "timefloat":                     # a clock time for `hour`: (hour 0-23, minute)
            cache = self.__dict__.setdefault("_timefloats", {})
            if name not in cache:
                tmpl = next((p_ for p_, o in self.R.items() if o.type.name == "MonoBehaviour"
                             and (mb_name(o) or "").startswith("TimeFloat - ")
                             and script_name(self.env, self.res, o) == "TimeFloatData"), None)
                if tmpl is None:
                    raise SSModError("this version of the game has no TimeFloat assets to copy for `hour`", tok, path)
                h, mi = name
                cache[name] = self.same_file_copy(tmpl, lambda t: t.update(
                    m_Name=f"TimeFloat - ssmod {h:02d}:{mi:02d}", hours=(h % 12) or 12, minutes=mi, PM=int(h >= 12),
                    value=0.0))
            return 0, cache[name]
        raise SSModError(f"internal: resolve {kind}")

    def scene_object(self, m, th, t, objpath, tok):
        """A dialogue wants to call on / pass a component of an object in its npc's scene. Dialogues are assets and
        can't point into a scene, so (like the game's own "Farm/Farm") they go through a global blackboard that
        SSMod adds to that scene (SceneCtx.add_call_blackboard) holding one variable per object."""
        level = self.cat.scene_file(th.scene, th.tok, m.mf.path)
        reg = m.call_objects.setdefault(level, {})
        key = (t, objpath)
        if key not in reg:
            var = f"o{len(reg) + 1}"
            reg[key] = (var, calls.stable_id(m.slug, level, t, objpath), tok)
        var, vid, _ = reg[key]
        return {"_name": f"{call_blackboard_name(m, level)}/{var}", "_targetVariableID": vid}

    def find_asset(self, cls, name, tok, path):
        """An asset (ScriptableObject) by its name, for `call` arguments: asset "Weather Snowy"."""
        if getattr(self, "_asset_index", None) is None:
            self._asset_index = {}
            sources = [(0, self.env, self.res)]
            se, sf = clean_load("sharedassets0.assets", self.base)
            sources.append((RES_SA0, se, sf))
            for fid, env, f in sources:
                for pid, o in f.objects.items():
                    if o.type.name == "MonoBehaviour":
                        n = mb_name(o)
                        if n:
                            self._asset_index.setdefault(norm(n), []).append((fid, pid, env, f, o, n))
        hits = self._asset_index.get(norm(name), [])
        typed = [h for h in hits if script_name(h[2], h[3], h[4]) == cls]
        if len(typed) == 1 or (typed and len({h[5] for h in typed}) == 1):
            return typed[0][0], typed[0][1]
        if not typed:
            kinds = sorted({script_name(h[2], h[3], h[4]) for h in hits})
            same = [k for k, v in self._asset_index.items() if v and script_name(v[0][2], v[0][3], v[0][4]) == cls]
            extra = f" (there is one called that, but it's a {', '.join(kinds)})" if kinds else suggest(norm(name), same)
            raise SSModError(f'no {cls} called "{name}"{extra}. ./ssmod assets {cls} lists them', tok, path)
        raise SSModError(f'more than one {cls} is called "{name}"', tok, path)

    # ---- new areas
    def level_data_of(self, level):
        """(scene env, file, LevelData pptr as seen from that scene) of a scene."""
        env, f = SceneCtx.load_scene(self, level)
        for p, o in f.objects.items():
            if o.type.name == "MonoBehaviour" and script_name(env, f, o) == "LevelController":
                return env, f, o.read_typetree()["levelData"]
        raise SSModError(f"{level} has no LevelController")

    def res_view(self, f, pp):
        """A PPtr from scene file f -> (fid, pid) as seen from resources.assets."""
        name = f.externals[pp["m_FileID"] - 1].path.split("/")[-1].lower()
        if name == "resources.assets":
            return 0, pp["m_PathID"]
        for k, e in enumerate(self.res.externals, 1):
            if e.path.split("/")[-1].lower() == name:
                return k, pp["m_PathID"]
        raise SSModError(f"resources.assets can't see {name}")

    def create_area(self, m, a, level, index, into=None):
        """Clone the source scene's LevelData into resources.assets for the new area; returns its path id.
        Links to new areas that don't exist yet are skipped; call again with into=<pid> once they all exist."""
        src_level = self.cat.scene_file(a.source, a.tok, m.mf.path)
        env, f, lpp = self.level_data_of(src_level)
        sfile = f.externals[lpp["m_FileID"] - 1].path.split("/")[-1]
        se, sf = load(sfile)
        c = CrossFileCloner(se, sf, self.env, self.res)
        src = sf.objects[lpp["m_PathID"]]
        tree = src.read_typetree()
        script = tree.pop("m_Script")

        def remap(node):
            if isinstance(node, dict):
                if set(node) == {"m_FileID", "m_PathID"}:
                    if not node["m_PathID"]:
                        return node
                    fid = c.add_external(sfile) if node["m_FileID"] == 0 else c.ext_id(node["m_FileID"])
                    return pptr(node["m_PathID"], fid)
                return {k: remap(v) for k, v in node.items()}
            if isinstance(node, list):
                return [remap(v) for v in node]
            return node
        tree = remap(tree)
        links, inter = [], []
        link_t = tree["links"][0] if tree["links"] else None
        for mine, other, theirs, tok in a.connects:
            olevel = self.cat.scene_file(other, tok, m.mf.path)
            if olevel in self.new_scenes:
                fid, pid = 0, self.new_scenes[olevel]["leveldata"]
            elif olevel in self.pending_areas:
                continue
            else:
                oe, of_, opp = self.level_data_of(olevel)
                fid, pid = self.res_view(of_, opp)
            if link_t is not None:
                links.append(dict(copy.deepcopy(link_t), level=pptr(pid, fid), exitType=EXIT_IDS[mine], enterType=EXIT_IDS[theirs]))
        ids = [EXIT_IDS[mine] for mine, _, _, _ in a.connects]
        for i1 in ids:
            for i2 in ids:
                if i1 != i2:
                    inter.append({"fromExit": i1, "toExit": i2, "linearDistance": 2500.0, "pathDistance": 3200.0, "reachable": 1})
        slug_id = "s" + hashlib.sha1(a.name.encode()).hexdigest()[:3]
        tree.update(m_Name=a.name, id=slug_id, levelName=a.display, levelNameKey="",
                    scene={"scenePath": f"Assets/Scenes/SSMod/{a.name}.unity", "sceneGUID": hashlib.md5(a.name.encode()).hexdigest()},
                    links=links, interlinkData=inter, includeInStats=0, includeInUnitTests=0)
        ordered = {k: (script if k == "m_Script" else tree[k]) for k in src.read_typetree()}
        data = bytearray(copy.copy(src).save_typetree(ordered))
        sfid, spid = struct.unpack_from("<iq", src.get_raw_data(), 16)
        struct.pack_into("<iq", data, 16, c.ext_id(sfid), spid)
        if into is not None:
            self.R[into].set_raw_data(bytes(data))
            return into
        new = copy.copy(src)
        new.assets_file, new.path_id, new.type_id = self.res, self.new_id(), c.type_id(src.type_id)
        new.set_raw_data(bytes(data))
        self.R[new.path_id] = new
        self.library_add(LEVEL_LIBRARY, new.path_id)
        self.pending_areas.discard(level)
        self.new_scenes[level] = {"decl": a, "mod": m, "leveldata": new.path_id, "source": src_level, "index": index}
        return new.path_id

    def create_elevator(self, m, e, index):
        floors = []
        et = self.R[TOWNHALL_ELEVATOR].read_typetree()
        ft = et["floors"][0]
        for scene, loc, label, tok in e.floors:
            level = self.cat.scene_file(scene, tok, m.mf.path)
            if level in self.new_scenes:
                fid, pid = 0, self.new_scenes[level]["leveldata"]
            else:
                _, of_, opp = self.level_data_of(level)
                fid, pid = self.res_view(of_, opp)
            floors.append(dict(copy.deepcopy(ft), id=str(len(floors) + 1), description=label, groundFloor=len(floors) == 0,
                               level=pptr(pid, fid)))
        et.update(m_Name=f"ElevatorData ssmod {e.name}", id="E" + hashlib.sha1(e.name.encode()).hexdigest()[:3],
                  exitID=241 + index, defaultFloorIndex=0, canMalfunction=False, forceTestMalfunction=False,
                  playElevatorMusic=True, panelPrefab=pptr(PANEL_6), forBuilding=pptr(0), floors=floors)
        return self.same_file_copy(TOWNHALL_ELEVATOR, lambda t: t.update(et))

    def save_resources(self):
        self._write("resources.assets", self.res.save())
        if getattr(self, "audio_blob", None):
            self._write(self.AUDIO_FILE, bytes(self.audio_blob))

    def _write(self, name, data):
        with open(os.path.join(self.out, name), "wb") as fh:
            fh.write(data)
        self.written.add(name)

    # ---- per scene
    def build_scene(self, level, entries):
        """entries: list of (ModState, decl)."""
        if level in self.new_scenes:
            info = self.new_scenes[level]
            env, f = clean_load(info["source"], self.base)       # a fresh copy of the source scene
        else:
            env, f = load(level, src=os.path.join(self.base, level))
        scene = SceneCtx(self, env, f, level)
        for m, _ in entries:            # names are per scene: the same hud/npc name can be used in another scene
            m.objects = {}
        if level in self.new_scenes:
            scene.setup_area(self.new_scenes[level])
        for m, decl in entries:
            if type(decl).__name__ == "ExitRewire":
                scene.rewire(decl)
        entries = [e for e in entries if type(e[1]).__name__ != "ExitRewire"]
        order = {"HideDecl": 0, "ElevatorPlace": 1, "PlaceDecl": 1, "HudDecl": 1, "ThingDecl": 2, "OverrideDecl": 2,
                 "RouteDecl": 3, "PickupDecl": 4, "ScriptDecl": 5}
        entries = sorted(entries, key=lambda e: order[type(e[1]).__name__])
        for m, decl in entries:
            kind = type(decl).__name__
            if kind == "ScriptDecl":
                scene.add_script(m, decl)
                continue
            if kind == "HideDecl":
                scene.hide(m, decl)
                continue
            if kind == "OverrideDecl":
                scene.override(m, decl)
                continue
            if kind == "HudDecl":
                scene.add_hud(m, decl)
                continue
            if kind == "ElevatorPlace":
                scene.add_elevator(m, decl)
                continue
            if kind == "PlaceDecl":
                scene.place(m, decl)
                continue
            if kind == "RouteDecl":
                owner = scene.actor_of(scene.find_object(decl.owner, decl.tok, m.mf.path), decl.tok, m.mf.path)
                m.routes[decl.name] = scene.add_route(m, decl.name, owner, decl.steps, run_on_start=False, loop=False)
                continue
            if hasattr(decl, "dialogue"):
                x, y = scene.locate(decl.loc, m.mf.path)
                if decl.kind == "npc":
                    scene.add_npc(m, decl, x, y)
                else:
                    scene.add_spot(m, decl, x, y)
            else:
                item = m.items.get(decl.item) or self.game_item(decl.item, decl.tok, m.mf.path)
                for loc in decl.locs:
                    x, y = scene.locate(loc, m.mf.path)
                    for k in range(decl.count):
                        a = 2 * math.pi * k / max(decl.count, 1)
                        r = 0 if decl.count == 1 else 30
                        scene.add_pickup(item, x + r * math.cos(a), y + r * math.sin(a), decl.item)
        for m in {id(m): m for m, _ in entries}.values():
            if m.call_objects.get(level):
                scene.add_call_blackboard(m)
        self._write(level, f.save())


class ModState:
    def __init__(self, mf, slug_):
        self.mf, self.slug = mf, slug_
        self.flags, self.items, self.dialogs, self.strvars, self.titles = {}, {}, {}, {}, {}
        self.objects = {}          # npc / spot name -> {"go": pid, "actor": pid} in the scene being built
        self.routes = {}           # route name -> PatrolRoute component pid
        self.call_objects = {}     # level -> {(type, object path): (variable, id, tok)} that dialogues `call` on
        self.sounds = {}           # sound name -> AudioAsset path id (resources.assets)


def world_scale(f, tr_pid):
    """Accumulated x/y scale of a Transform (so a copied child keeps its size once it has no parent)."""
    sx = sy = 1.0
    while tr_pid:
        t = f.objects[tr_pid].read()
        sx, sy = sx * t.m_LocalScale.x, sy * t.m_LocalScale.y
        tr_pid = t.m_Father.m_PathID
    return sx, sy


class SceneCtx:
    _templates = {}
    _paths = {}

    def __init__(self, b, env, f, level):
        self.b, self.env, self.f, self.level = b, env, f, level
        self.O = f.objects
        self.kinds = {}
        self._names = None
        self.fresh = set()         # objects created by this build (never read them back)
        self.mesh_sprites = {}     # (mesh name, part) -> the Sprite made for it in this scene

    def template(self, level):
        key = (self.b.base, level)
        if key not in SceneCtx._templates:
            own = os.path.join(self.b.base, level)
            try:
                SceneCtx._templates[key] = clean_load(level, self.b.base)    # the game without SSMod
            except Exception:
                SceneCtx._templates[key] = load(level, src=own)             # our own scenes (vault, LPP floors)
        return SceneCtx._templates[key]

    @staticmethod
    def load_scene(builder, level):
        own = os.path.join(builder.base, level)
        if os.path.exists(own):
            return load(level, src=own)
        return load(level)

    def exits(self):
        """Exit id -> AreaExitTrigger pids of the scene's own exits (not doors made in this build: a fresh copy
        reads back as its template, so it must never be read and saved again)."""
        out = {}
        for p, o in self.O.items():
            if p in self.fresh:
                continue
            if o.type.name == "MonoBehaviour" and script_name(self.env, self.f, o) == "AreaExitTrigger":
                out.setdefault(o.read_typetree()["id"], []).append(p)
        return out

    def setup_area(self, info):
        a, m = info["decl"], info["mod"]
        res = self.ext("resources.assets")
        for p, o in self.O.items():
            if o.type.name == "MonoBehaviour" and script_name(self.env, self.f, o) == "LevelController":
                t = o.read_typetree()
                t["levelData"] = pptr(info["leveldata"], res)
                o.save_typetree(t)
        if a.room:
            self.resize_room(a.room, a.tok, m.mf.path)
        for name in a.closes:
            for p in self.exits().get(EXIT_IDS[name], []):
                go = self.O[p].read_typetree()["m_GameObject"]["m_PathID"]
                t = self.O[go].read_typetree()
                t["m_IsActive"] = False
                self.O[go].save_typetree(t)
        # where each connected exit leads
        targets = {}
        for mine, other, theirs, tok in a.connects:
            olevel = self.b.cat.scene_file(other, tok, m.mf.path)
            if olevel in self.b.new_scenes:
                target = pptr(self.b.new_scenes[olevel]["leveldata"], res)
            else:
                oe, of_, opp = self.b.level_data_of(olevel)
                name = of_.externals[opp["m_FileID"] - 1].path.split("/")[-1].lower()
                target = pptr(opp["m_PathID"], self.ext(name))
            targets[EXIT_IDS[mine]] = (target, EXIT_IDS[theirs])
        # new doors get their destination while they're made (a fresh copy can't be read back reliably)
        door_ids = set()
        for d in a.doors:
            framed = d.frame if d.frame is not None else bool(a.room)      # rooms get real doors by default
            if framed and d.facing not in ("North", "South"):
                if d.frame:
                    raise SSModError("a framed or narrow door must face North or South (top or bottom wall)", d.tok, m.mf.path)
                framed = False
            self.add_door(m, d, targets.get(EXIT_IDS[d.exit]), bool(framed), art=framed is True)
            door_ids.add(EXIT_IDS[d.exit])
        ex = self.exits()
        for mine, other, theirs, tok in a.connects:
            eid = EXIT_IDS[mine]
            if eid in door_ids:
                continue
            if eid not in ex:
                raise SSModError(f"{a.source} has no {mine} exit (add one with  door {mine} at (x, y);)", tok, m.mf.path)
            target, their_id = targets[eid]
            for p in ex[eid]:
                t = self.O[p].read_typetree()
                t["targetLevel"], t["targetID"] = target, their_id
                t["targetEvent"] = pptr(0)
                self.O[p].save_typetree(t)

    # ---- doors and rooms
    def add_door(self, m, d, target=None, framed=False, art=True):
        """A walk-through exit (Campground_TreeInterior's door) at d.loc. target: (LevelData pptr, their exit id).

        framed: the tree house's own door (a wooden frame with an open door in it) is put there too, and the exit
        zone is the size of the doorway, so you leave by walking into the door - not by stepping somewhere near it.
        Unframed doors keep the tree house's big zone (224 x 458 around the point)."""
        x, y = self.locate(d.loc, m.mf.path)
        de, df = self.template(DOOR_LEVEL)
        c = CrossFileCloner(de, df, self.env, self.f)
        root_tr = transform_of(df, df.objects[DOOR_GO].read()).path_id
        vx, vy = {"North": (0, -1), "South": (0, 1), "East": (-1, 0), "West": (1, 0)}[d.facing]   # into the room
        kids = {}
        for ch in df.objects[root_tr].read().m_Children:
            kids[ch.m_PathID] = df.objects[df.objects[ch.m_PathID].read().m_GameObject.m_PathID].read().m_Name

        def edit(i, tree, mm):
            k = self.kind(de, df, i)
            if i == DOOR_GO:
                tree["m_Name"] = f"ssmod Door {d.exit}"
                tree["m_IsActive"] = True
            elif i == root_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y)}
            elif i in kids:
                if framed:
                    dist = DOOR_EXIT_IN if kids[i] == "Exit" else DOOR_ENTER_IN
                else:
                    dist = 72.0 if kids[i] == "Exit" else 254.0
                tree["m_LocalPosition"] = {"x": vx * dist, "y": vy * dist, "z": 0.0}
            elif k == "AreaExitTrigger":
                tree["id"] = EXIT_IDS[d.exit]
                tree["targetLevel"], tree["targetEvent"] = pptr(0), pptr(0)
                if target:
                    tree["targetLevel"], tree["targetID"] = target[0], target[1]
            elif k == "BoxCollider2D":
                if framed:
                    # the doorway: as wide as the opening, from just inside the room to well past the wall
                    tree["m_Size"] = {"x": 72.0 * DOOR_SCALES[d.facing], "y": DOOR_ZONE_DEPTH}
                    inside = DOOR_ZONE_IN_SOUTH if d.facing == "South" else DOOR_ZONE_IN_NORTH
                    tree["m_Offset"] = {"x": 0.0, "y": vy * (inside - DOOR_ZONE_DEPTH / 2)}
                else:
                    tree["m_Size"] = {"x": 224.02, "y": 458.5} if vy else {"x": 458.5, "y": 224.02}
                    tree["m_Offset"] = {"x": 0.0, "y": 0.0}
        mm = c.clone(DOOR_GO, edit)
        self.fresh.update(mm.values())
        if framed and art:
            # bottom wall: the frame straddles the wall like the tree house's; top wall: it stands on the wall line,
            # drawn in front of the wall face
            sc = DOOR_SCALES[d.facing]
            fy, front = (y + 60.0, 0.0) if d.facing == "South" else (y + 50.5 * sc, 14.0)
            for name, dx, dy, fr in ((DOOR_FRAME, 0.0, 0.0, front), (DOOR_PANEL, -25.0 * sc, -50.0 * sc, front + 0.5)):
                self.place(m, PlaceDecl(name, DOOR_SCENE, self.level, Loc(x + dx, fy + dy, None, d.tok), (sc, sc),
                                        d.show_if, d.tok, d.hide_if, False, None, None, 0.0, 0, None, fr))
        if d.show_if:
            self.add_activator(m, d.show_if, [mm[DOOR_GO]], d.tok)
        if d.hide_if:
            self.add_activator(m, d.hide_if, [mm[DOOR_GO]], d.tok, inverted=True)

    def resize_room(self, room, tok, path):
        """Stretch a TownHall_Floor_B1 style room to (x0, y0)-(x1, y1) (the same edits as the Heist vault room) and
        clear its furniture, npcs and elevator."""
        L, B, R, T = room
        O = self.O
        paths = self.go_paths(self.f)

        def one(p):
            hits = paths.get(p.lower())
            if not hits:
                raise SSModError(f'`room` only works in areas copied from "TownHall_Floor_B1" (missing {p})', tok, path)
            return sorted(hits)[0][1]
        root = one(ROOM_ROOT)

        def tr(go):
            return transform_of(self.f, O[go].read())

        def edit_tr(go, **kw):
            t = tr(go)
            tree = t.read_typetree()
            fx, fy = (world_position(self.f, tree["m_Father"]["m_PathID"])[:2] if tree["m_Father"]["m_PathID"] else (0.0, 0.0))
            if "x" in kw:
                tree["m_LocalPosition"]["x"] = kw["x"] - fx
            if "y" in kw:
                tree["m_LocalPosition"]["y"] = kw["y"] - fy
            if "dy" in kw:
                tree["m_LocalPosition"]["y"] += kw["dy"]
            if "sx" in kw:
                tree["m_LocalScale"]["x"] *= kw["sx"]
            if "sy" in kw:
                tree["m_LocalScale"]["y"] *= kw["sy"]
            t.save_typetree(tree)

        def comps(go, fn):
            for i in hierarchy_ids(self.f, go):
                o = O[i]
                if o.type.name in ("BoxCollider2D", "PolygonCollider2D", "SpriteRenderer"):
                    t = o.read_typetree()
                    if fn(o.type.name, t):
                        o.save_typetree(t)

        # the original room: walls x -4245..-3599, floor from y 807, side walls 692.6 high (top ~1500)
        sh = B - 807.0                      # move the whole room up/down
        top = T - sh                        # top in the room's own coordinates
        dy_top = top - 1500.0
        sx, sy = (R - L) / 640.05, 1 + dy_top / 550.53
        cx = (L + R) / 2 + 10
        edit_tr(one(ROOM_ROOT + "/Floor"), x=cx, y=B, sx=sx, sy=sy)
        edit_tr(one(ROOM_ROOT + "/Wall (1)"), x=cx, dy=dy_top + sh, sx=(R - L + 8) / 666.0)
        edit_tr(one(ROOM_ROOT + "/Interior Lights"), x=cx, y=B, sx=sx, sy=sy)
        side = (T - B) / 692.6
        edit_tr(one(ROOM_ROOT + "/InteriorWall_1x36"), x=L - 1, y=B, sy=side)
        edit_tr(one(ROOM_ROOT + "/InteriorWall_1x36 (1)"), x=R, y=B, sy=side)
        edit_tr(one(ROOM_ROOT + "/InteriorWall_4x1 (1)"), x=L, y=B, sx=(R - L + 5) / 650.0)
        edit_tr(one(ROOM_ROOT + "/InteriorWall_4x1"), x=L, dy=dy_top + sh, sx=(R - L + 5) / 669.2)
        zone = one(ROOM_ROOT + "/InteriorArea")
        zx, zy, _ = world_position(self.f, tr(zone).path_id)

        def grow_zone(kind, t):
            if kind == "BoxCollider2D":
                t["m_Size"] = {"x": R - L + 60, "y": T - B + 60}
                t["m_Offset"] = {"x": (L + R) / 2 - zx, "y": (B + T) / 2 - zy}
                return True
            if kind == "PolygonCollider2D":
                t["m_Points"]["m_Paths"] = [[{"x": L - 30 - zx, "y": B - 30 - zy}, {"x": R + 30 - zx, "y": B - 30 - zy},
                                             {"x": R + 30 - zx, "y": T + 30 - zy}, {"x": L - 30 - zx, "y": T + 30 - zy}]]
                return True
            return False
        comps(zone, grow_zone)
        ab = one("AreaBounds")
        edit_tr(ab, x=(L + R) / 2, y=(B + T) / 2)
        bw, bh = max(2915.0, R - L + 2300), max(2110.0, T - B + 1400)

        def grow_bounds(kind, t):
            if kind == "BoxCollider2D":
                t["m_Size"] = {"x": bw, "y": bh}
                t["m_Offset"] = {"x": 0.0, "y": 0.0}
                return True
            if kind == "SpriteRenderer":
                t["m_Size"] = {"x": bw + 200, "y": bh + 200}
                return True
            return False
        comps(ab, grow_bounds)
        pf = one("Custom Pathfind Area")
        px, py, _ = world_position(self.f, tr(pf).path_id)

        def grow_path(kind, t):
            if kind == "PolygonCollider2D":
                t["m_Points"]["m_Paths"] = [[{"x": L - px, "y": B + 7 - py}, {"x": R + 10 - px, "y": B + 7 - py},
                                             {"x": R + 10 - px, "y": T - py}, {"x": L - px, "y": T - py}]]
                return True
            return False
        comps(pf, grow_path)
        start = paths.get("levelcontroller/player starting pos")
        if start:
            edit_tr(sorted(start)[0][1], x=(L + R) / 2, y=B + 250)
        # clear furniture, npcs and the elevator: everything that isn't the room itself
        for p_, hits in paths.items():
            parts = p_.split("/")
            drop = (len(parts) == 1 and parts[0] not in {k.lower() for k in ROOT_KEEP}) or \
                   (len(parts) == 2 and parts[0] == ROOM_ROOT.lower() and parts[1] not in {k.lower() for k in ROOM_KEEP})
            if drop:
                for _, go in hits:
                    t = O[go].read_typetree()
                    t["m_IsActive"] = False
                    O[go].save_typetree(t)

    def rewire(self, d):
        """A neighbour's exit now leads into the new area."""
        ex = self.exits()
        if d.exit_id not in ex:
            raise SSModError(f"that scene has no exit with id {d.exit_id}", d.tok, d.path)
        res = self.ext("resources.assets")
        for p in ex[d.exit_id]:
            t = self.O[p].read_typetree()
            t["targetLevel"], t["targetID"] = pptr(d.leveldata, res), d.target_id
            t["targetEvent"] = pptr(0)
            self.O[p].save_typetree(t)

    def ext(self, name):
        for k, e in enumerate(self.f.externals, 1):
            if e.path.lower().endswith(name):
                return k
        c = CrossFileCloner(*self.template(PICKUP_LEVEL), self.env, self.f)
        return c.add_external(name)

    def kind(self, e, ff, i):
        key = (ff, i)
        if key not in self.kinds:
            o = ff.objects[i]
            self.kinds[key] = script_name(e, ff, o) if o.type.name == "MonoBehaviour" else o.type.name
        return self.kinds[key]

    def find_object(self, name, tok, path):
        """GameObject path id of a named object in this scene (active objects first)."""
        self._index_names()
        hits = self._names.get(name.lower())
        if not hits:
            raise SSModError(f'no object called "{name}" in this scene.' + suggest(name.lower(), self._names), tok, path)
        return sorted(hits)[0][1]

    def _index_names(self):
        if self._names is None:
            self._names = {}
            for pid, o in self.O.items():
                if o.type.name == "GameObject":
                    g = o.read()
                    self._names.setdefault(g.m_Name.lower(), []).append((not g.m_IsActive, pid))

    def locate(self, loc, path):
        if loc.landmark is None:
            return loc.x, loc.y
        pid = self.find_object(loc.landmark, loc.tok, path)
        x, y, _ = world_position(self.f, transform_of(self.f, self.O[pid].read()).path_id)
        return x + loc.x, y + loc.y

    def res_pptr(self, fid_pid):
        """A (file id, path id) as seen from resources.assets -> PPtr in this scene."""
        fid, pid = fid_pid
        if fid == 0:
            return pptr(pid, self.ext("resources.assets"))
        if fid == RES_SA0:
            return pptr(pid, self.ext("sharedassets0.assets"))
        raise SSModError("internal: unsupported sprite file")

    # npc
    def add_npc(self, m, d, x, y):
        props = {k: v[0] for k, v in d.props.items() if isinstance(v, tuple)}
        look = d.props.get("look", {}) if isinstance(d.props.get("look"), dict) else {}
        colors = {k: v[0][1] for k, v in look.items() if isinstance(v, tuple) and isinstance(v[0], tuple) and v[0][0] == "color"}
        for k, v in look.items():                                    # catch typos instead of silently ignoring them
            if k not in LOOK_COLORS and k not in LOOK_TYPES and k not in ("chubby", "gloves"):
                raise SSModError(f"unknown look option '{k}'." + suggest(k, list(LOOK_COLORS) + list(LOOK_TYPES) + ["chubby"]),
                                 v[1] if isinstance(v, tuple) else d.tok, m.mf.path)
        look_types = {}
        for k, names in LOOK_TYPES.items():
            if k in look:
                val, vtok = look[k]
                val = val[1] if isinstance(val, tuple) else val
                key = norm(str(val))
                if key not in names:
                    raise SSModError(f"{k} must be one of: {', '.join(LOOK_TYPE_NAMES[k])}", vtok, m.mf.path)
                look_types[k] = names[key]
        chubby = look["chubby"][0] if "chubby" in look else None
        npc_scale = float(props["scale"]) if "scale" in props else None
        actor_data = None
        carl = bool(props.get("carl", False))
        if carl:
            actor_data = pptr(RANDOM_CAMPER_ACTOR, self.ext("sharedassets0.assets"))
        if "actor" in props:
            a = self.b.cat.static()["actors"].get(norm(props["actor"]))
            if not a:
                raise SSModError(f'unknown actor "{props["actor"]}".' + suggest(norm(props["actor"]), self.b.cat.static()["actors"]),
                                 d.props["actor"][1], m.mf.path)
            actor_data = pptr(a[0], self.ext("sharedassets0.assets"))
        ce, cf = self.template(CAMPER_LEVEL)
        c = CrossFileCloner(ce, cf, self.env, self.f)
        root_tr = transform_of(cf, cf.objects[CAMPER].read()).path_id

        def edit(i, tree, mm):
            k = self.kind(ce, cf, i)
            if i == CAMPER:
                tree["m_Name"] = d.name
            elif i == root_tr:
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y)}
                if npc_scale:
                    tree["m_LocalScale"] = {"x": npc_scale, "y": npc_scale, "z": 1.0}
            elif k == "UniqueID":
                tree["ID"] = uuid.uuid4().hex
            elif k == "GameActor" and actor_data:
                tree["actorData"] = actor_data
            elif k == "Camper":
                if props.get("ranger", False):
                    tree.update(isRanger=True, disableAllSenses=False, canBeTerrified=False, autoChaseOnRangerDanger=True)
                else:
                    tree.update(isRanger=False, disableAllSenses=True, canBeTerrified=False, autoChaseOnRangerDanger=False)
            elif k == "CamperBaseLook":
                if carl:
                    carl_look(tree, pptr(BEARD_LONG, self.ext("sharedassets0.assets")))
                for key, field_name in LOOK_COLORS.items():
                    if key in colors:
                        tree[field_name] = rgba(colors[key])
                if "gloves" in colors:
                    tree["hasGloves"] = True
                if "beard" in colors and not carl:                    # a beard colour also gives them a beard
                    tree["beard"] = pptr(BEARD_LONG, self.ext("sharedassets0.assets"))
                for key, value in look_types.items():
                    tree[key] = value
                if chubby is not None:
                    tree["chubbiness"] = max(0.0, min(1.0, float(chubby)))
        mm = c.clone(CAMPER, edit)
        actor = next(mm[i] for i in mm if self.kind(ce, cf, i) == "GameActor")
        m.objects[d.name] = {"go": mm[CAMPER], "actor": actor}
        te, tf = self.template(TALK_LEVEL)
        tc = CrossFileCloner(te, tf, self.env, self.f)
        t_tr = transform_of(tf, tf.objects[TALK_GO].read()).path_id
        res = self.ext("resources.assets")

        def talk(i, tree, mm2):
            k = self.kind(te, tf, i)
            if i == TALK_GO:
                tree["m_Name"] = d.name + " Dialog"
            elif i == t_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y)}
            elif k == "DialogueTreeController":
                tree["_graph"] = pptr(m.dialogs[d.name], res)
            elif k == "ActorDialog":
                tree.update(actor=pptr(actor), mustBeInDisguiseIfHuman=bool(props.get("needsDisguise", False)))
        gone = [mm[CAMPER]]                       # everything showIf / hideIf has to switch together
        if d.dialogue:
            gone.append(tc.clone(TALK_GO, talk)[TALK_GO])
        if props.get("bubble", False):
            bub = self.add_bubble(x, y + 60)
            if bub:
                gone.append(bub)
        if "patrol" in d.props:
            steps = d.props["patrol"][0]
            m.routes[d.name + " patrol"] = self.add_route(m, d.name + " patrol", actor, steps, run_on_start=True, loop=True,
                                                          back_and_forth=True)
        if isinstance(props.get("showIf"), tuple):
            self.add_activator(m, props["showIf"][1], gone, d.props["showIf"][1])
        if isinstance(props.get("hideIf"), tuple):     # hideIf = Flag;  the character leaves when the flag is set
            self.add_activator(m, props["hideIf"][1], gone, d.props["hideIf"][1], inverted=True)

    # spot
    def add_spot(self, m, d, x, y):
        props = {k: v[0] for k, v in d.props.items() if isinstance(v, tuple)}
        te, tf = self.template(PROP_LEVEL)
        tc = CrossFileCloner(te, tf, self.env, self.f)
        trs = {transform_of(tf, tf.objects[g].read()).path_id for g in (PROP_ACTION_GO, PROP_DIALOG_GO)}
        res = self.ext("resources.assets")

        def edit(i, tree, mm):
            k = self.kind(te, tf, i)
            if i == PROP_ACTION_GO:
                tree["m_Name"] = d.name
            elif i == PROP_DIALOG_GO:
                tree["m_Name"] = d.name + " Dialog"
            elif i in trs:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y)}
            elif k == "BoxCollider2D":
                tree["m_Size"], tree["m_Offset"] = dict(ACTION_AREA[0]), dict(ACTION_AREA[1])
            elif k == "DialogueTreeController":
                tree["_graph"] = pptr(m.dialogs[d.name], res)
        dm = tc.clone(PROP_DIALOG_GO, edit)
        am = tc.clone(PROP_ACTION_GO, edit, extra=dm)
        m.objects[d.name] = {"go": am[PROP_ACTION_GO], "actor": None}
        if props.get("bubble", True):
            self.add_bubble(x, y + 40)

    def add_bubble(self, x, y):
        be, bf = self.template(BUBBLE_LEVEL)
        bc = CrossFileCloner(be, bf, self.env, self.f)
        b_tr = transform_of(bf, bf.objects[BUBBLE_GO].read()).path_id

        def edit(i, tree, mm):
            if i == BUBBLE_GO:
                tree["m_Name"] = "ssmod Bubble"
            elif i == b_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y) - 384.0}
            elif self.kind(be, bf, i) == "IndicatorBubble":
                tree.update(actorAnchor=pptr(0), followAnchor=pptr(0), showCondition=pptr(0), hideCondition=pptr(0),
                            localShowCondition=pptr(0), localHideCondition=pptr(0))
        return bc.clone(BUBBLE_GO, edit)[BUBBLE_GO]

    def actor_of(self, go, tok, path):
        for i in hierarchy_ids(self.f, go):
            o = self.O[i]
            if o.type.name == "MonoBehaviour" and script_name(self.env, self.f, o) == "GameActor":
                return i
        raise SSModError("that object isn't a character (no GameActor)", tok, path)

    def route_of(self, go):
        for i in hierarchy_ids(self.f, go):
            o = self.O[i]
            if o.type.name == "MonoBehaviour" and script_name(self.env, self.f, o) == "PatrolRoute":
                return i
        return None

    def component_of(self, m, t, objpath, tok, path):
        """The component of type t (or a subclass) on a named object of this scene (or an npc/spot of this mod).
        t UnityEngine.GameObject gives the object itself."""
        if objpath in m.objects:
            # this mod's own npc/spot, made in this build: its new objects can't be read back yet, so use what
            # was kept when it was made
            own = m.objects[objpath]
            if t == "UnityEngine.GameObject":
                return own["go"]
            if own.get("actor") and (t == "GameActor" or calls.assignable("GameActor", t)):
                return own["actor"]
            if own.get("text") and (t in ("TMPro.TMP_Text", "TMPro.TextMeshPro") or calls.assignable("TMPro.TextMeshPro", t)):
                return own["text"]
            for k_, cp in (own.get("comps") or {}).items():
                if k_ == t or t in calls.bases(k_):
                    return cp
            have = ", ".join(sorted(own.get("comps") or {})) or "GameActor, GameObject"
            raise SSModError(f'"{objpath}" (yours) has no {calls.friendly(t)}; it has: {have}', tok, path)
        # look in the clean copy of this scene (same ids; this build's new objects can't be read back yet)
        if self.level in self.b.new_scenes:
            se, sf = self.env, self.f
        else:
            se, sf = self.template(self.level)
        go = self.find_in(sf, objpath, "this scene", tok, path)
        if t == "UnityEngine.GameObject":
            return go
        want = objpath.lower().strip("/")
        hits = sorted(h for p, hs in self.go_paths(sf).items() if p == want or p.endswith("/" + want) for h in hs)
        found = []
        for _, g in hits:                        # several objects can match a name: use the one that has it
            for c in sf.objects[g].read().m_Component:
                cp = (c.component if hasattr(c, "component") else c).m_PathID
                o = sf.objects.get(cp)
                if o is None:
                    continue
                k = calls.full_class(script_name(se, sf, o)) if o.type.name == "MonoBehaviour" else "UnityEngine." + o.type.name
                found.append(k)
                if k == t or t in calls.bases(k):
                    return cp
        raise SSModError(f'"{objpath}" has no {calls.friendly(t)} (it has: {", ".join(sorted(set(found))) or "nothing"})',
                         tok, path)

    def add_call_blackboard(self, m):
        """A GlobalBlackboard named SSMod_<mod>_<level>, one variable per object this mod's dialogues call on
        (the game's own dialogues reach scene objects the same way, e.g. "Farm/Farm")."""
        path = m.mf.path
        variables, refs = {}, [pptr(0)]
        for (t, objpath), (var, vid, tok) in sorted(m.call_objects[self.level].items(), key=lambda kv: kv[1][0]):
            refs.append(pptr(self.component_of(m, t, objpath, tok, path)))
            variables[var] = {"_value": len(refs) - 1, "_name": var, "_id": vid, "$type": calls.variable_type(t, tok, path)}
        name = call_blackboard_name(m, self.level)
        blackboard = json.dumps({"_name": name, "_variables": variables})
        level = self.b.cat.scene_file("TownHall_Floor_B1", None, path)
        te, tf = self.template(level)
        go = self.find_in(tf, "LevelController/Global Blackboard", "TownHall_Floor_B1", None, path)
        go_tr = transform_of(tf, tf.objects[go].read()).path_id
        bb = [cp for cp in ((c.component if hasattr(c, "component") else c).m_PathID for c in tf.objects[go].read().m_Component)
              if tf.objects[cp].type.name == "MonoBehaviour" and script_name(te, tf, tf.objects[cp]) == "GlobalBlackboard"][0]
        c = CrossFileCloner(te, tf, self.env, self.f)

        def edit(i, tree, mm):
            if i == go:
                tree["m_Name"] = f"ssmod Blackboard {m.slug}"
            elif i == go_tr:
                tree["m_Father"] = pptr(0)
            elif i == bb:
                tree.update(_serializedBlackboard=blackboard, _objectReferences=refs, dontDestroy=0)
        c.clone(go, edit)

    def add_route(self, m, name, owner_actor, steps, run_on_start, loop, back_and_forth=False):
        """A PatrolRoute + ActionPlayer walking through positions (with waits / chat bubbles)."""
        actions, points = [], []
        for st in steps:
            if st.kind == "goto":
                x, y = self.locate(st.value, m.mf.path)
                points.append((x, y))
                actions.append({"position": {"_value": {"x": x, "y": y}}, "targetTransform": {}, "proximity": {"_value": 15.0},
                                "usePathfinder": True, "$type": "ActorGotoPosition"})
            elif st.kind == "wait":
                actions.append({"waitTime": {"_value": st.value}, "$type": "NodeCanvas.Tasks.Actions.Wait"})
            else:
                actions.append({"speech": st.value, "locKey": "", "$type": "ActorSpeak"})
        if back_and_forth and len(points) > 2:
            gotos = [a for a in actions if a["$type"] == "ActorGotoPosition"]
            actions += [dict(a) for a in reversed(gotos[1:-1])]
        re_, rf = self.template(ROUTE_LEVEL)
        c = CrossFileCloner(re_, rf, self.env, self.f)
        root_tr = transform_of(rf, rf.objects[ROUTE_GO].read()).path_id
        x0, y0 = points[0]

        def edit(i, tree, mm):
            k = self.kind(re_, rf, i)
            if i == ROUTE_GO:
                tree["m_Name"] = f"ssmod Route {name}"
            elif i == root_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x0, "y": y0, "z": 0.0}
            elif k == "PatrolRoute":
                tree.update(owner=pptr(owner_actor), runOnStart=run_on_start, loop=loop)
            elif k == "ActionPlayer":
                tree.update(_serializedList=json.dumps({"actions": actions}), _objectReferences=[pptr(0)],
                            defaultAgent=pptr(owner_actor), loop=loop)
        mm = c.clone(ROUTE_GO, edit)
        return next(mm[i] for i in mm if self.kind(re_, rf, i) == "PatrolRoute")

    def add_activator(self, m, flag, targets, tok, inverted=False):
        """ConditionActivator: the targets are only active while the flag is set (inverted: while it is NOT set)."""
        if flag not in m.flags:
            raise SSModError(f"unknown flag '{flag}' for {'hideIf' if inverted else 'showIf'}. Declare it at the top:  flag {flag};",
                             tok, m.mf.path)
        ae, af = self.template(ACTIVATOR_LEVEL)
        c = CrossFileCloner(ae, af, self.env, self.f)
        go = af.objects[ACTIVATOR_MB].read_typetree()["m_GameObject"]["m_PathID"]
        go_tr = transform_of(af, af.objects[go].read()).path_id
        res = self.ext("resources.assets")

        def edit(i, tree, mm):
            if i == go:
                tree["m_Name"] = f"ssmod Activator {flag}"
            elif i == go_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": 0.0, "y": 0.0, "z": 0.0}
            elif i == ACTIVATOR_MB:
                if inverted:       # the game's own Town activator uses invertObject alone like this
                    tgt = dict(targetObject=pptr(0), targetObjects=[], invertObject=pptr(targets[0]),
                               invertObjects=[pptr(t) for t in targets[1:]])
                else:
                    tgt = dict(targetObject=pptr(targets[0]), targetObjects=[pptr(t) for t in targets[1:]],
                               invertObject=pptr(0), invertObjects=[])
                tree.update(invertCondition=False, condition=pptr(m.flags[flag], res), localCondition=pptr(0),
                            otherConditions=[], runInAwake=True, **tgt)
        c.clone(go, edit)

    def override(self, m, d):
        """Point every DialogueTreeController on the named object (and its children) at this mod's dialogue, so a
        character of the game says the mod's lines. Existing objects, edited in place."""
        path = m.mf.path
        se, sf = (self.env, self.f) if self.level in self.b.new_scenes else self.template(self.level)
        want = d.name.lower().strip("/")
        roots = sorted(h for p_, hs in self.go_paths(sf).items() if p_ == want or p_.endswith("/" + want) for h in hs)
        if not roots:
            self.find_in(sf, d.name, "this scene", d.tok, path)        # raises a helpful "no object called ..."
        res = self.ext("resources.assets")
        dlg = m.dialogs["override:" + d.name]
        done = 0
        for _, root in roots:
            for i in hierarchy_ids(sf, root):
                o = self.O.get(i)
                if o is None or o.type.name != "MonoBehaviour" or self.kind(se, sf, i) != "DialogueTreeController":
                    continue
                raw = o.get_raw_data()
                tree = o.read_typetree()
                tree["_graph"] = pptr(dlg, res)
                data = bytearray(copy.copy(o).save_typetree(tree))
                data[16:28] = raw[16:28]           # keep m_Script exactly as it was (the layout can misread it)
                o.set_raw_data(bytes(data))
                done += 1
            if done:
                break
        if not done:
            raise SSModError(f'"{d.name}" has nothing to talk to (no DialogueTreeController on it or its children)', d.tok, path)

    def hide(self, m, d):
        self._index_names()
        hits = self._names.get(d.name.lower())
        if not hits:
            raise SSModError(f'no object called "{d.name}" in this scene.' + suggest(d.name.lower(), self._names), d.tok, m.mf.path)
        for _, pid in hits:
            t = self.O[pid].read_typetree()
            t["m_IsActive"] = False
            self.O[pid].save_typetree(t)

    @staticmethod
    def go_paths(f):
        """{lower-case hierarchy path: [(inactive, go pid)]} for every GameObject of a file (cached per file)."""
        key = f
        if key not in SceneCtx._paths:
            O = f.objects
            parent, name, active = {}, {}, {}
            for pid, o in O.items():
                if o.type.name in ("Transform", "RectTransform"):
                    try:
                        t = o.read()
                        go = t.m_GameObject.m_PathID
                        g = O[go].read()
                        name[pid], active[pid] = g.m_Name, bool(g.m_IsActive)
                    except (AttributeError, KeyError):
                        continue                    # a copy made in this build (it reads back as unknown)
                    parent[pid] = (t.m_Father.m_PathID, go)
            paths = {}
            for tp in parent:
                parts, cur, act = [], tp, True
                while cur and cur in name:
                    parts.append(name[cur])
                    act = act and active[cur]
                    cur = parent[cur][0]
                paths.setdefault("/".join(reversed(parts)).lower(), []).append((not act, parent[tp][1]))
            SceneCtx._paths[key] = paths
        return SceneCtx._paths[key]

    def find_in(self, f, name, where, tok, path):
        """GameObject pid in file f by name, or by (the end of) its hierarchy path: "Bank/Counter"."""
        paths = self.go_paths(f)
        want = name.lower().strip("/")
        hits = [h for p, hs in paths.items() if p == want or p.endswith("/" + want) for h in hs]
        if not hits:
            leaves = {p.rsplit("/", 1)[-1] for p in paths}
            raise SSModError(f'no object called "{name}" in {where}.' + suggest(want.rsplit("/", 1)[-1], leaves), tok, path)
        return sorted(hits)[0][1]

    def place(self, m, d):
        level = self.b.cat.scene_file(d.source, d.tok, m.mf.path)
        se, sf = self.template(level)
        src = self.find_in(sf, d.name, d.source, d.tok, m.mf.path)
        s_tr = transform_of(sf, sf.objects[src].read())
        sx0, sy0, sz0 = world_position(sf, s_tr.path_id)
        x, y = self.locate(d.loc, m.mf.path)
        c = CrossFileCloner(se, sf, self.env, self.f)

        ws = world_scale(sf, s_tr.path_id)
        sx, sy = ws[0] * d.scale[0], ws[1] * d.scale[1]
        if d.size:
            w0, h0 = self.sprite_size(se, sf, src, d)
            sx, sy = d.size[0] / w0, d.size[1] / h0
        sprite_pid = None
        y_sort = y
        if d.mesh or d.image:                        # custom geometry / pictures: their own size in world units
            sx, sy = d.scale
        if d.flip:
            sx = -sx
        rot = None
        if d.rotate:
            a = math.radians(d.rotate) / 2
            rot = {"x": 0.0, "y": 0.0, "z": math.sin(a), "w": math.cos(a)}
        if d.image:
            sprite_pid = self.image_sprite(se, sf, src, d)
            # a picture stands on its bottom edge (like a building): `at` is where it touches the ground, and it
            # sorts by that point, so the player walks in front of it below and behind it above
            y_sort = y
            y = y + abs(sy) * d.image[3] / 2
        if d.mesh:
            sprite_pid = self.mesh_sprite(se, sf, src, d)
            # the sprite is centred on its bounding box (like the white square), so move the object by that
            # centre; every colour of one mesh still sorts by the mesh's own origin
            cx, cy = d.mesh[4]
            ox, oy = sx * cx, sy * cy
            th = math.radians(d.rotate)
            x, y = x + ox * math.cos(th) - oy * math.sin(th), y + ox * math.sin(th) + oy * math.cos(th)
        tint = rgba(d.color) if d.color else (rgba("FFFFFF") if d.image else None)
        # floors (WorldBackgroundLayer) are stacked by their z offset, everything else by sorting order
        bg_gos = set()
        for i in hierarchy_ids(sf, src):
            if self.kind(se, sf, i) == "WorldBackgroundLayer":
                bg_gos.add(sf.objects[i].read_typetree()["m_GameObject"]["m_PathID"])

        bob_pid = anchor_pid = None
        nxt = max(self.f.objects) + 1 + len(c.clone_ids(src))   # extra components get the ids right after the copy
        if d.bob:
            bob_pid, nxt = nxt, nxt + 1
        if d.hud:
            anchor_pid, nxt = nxt, nxt + 1
        anim_pid = None
        if d.anim:
            anim_pid, nxt = nxt, nxt + 1

        def edit(i, tree, mm):
            k = self.kind(se, sf, i)
            if i == src:
                tree["m_IsActive"] = True
                for extra in (bob_pid, anchor_pid, anim_pid):
                    if extra:
                        tree["m_Component"].append({"component": pptr(extra)})
            elif i == s_tr.path_id:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y_sort) - d.front}
                tree["m_LocalScale"] = {"x": sx, "y": sy, "z": tree["m_LocalScale"]["z"]}
                if "m_AnchoredPosition" in tree:          # a RectTransform (signs): keep both in step
                    tree["m_AnchoredPosition"] = {"x": x, "y": y}
                if rot:
                    tree["m_LocalRotation"] = rot
            elif k == "UniqueID":
                tree["ID"] = uuid.uuid4().hex
            if k == "TextMeshPro" and (d.text is not None or tint):
                if d.text is not None:
                    tree["m_text"] = d.text
                if tint:
                    tree["m_fontColor"] = dict(tint, a=tree["m_fontColor"]["a"])
                    r8, g8, b8 = (int(round(tint[c] * 255)) for c in ("r", "g", "b"))
                    tree["m_fontColor32"] = {"rgba": r8 | g8 << 8 | b8 << 16 | 255 << 24}
            elif k in ("LocalizedText", "SignUtil") and d.text is not None:
                tree["m_Enabled"] = 0            # otherwise it puts the original words back at Start
            if k == "WorldBackgroundLayer" and d.layer:
                tree["layerConfigDelta"] = tree["layerConfigDelta"] + d.layer
            if d.hud and k in ("SpriteRenderer", "MeshRenderer"):
                tree["m_SortingOrder"] = 32000             # on top of everything
            if k in ("SpriteRenderer", "MeshRenderer"):
                if tint and k == "SpriteRenderer":
                    tree["m_Color"] = dict(tint, a=tree["m_Color"]["a"])
                if sprite_pid and k == "SpriteRenderer":
                    tree["m_Sprite"] = pptr(sprite_pid)
                if d.layer and tree["m_GameObject"]["m_PathID"] not in {mm.get(g) for g in bg_gos}:
                    tree["m_SortingOrder"] = max(-32768, min(32767, tree["m_SortingOrder"] + d.layer))
        mm = c.clone(src, edit)
        for reserved in (bob_pid, anchor_pid, anim_pid):   # hold the ids, so new sprites/clips don't take them
            if reserved:
                self.f.objects[reserved] = self.f.objects[mm[src]]
        if d.bob:
            self.add_bob(mm[src], bob_pid, d)
        if d.anim:
            self.add_animation(mm[src], anim_pid, d, (x, y, depth(y_sort) - d.front, sx, sy, d.rotate), se, sf, src)
        if d.as_name or d.hud:                   # remember its components, so `call` can reach them by name
            comps = {}
            for c_ in sf.objects[src].read().m_Component:
                cp = (c_.component if hasattr(c_, "component") else c_).m_PathID
                if cp in mm and cp in sf.objects:
                    o_ = sf.objects[cp]
                    k_ = calls.full_class(self.kind(se, sf, cp)) if o_.type.name == "MonoBehaviour" else "UnityEngine." + o_.type.name
                    comps[k_] = mm[cp]
            if d.as_name:
                if d.as_name in m.objects:
                    raise SSModError(f"{d.as_name} is already used in this scene", d.tok, m.mf.path)
                m.objects[d.as_name] = {"go": mm[src], "comps": comps}
        if d.hud:
            self.add_anchor(mm[src], anchor_pid, d)
            text = next((mm[i] for i in hierarchy_ids(sf, src) if self.kind(se, sf, i) == "TextMeshPro"), None)
            m.objects[d.hud[0]] = {"go": mm[src], "text": text}
        if d.show_if:
            self.add_activator(m, d.show_if, [mm[src]], d.tok)
        if d.hide_if:
            self.add_activator(m, d.hide_if, [mm[src]], d.tok, inverted=True)
        return mm[src]

    def mesh_sprite(self, se, sf, go, d):
        """A new Sprite in this scene holding one colour of a custom mesh: a copy of the box's white square with
        our own vertex and index buffers. Made once per scene and reused by every placement of that mesh."""
        name, part, verts, idx, (cx, cy), (bw, bh) = d.mesh
        key = (name, part)
        if key in self.mesh_sprites:
            return self.mesh_sprites[key]
        ref = None
        for c in sf.objects[go].read().m_Component:
            cp = c.component if hasattr(c, "component") else c
            o = sf.objects[cp.m_PathID]
            if o.type.name == "SpriteRenderer":
                ref = o.read_typetree()["m_Sprite"]
        if not ref or not ref["m_PathID"]:
            raise SSModError("internal: the box building block has no sprite", d.tok, None)
        if ref["m_FileID"] == 0:
            ae, af, aname = se, sf, None
        else:
            aname = os.path.basename(sf.externals[ref["m_FileID"] - 1].path)
            ae, af = self.template(aname)
        src = af.objects[ref["m_PathID"]]
        t = copy.deepcopy(src.read_typetree())
        rd = t["m_RD"]
        c = CrossFileCloner(ae, af, self.env, self.f)
        # The white square is packed in a sprite atlas: in the game its picture comes from the atlas, looked up by
        # its render-data key. Our copy must stand on its own, or it would point at an atlas it isn't in. So it
        # gets the atlas TEXTURE directly, with every vertex on the white square's texel, and no atlas link.
        uv = (0.0, 0.0)
        ap = t.get("m_SpriteAtlas") or {}
        if ap.get("m_PathID") and ap.get("m_FileID") == 0 and ap["m_PathID"] in af.objects:
            rkey = t["m_RenderDataKey"]
            for k, v in af.objects[ap["m_PathID"]].read_typetree()["m_RenderDataMap"]:
                if k == rkey and v["texture"]["m_PathID"]:
                    tex = v["texture"]
                    if tex["m_FileID"] == 0:
                        tt = af.objects[tex["m_PathID"]].read_typetree()
                        fid = self.ext(aname.lower()) if aname else 0
                    else:
                        tt, fid = None, c.ext_id(tex["m_FileID"])
                    r = v["textureRect"]
                    if tt:
                        uv = ((r["x"] + r["width"] / 2) / tt["m_Width"], (r["y"] + r["height"] / 2) / tt["m_Height"])
                    rd["texture"] = pptr(tex["m_PathID"], fid)
                    rd["settingsRaw"] = v["settingsRaw"]
                    # The game works out a sprite's texture coordinates from its vertex POSITIONS:
                    # texel = position * scale + offset (uvTransform = scale x, offset x, scale y, offset y).
                    # With the atlas's scale of 1 a big shape spreads across the whole item atlas (seen in game:
                    # a tent painted with soup cans). Scale 0 pins every vertex to the white square's centre.
                    rd["uvTransform"] = {"x": 0.0, "y": r["x"] + r["width"] / 2, "z": 0.0, "w": r["y"] + r["height"] / 2}
                    break
        t["m_SpriteAtlas"] = pptr(0)
        t["m_AtlasTags"] = []
        vdata, ibytes = sprite_buffers(verts, idx, cx, cy, uv)
        keep = lambda old, b: bytes(b) if isinstance(old, (bytes, bytearray)) else list(b)   # noqa: E731
        w, h = max(bw, 1.0), max(bh, 1.0)
        t["m_Name"] = f"ssmod mesh {name} {part}"
        t["m_Rect"] = {"x": 0.0, "y": 0.0, "width": w, "height": h}
        t["m_Offset"] = {"x": 0.0, "y": 0.0}
        t["m_Pivot"] = {"x": 0.5, "y": 0.5}
        t["m_PhysicsShape"] = []
        g = uuid.uuid4().int                              # its own render-data key (a GUID + a file id)
        rk = t["m_RenderDataKey"]
        first = rk[0] if isinstance(rk, (tuple, list)) else rk["first"]
        guid = {k: (g >> (32 * n)) & 0xFFFFFFFF for n, k in enumerate(first)} if isinstance(first, dict) else first
        t["m_RenderDataKey"] = type(rk)((guid, rk[1])) if isinstance(rk, (tuple, list)) else dict(rk, first=guid)
        rd["m_VertexData"]["m_VertexCount"] = len(verts)
        rd["m_VertexData"]["m_DataSize"] = keep(rd["m_VertexData"]["m_DataSize"], vdata)
        rd["m_IndexBuffer"] = keep(rd["m_IndexBuffer"], ibytes)
        sub = rd["m_SubMeshes"][0]
        sub.update(firstByte=0, indexCount=len(idx), baseVertex=0, firstVertex=0, vertexCount=len(verts))
        rd["m_SubMeshes"] = [sub]
        new = copy.copy(src)
        new.assets_file = self.f
        new.path_id = max(self.f.objects) + 1
        new.type_id = c.type_id(src.type_id)
        new.set_raw_data(copy.copy(src).save_typetree(t))
        self.f.objects[new.path_id] = new
        self.fresh.add(new.path_id)
        self.mesh_sprites[key] = new.path_id
        return new.path_id

    def add_hud(self, m, d):
        """Text stuck to the screen: the sign-text building block with the game's AnchorIntoCamera (which keeps the
        rain on screen), drawn on top of everything. Change it later with  call TMP_Text("Name").set_text("...")."""
        if d.name in m.objects:
            raise SSModError(f"{d.name} is already used in this scene", d.tok, m.mf.path)
        pd = PlaceDecl(BLOCKS["text"][1], BLOCKS["text"][0], d.scene, Loc(0.0, 0.0), (d.scale, d.scale), d.show_if, d.tok,
                       d.hide_if, False, None, d.color, 0.0, 0, d.text, 0.0, hud=(d.name, d.x, d.y))
        self.place(m, pd)

    def add_anchor(self, go, pid, d):
        """AnchorIntoCamera on a placed object (copied from the game's RainParticles prefab in resources.assets)."""
        tmpl = self.b.__dict__.get("_anchor_tmpl")
        if tmpl is None:
            tmpl = next((p_ for p_, o in self.b.R.items() if o.type.name == "MonoBehaviour"
                         and script_name(self.b.env, self.b.res, o) == "AnchorIntoCamera"), None)
            if tmpl is None:
                raise SSModError("this version of the game has no AnchorIntoCamera to copy for hud", d.tok, None)
            self.b._anchor_tmpl = tmpl
        src = self.b.R[tmpl]
        c = CrossFileCloner(self.b.env, self.b.res, self.env, self.f)
        _, x, y = d.hud
        full = copy.deepcopy(src.read_typetree())
        full.update(m_GameObject=pptr(go), m_Enabled=1, localPosition={"x": float(x), "y": float(y), "z": 1.0})
        data = bytearray(copy.copy(src).save_typetree(full))
        fid, spid = struct.unpack_from("<iq", src.get_raw_data(), 16)
        struct.pack_into("<iq", data, 16, c.ext_id(fid), spid)
        new = copy.copy(src)
        new.assets_file, new.path_id, new.type_id = self.f, pid, c.type_id(src.type_id)
        new.set_raw_data(bytes(data))
        self.f.objects[pid] = new
        self.fresh.add(pid)

    @staticmethod
    def _keys(points, size):
        """Linear keyframes for (time, tuple of `size` floats): Unity's Keyframe with straight slopes."""
        names = "xyzw"[:size]
        out = []
        for i, (t, v) in enumerate(points):
            def slope(a, b):
                (ta, va), (tb, vb) = a, b
                return [(vb[k] - va[k]) / max(tb - ta, 1e-6) for k in range(size)]
            ins = slope(points[i - 1], points[i]) if i > 0 else [0.0] * size
            outs = slope(points[i], points[i + 1]) if i + 1 < len(points) else [0.0] * size
            vec = lambda xs: {n: float(xx) for n, xx in zip(names, xs)}   # noqa: E731
            out.append({"time": float(t), "value": vec(v), "inSlope": vec(ins), "outSlope": vec(outs), "weightedMode": 0,
                        "inWeight": vec([1 / 3] * size), "outWeight": vec([1 / 3] * size)})
        return out

    def add_animation(self, go, pid, d, base, se, sf, src_go):
        """Keyframes on a placed object: a legacy AnimationClip (plain curves, like the game's own legacy clips) and a
        legacy Animation component that plays it automatically. move/scale/rotate are relative to how it's placed;
        show swaps the picture (frame-by-frame animation from PNGs)."""
        a = d.anim
        bx, by, bz, bsx, bsy, brot = base
        length = max(a.keys[-1][0], 1e-3)

        def track(name):
            return [(t, k[name]) for t, k in a.keys if name in k]
        pos = track("move")
        scl = track("scale")
        rot = track("rotate")
        show = track("show")
        curves = {"m_PositionCurves": [], "m_ScaleCurves": [], "m_RotationCurves": [], "m_EulerCurves": [], "m_PPtrCurves": []}
        wrap = {"m_PreInfinity": 2, "m_PostInfinity": 2, "m_RotationOrder": 4}
        if pos:
            pts = [(t, (bx + dx, by + dy, bz)) for t, (dx, dy) in pos]
            curves["m_PositionCurves"].append({"curve": dict(wrap, m_Curve=self._keys(pts, 3)), "path": ""})
        if scl:
            pts = [(t, (bsx * kx, bsy * ky, 1.0)) for t, (kx, ky) in scl]
            curves["m_ScaleCurves"].append({"curve": dict(wrap, m_Curve=self._keys(pts, 3)), "path": ""})
        if rot:
            # quaternions, sampled every 30 degrees or less so big turns (0 -> 360) go the long way round
            samples = [(rot[0][0], rot[0][1])]
            for (t0, a0), (t1, a1) in zip(rot, rot[1:]):
                n = max(1, int(math.ceil(abs(a1 - a0) / 30.0)))
                samples += [(t0 + (t1 - t0) * k / n, a0 + (a1 - a0) * k / n) for k in range(1, n + 1)]
            quats, prev = [], None
            for t, deg in samples:
                h = math.radians(deg + brot) / 2
                q = (0.0, 0.0, math.sin(h), math.cos(h))
                if prev and sum(p_ * q_ for p_, q_ in zip(prev, q)) < 0:
                    q = tuple(-c_ for c_ in q)                     # stay on one side, so it doesn't flip
                quats.append((t, q))
                prev = q
            curves["m_RotationCurves"].append({"curve": dict(wrap, m_Curve=self._keys(quats, 4)), "path": ""})
            eul = [(t, (0.0, 0.0, deg + brot)) for t, deg in rot]
            curves["m_EulerCurves"].append({"curve": dict(wrap, m_Curve=self._keys(eul, 3)), "path": ""})
        if show:
            class _Pic:                                            # what image_sprite needs from a placement
                pass
            frames = []
            for t, name in show:
                pic = _Pic()
                pic.image = a.frames[name]
                frames.append({"time": float(t), "value": pptr(self.image_sprite(se, sf, src_go, pic))})
            curves["m_PPtrCurves"].append({"curve": frames, "attribute": "m_Sprite", "path": "", "classID": 212,
                                           "script": pptr(0)})
        # the clip: a copy of one of the game's legacy clips with our curves
        ae, af = self.template("sharedassets0.assets")
        if not hasattr(SceneCtx, "_legacy_tmpl"):
            SceneCtx._legacy_tmpl = {}
        cache = SceneCtx._legacy_tmpl
        if "clip" not in cache:
            cache["clip"] = next(p_ for p_, o in af.objects.items() if o.type.name == "AnimationClip" and o.read_typetree()["m_Legacy"])
            cache["anim"] = next(p_ for p_, o in af.objects.items() if o.type.name == "Animation")
        c = CrossFileCloner(ae, af, self.env, self.f)
        csrc = af.objects[cache["clip"]]
        t_ = copy.deepcopy(csrc.read_typetree())
        t_.update(curves)
        t_.update(m_Name=f"ssmod anim {a.name}", m_Legacy=True, m_Compressed=False, m_UseHighQualityCurve=True,
                  m_SampleRate=60.0, m_WrapMode=2 if a.loop else 8, m_FloatCurves=[], m_CompressedRotationCurves=[],
                  m_Events=[], m_HasGenericRootTransform=False,
                  m_ClipBindingConstant={"genericBindings": [], "pptrCurveMapping": []})
        t_["m_MuscleClip"]["m_StartTime"] = 0.0
        t_["m_MuscleClip"]["m_StopTime"] = float(length)
        clip_pid = max(self.f.objects) + 1
        new = copy.copy(csrc)
        new.assets_file, new.path_id, new.type_id = self.f, clip_pid, c.type_id(csrc.type_id)
        new.set_raw_data(copy.copy(csrc).save_typetree(t_))
        self.f.objects[clip_pid] = new
        self.fresh.add(clip_pid)
        # the Animation component on the placed object
        asrc = af.objects[cache["anim"]]
        at = copy.deepcopy(asrc.read_typetree())
        at.update(m_GameObject=pptr(go), m_Enabled=1, m_Animation=pptr(clip_pid), m_Animations=[pptr(clip_pid)],
                  m_WrapMode=2 if a.loop else 8, m_PlayAutomatically=True, m_AnimatePhysics=False, m_CullingType=0)
        newa = copy.copy(asrc)
        newa.assets_file, newa.path_id, newa.type_id = self.f, pid, c.type_id(asrc.type_id)
        newa.set_raw_data(copy.copy(asrc).save_typetree(at))
        self.f.objects[pid] = newa
        self.fresh.add(pid)

    def add_bob(self, go, pid, d):
        """An AutoMoverSine on a placed object: it bobs by (dx, dy) and back every few seconds (the game's own
        floating "?" bubbles use it). Copied from the Campground hub's picnic-table bubble."""
        level = self.b.cat.scene_file("Campground_Hub", d.tok, None)
        te, tf = self.template(level)
        holder = self.find_in(tf, "PicnicTable/PlayerAction_Eat/IndicatorBubble/Mover / Scaler", "Campground_Hub", d.tok, None)
        src = next(tf.objects[(c_.component if hasattr(c_, "component") else c_).m_PathID]
                   for c_ in tf.objects[holder].read().m_Component
                   if script_name(te, tf, tf.objects[(c_.component if hasattr(c_, "component") else c_).m_PathID]) == "AutoMoverSine")
        c = CrossFileCloner(te, tf, self.env, self.f)
        dx, dy, secs = d.bob
        mag = math.hypot(dx, dy) or 1.0
        tree = copy.deepcopy(src.read_typetree())
        tree.pop("m_Script", None)
        tree.update(m_GameObject=pptr(go), m_Enabled=1, delta={"x": dx / mag, "y": dy / mag, "z": 0.0}, relative=0,
                    worldSpace=0, offset={"x": 0.0, "y": 0.0, "z": 0.0},
                    sineWave=dict(tree["sineWave"], period=float(secs), magnitude=float(mag), baseValue=0.0,
                                  periodOffset=0.0, randomizeOffset=1))
        full = {k: (src.read_typetree()["m_Script"] if k == "m_Script" else tree[k]) for k in src.read_typetree()}
        data = bytearray(copy.copy(src).save_typetree(full))
        fid, spid = struct.unpack_from("<iq", src.get_raw_data(), 16)
        struct.pack_into("<iq", data, 16, c.ext_id(fid), spid)
        new = copy.copy(src)
        new.assets_file, new.path_id, new.type_id = self.f, pid, c.type_id(src.type_id)
        new.set_raw_data(bytes(data))
        self.f.objects[pid] = new
        self.fresh.add(pid)

    MAX_IMAGE = 2048                                  # bigger pictures are scaled down (memory, file size)

    def image_texture(self, d):
        """A new Texture2D in this scene holding a PNG's pixels (RGBA32, no compression, one mip): a copy of a small
        game texture with our own size and pixel data. Made once per picture per scene."""
        from PIL import Image
        name, png = d.image[0], d.image[1]
        cache = self.__dict__.setdefault("image_textures", {})
        if png in cache:
            return cache[png]
        se, sf = self.template("sharedassets0.assets")
        src = next((o for o in sf.objects.values() if o.type.name == "Texture2D" and o.read().m_Name == "Cursor_Click"), None) \
            or next(o for o in sf.objects.values() if o.type.name == "Texture2D")
        with Image.open(png) as im:
            img = im.convert("RGBA")
        if max(img.size) > self.MAX_IMAGE:
            k = self.MAX_IMAGE / max(img.size)
            img = img.resize((max(1, int(img.width * k)), max(1, int(img.height * k))), Image.LANCZOS)
        data = img.transpose(Image.FLIP_TOP_BOTTOM).tobytes()     # Unity textures start at the bottom row
        t = copy.deepcopy(src.read_typetree())
        t.update(m_Name=f"ssmod image {name}", m_Width=img.width, m_Height=img.height, m_CompleteImageSize=len(data),
                 m_TextureFormat=4, m_MipCount=1, m_ImageCount=1, m_IsReadable=False,
                 m_StreamData={"offset": 0, "size": 0, "path": ""})
        t["image data"] = data
        ts = t["m_TextureSettings"]
        ts.update(m_FilterMode=1, m_WrapU=1, m_WrapV=1, m_WrapW=1)
        c = CrossFileCloner(se, sf, self.env, self.f)
        new = copy.copy(src)
        new.assets_file = self.f
        new.path_id = max(self.f.objects) + 1
        new.type_id = c.type_id(src.type_id)
        new.set_raw_data(copy.copy(src).save_typetree(t))
        self.f.objects[new.path_id] = new
        self.fresh.add(new.path_id)
        cache[png] = (new.path_id, img.width, img.height)
        return cache[png]

    def image_sprite(self, se, sf, go, d):
        """A new Sprite showing a PNG: a copy of the box's white square pointed at the picture's own texture, as one
        quad. The game works out texture coordinates from vertex positions (texel = position * scale + offset),
        so uvTransform is set to spread the whole picture over the quad, and the vertices carry the same uvs."""
        name, png, w_world, h_world = d.image
        key = ("image", png, w_world, h_world)
        if key in self.mesh_sprites:
            return self.mesh_sprites[key]
        tex, pw, ph = self.image_texture(d)
        ref = None
        for comp in sf.objects[go].read().m_Component:
            cp = comp.component if hasattr(comp, "component") else comp
            o = sf.objects[cp.m_PathID]
            if o.type.name == "SpriteRenderer":
                ref = o.read_typetree()["m_Sprite"]
        if ref["m_FileID"] == 0:
            ae, af = se, sf
        else:
            ae, af = self.template(os.path.basename(sf.externals[ref["m_FileID"] - 1].path))
        src = af.objects[ref["m_PathID"]]
        t = copy.deepcopy(src.read_typetree())
        rd = t["m_RD"]
        c = CrossFileCloner(ae, af, self.env, self.f)
        ppu = pw / max(w_world, 1e-3)                   # texture pixels per world unit
        hw, hh = w_world / 2, h_world / 2
        verts = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
        uvs = [((x * ppu + pw / 2) / pw, (y * (ph / max(h_world, 1e-3)) + ph / 2) / ph) for x, y in verts]
        idx = [0, 1, 2, 0, 2, 3]
        pos = b"".join(struct.pack("<3f", x, y, 0.0) for x, y in verts)
        pos += b"\0" * (-len(pos) % 16)
        vdata = pos + b"".join(struct.pack("<2f", u, v) for u, v in uvs)
        ibytes = struct.pack(f"<{len(idx)}H", *idx)
        keep = lambda old, b: bytes(b) if isinstance(old, (bytes, bytearray)) else list(b)   # noqa: E731
        t["m_Name"] = f"ssmod image {name}"
        t["m_Rect"] = {"x": 0.0, "y": 0.0, "width": float(pw), "height": float(ph)}
        t["m_Offset"] = {"x": 0.0, "y": 0.0}
        t["m_Pivot"] = {"x": 0.5, "y": 0.5}
        t["m_PixelsToUnits"] = ppu
        t["m_PhysicsShape"] = []
        t["m_SpriteAtlas"] = pptr(0)
        t["m_AtlasTags"] = []
        g = uuid.uuid4().int
        rk = t["m_RenderDataKey"]
        first = rk[0] if isinstance(rk, (tuple, list)) else rk["first"]
        guid = {k: (g >> (32 * n)) & 0xFFFFFFFF for n, k in enumerate(first)} if isinstance(first, dict) else first
        t["m_RenderDataKey"] = type(rk)((guid, rk[1])) if isinstance(rk, (tuple, list)) else dict(rk, first=guid)
        rd["texture"] = pptr(tex)
        rd["settingsRaw"] = 0
        rd["textureRect"] = {"x": 0.0, "y": 0.0, "width": float(pw), "height": float(ph)}
        rd["textureRectOffset"] = {"x": 0.0, "y": 0.0}
        rd["uvTransform"] = {"x": ppu, "y": pw / 2, "z": ph / max(h_world, 1e-3), "w": ph / 2}
        rd["m_VertexData"]["m_VertexCount"] = len(verts)
        rd["m_VertexData"]["m_DataSize"] = keep(rd["m_VertexData"]["m_DataSize"], vdata)
        rd["m_IndexBuffer"] = keep(rd["m_IndexBuffer"], ibytes)
        sub = rd["m_SubMeshes"][0]
        sub.update(firstByte=0, indexCount=len(idx), baseVertex=0, firstVertex=0, vertexCount=len(verts))
        rd["m_SubMeshes"] = [sub]
        new = copy.copy(src)
        new.assets_file = self.f
        new.path_id = max(self.f.objects) + 1
        new.type_id = c.type_id(src.type_id)
        new.set_raw_data(copy.copy(src).save_typetree(t))
        self.f.objects[new.path_id] = new
        self.fresh.add(new.path_id)
        self.mesh_sprites[key] = new.path_id
        return new.path_id

    def sprite_size(self, se, sf, go, d):
        """World-unit size of the sprite on an object (for `size`)."""
        for c in sf.objects[go].read().m_Component:
            p = c.component if hasattr(c, "component") else c
            o = sf.objects[p.m_PathID]
            if o.type.name == "SpriteRenderer":
                t = o.read_typetree()
                sp = o.read().m_Sprite
                if t["m_DrawMode"]:
                    return t["m_Size"]["x"], t["m_Size"]["y"]
                st = sp.deref().read_typetree()
                ppu = st["m_PixelsToUnits"] or 1.0
                return st["m_Rect"]["width"] / ppu, st["m_Rect"]["height"] / ppu
        raise SSModError("`size` needs an object with a sprite on it (use scale instead)", d.tok, None)

    def add_elevator(self, m, d):
        """Office_Floor_2's elevator at d.loc, using the mod's ElevatorData (d: ElevatorPlace)."""
        x, y = self.locate(d.loc, m.mf.path)
        ee, ef = self.template(ELEVATOR_LEVEL)
        c = CrossFileCloner(ee, ef, self.env, self.f)
        el_tr = transform_of(ef, ef.objects[ELEVATOR_GO].read()).path_id
        ox, oy, oz = world_position(ef, el_tr)
        res = self.ext("resources.assets")

        def edit(i, tree, mm):
            if i == ELEVATOR_GO:
                tree["m_Name"] = f"ssmod Elevator {d.name}"
            elif i == el_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": oz + 0.1 * (y - oy)}
            elif self.kind(ee, ef, i) == "Elevator":
                tree["elevatorData"] = pptr(d.elevator, res)
        c.clone(ELEVATOR_GO, edit)

    # script
    def add_script(self, m, d):
        path = m.mf.path
        res = self.ext("resources.assets")
        if d.speaker and d.speaker not in m.objects:
            raise SSModError(f"speaker {d.speaker} must be an npc of this mod in the same scene", d.tok, path)

        def resolve(kind, name, tok):
            if kind == "object":
                if name in m.objects:
                    return 0, m.objects[name]["go"]
                return 0, self.find_object(name, tok, path)
            if kind == "actor":
                if not d.speaker:
                    raise SSModError("speak needs a speaker: script Name in \"Scene\" by NpcName { ... }", tok, path)
                return 0, m.objects[d.speaker]["actor"]
            if kind == "weather":
                return res, WEATHER[name]
            if kind == "route":
                if name in m.routes:
                    return 0, m.routes[name]
                r = self.route_of(self.find_object(name, tok, path))
                if r is None:
                    raise SSModError(f'"{name}" has no patrol route', tok, path)
                return 0, r
            if kind == "component":
                return 0, self.component_of(m, name[0], name[1], tok, path)
            fid, pid = self.b.resolve(m, kind, name, tok)          # flags, items, disguises live in resources
            if fid == RES_SA0:
                return self.ext("sharedassets0.assets"), pid
            return (res if fid == 0 else fid), pid
        graph, blackboard, refs = ScriptCompiler(resolve, path, has_agent=bool(d.speaker)).compile(d.body)

        se, sf = self.template(SCRIPT_LEVEL)
        c = CrossFileCloner(se, sf, self.env, self.f)
        host_ids = hierarchy_ids(sf, SCRIPT_HOST_GO)
        skip = {i for i in host_ids if self.kind(se, sf, i) == "ActorAIBehaviour"}
        ids = [i for i in host_ids if i not in skip] + [SCRIPT_BT]
        nxt = max(self.O) + 1
        mp = {i: nxt + k for k, i in enumerate(ids)}
        host_tr = transform_of(sf, sf.objects[SCRIPT_HOST_GO].read()).path_id
        x, y = self.locate(d.loc, path) if d.loc else (0.0, 0.0)
        agent = pptr(m.objects[d.speaker]["actor"]) if d.speaker else pptr(0)   # a GameActor, like the originals
        for i in ids:
            src = sf.objects[i]
            k = self.kind(se, sf, i)
            tree = copy.deepcopy(src.read_typetree())
            script = tree.pop("m_Script", None)
            tree = c._remap(tree, mp)
            if i == SCRIPT_HOST_GO:
                tree["m_Name"] = f"ssmod Script {d.name}"
                tree["m_IsActive"] = True
                tree["m_Component"] = [x_ for x_ in tree["m_Component"] if x_["component"]["m_PathID"]]
            elif i == host_tr:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": x, "y": y, "z": depth(y)}
            elif k == "BehaviourTreeOwner":
                tree.update(boundGraphSerialization=graph, boundGraphObjectReferences=refs, enableAction=0,
                            fallbackAgent=agent, _graph=pptr(mp[SCRIPT_BT]), _blackboard=tree["_blackboard"])
            elif k == "Blackboard":
                tree.update(_serializedBlackboard=blackboard, _objectReferences=[])
            elif i == SCRIPT_BT:
                tree.update(m_Name=f"ssmod Script {d.name} BehaviourTree", _serializedGraph=graph, _objectReferences=refs,
                            _deserializationFailed=False, repeat=False, updateInterval=0.0)
            if script is not None:
                tree = {kk: (script if kk == "m_Script" else tree[kk]) for kk in src.read_typetree()}
            data = bytearray(copy.copy(src).save_typetree(tree))
            if script is not None:
                fid, spid = struct.unpack_from("<iq", src.get_raw_data(), 16)
                struct.pack_into("<iq", data, 16, c.ext_id(fid), spid)
            new = copy.copy(src)
            new.assets_file, new.path_id, new.type_id = self.f, mp[i], c.type_id(src.type_id)
            new.set_raw_data(bytes(data))
            self.O[mp[i]] = new
        return mp[SCRIPT_HOST_GO]

    # pickup
    def add_pickup(self, item, x, y, label):
        pe, pf = self.template(PICKUP_LEVEL)
        pc = CrossFileCloner(pe, pf, self.env, self.f)
        gi_go = pf.objects[PICKUP_GI].read_typetree()["m_GameObject"]["m_PathID"]
        gi_root = transform_of(pf, pf.objects[gi_go].read()).path_id
        res = self.ext("resources.assets")
        sprite = self.res_pptr(item["sprite"])

        def edit(i, tree, mm):
            k = self.kind(pe, pf, i)
            if i == gi_go:
                tree["m_Name"] = f"ssmod Pickup {label}"
                tree["m_IsActive"] = True
            elif i == gi_root:
                tree["m_Father"] = pptr(0)
                tree["m_LocalPosition"] = {"x": float(x), "y": float(y), "z": depth(y)}
            elif k == "GroundItem":
                tree["itemData"] = pptr(item["pid"], res)
                tree["expires"] = False
            elif k == "WorldItem":
                tree["data"] = pptr(item["pid"], res)
            elif k == "SpriteRenderer":
                tree["m_Sprite"] = sprite
        pc.clone(gi_go, edit)


class ExitRewire:
    def __init__(self, exit_id, leveldata, target_id, tok, path):
        self.exit_id, self.leveldata, self.target_id, self.tok, self.path = exit_id, leveldata, target_id, tok, path


class ElevatorPlace:
    def __init__(self, name, elevator, loc, tok):
        self.name, self.elevator, self.loc, self.tok = name, elevator, loc, tok

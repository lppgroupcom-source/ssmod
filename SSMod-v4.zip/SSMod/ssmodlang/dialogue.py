"""Compile a .ssmod dialogue block into a NodeCanvas DialogueTree (version 2.9 JSON) + _objectReferences.

Compilation is continuation-passing: each statement is compiled with the id of the node that follows it,
so if/else and choice branches simply re-join. Conditions compile to chains of ConditionNodes
(short-circuit && / || / ! by swapping targets), so any condition works with the game's own tasks.
The first node in the list is the dialogue's start node.
"""
import json
import uuid

from .syntax import (Say, Act, If, Choice, End, CFlag, CHas, CCoins, CCall, CNot, CAnd, COr, SSModError,
                     CChance, CHour, CWeather, RandomBlock, CEvent)
from . import calls

COMPARE = {">=": "GreaterOrEqualTo", ">": "GreaterThan", "<": "LessThan", "<=": "LessOrEqualTo", "==": "EqualTo"}
DEFAULT_PROMPT = "What'll it be?"
WEATHERS = ("Clear", "Rainy", "Snowy", "SnowyHeavy")


def extra_condition(c, compare, path, ref=None):
    """chance / hour / weather: the game's own condition tasks (shared by dialogues and scripts).
    ref(kind, key, tok) -> an _objectReferences index (hour needs one: a TimeFloat asset)."""
    if isinstance(c, CChance):
        return {"probability": {"_value": c.percent / 100}, "maxValue": {"_value": 1.0},
                "$type": "NodeCanvas.Tasks.Conditions.Probability"}
    if isinstance(c, CHour):
        if not 0 <= c.value <= 24:
            raise SSModError("hour goes from 0 to 24", c.tok, path)
        # like the game's own ("6 PM" for the ferry): a TimeFloat asset the game converts to its day clock
        h = int(c.value) % 24
        m = int(round((c.value - int(c.value)) * 60))
        return {"valueObject": ref("timefloat", (h, m), c.tok), "checkType": compare[c.op], "$type": "CheckTime"}
    if isinstance(c, CWeather):
        if c.name not in WEATHERS:
            raise SSModError(f"weather is one of: {', '.join(WEATHERS)}", c.tok, path)
        t = {"value": {"_value": c.name}, "onMapSpecifically": False, "$type": "CheckWeather"}
        if c.op == "!=":
            t["_invert"] = True
        return t
    return None
STRING_VAR_TYPE = ("NodeCanvas.Framework.Variable`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, "
                   "PublicKeyToken=b77a5c561934e089]]")


class DialogueCompiler:
    """resolve(kind, name, tok) -> (file_id, path_id) for kind in flag, item, disguise, stringvar, title."""

    def __init__(self, resolve, path=None, scene_object=None):
        """scene_object(type, object path, tok) -> {"_name", "_targetVariableID"}: a global-blackboard variable that
        points at a component in the scene this dialogue is used in (npc / spot dialogues only)."""
        self.resolve, self.path, self._scene_object = resolve, path, scene_object
        self.nodes, self.conns, self.refs, self.ref_index = [], [], [{"m_FileID": 0, "m_PathID": 0}], {}
        self.notes = []       # choices that had no line before them (a default prompt was added)
        self.bb = {}          # blackboard variables: name -> id
        self.bb_types = {}    # name -> C# type (text input makes System.String)
        self.n = 0
        self._end = None

    # -- helpers
    def ref(self, kind, name, tok):
        key = (kind, name)
        if key not in self.ref_index:
            fid, pid = self.resolve(kind, name, tok)
            self.refs.append({"m_FileID": fid, "m_PathID": pid})
            self.ref_index[key] = len(self.refs) - 1
        return self.ref_index[key]

    def node(self, t, **kw):
        self.n += 1
        d = dict(kw)
        d["$type"] = "NodeCanvas.DialogueTrees." + t
        d["$id"] = str(self.n)
        self.nodes.append(d)
        return d["$id"]

    def link(self, a, b):
        self.conns.append({"_sourceNode": {"$ref": a}, "_targetNode": {"$ref": b},
                           "$type": "NodeCanvas.DialogueTrees.DTConnection"})

    def end(self):
        """The node branches that lead nowhere end on (keeps every ConditionNode two-armed)."""
        if self._end is None:
            self._end = self.node("FinishNode")
        return self._end

    def bb_var(self, name, typ="System.String", tok=None):
        if name not in self.bb:
            self.bb[name] = str(uuid.uuid4())
            self.bb_types[name] = typ
        elif self.bb_types[name] != typ:
            raise SSModError(f"'{name}' already holds a {calls.friendly(self.bb_types[name])}, not a {calls.friendly(typ)}",
                             tok, self.path)
        return self.bb[name]

    # -- the context calls.py needs
    def var(self, name):
        return (self.bb_types[name], {"_name": name, "_targetVariableID": self.bb[name]}) if name in self.bb else None

    def declare(self, name, t, tok):
        return {"_name": name, "_targetVariableID": self.bb_var(name, t, tok)}

    def scene_object(self, t, objpath, tok):
        if self._scene_object is None:
            raise SSModError("objects in the scene can only be used in an npc or spot's dialogue", tok, self.path)
        return self._scene_object(t, objpath, tok)

    def object_param(self, t, objpath, tok):
        return dict({"_type": t}, **self.scene_object(t, objpath, tok))

    def object_agent(self, t, objpath, tok):
        return self.scene_object(t, objpath, tok)

    # -- statements
    def block(self, stmts, nxt):
        """Compile a list of statements; returns the entry node id (or nxt if the block is empty)."""
        entry = nxt
        i = len(stmts)
        while i > 0:
            # merge runs of consecutive actions into one ActionNode
            j = i
            while j > 0 and isinstance(stmts[j - 1], Act) and stmts[j - 1].kind != "input":
                j -= 1
            if j < i:
                entry = self.actions(stmts[j:i], entry)
                i = j
                continue
            st = stmts[i - 1]
            entry = self.stmt(st, entry)
            if isinstance(st, Choice):
                # The game draws a menu ON the speech box of the line before it. Every choice in the game's own
                # dialogues comes straight after a StatementNode; reached from a condition or an action instead,
                # nothing is shown and the conversation never ends (the player is stuck). So a choice always
                # gets a line: its own prompt, the say right before it, or a default one.
                anchored = i >= 2 and isinstance(stmts[i - 2], Say)
                if st.prompt is not None or not anchored:
                    if st.prompt is None:
                        self.notes.append(st.tok)
                    entry = self.stmt(Say(st.prompt if st.prompt is not None else DEFAULT_PROMPT, st.tok), entry)
            i -= 1
        return entry

    def stmt(self, s, nxt):
        if isinstance(s, Say):
            nid = self.node("StatementNode", statement={"_text": s.text})
            if nxt:
                self.link(nid, nxt)
            return nid
        if isinstance(s, End):
            return self.end()
        if isinstance(s, RandomBlock):
            targets = [self.block(o, nxt) or self.end() for o in s.options]
            nid = self.node("RandomNode", preventRepeat=True, useDaySeed=s.daily, subtasks=[None] * len(targets))
            for tg in targets:
                self.link(nid, tg)
            return nid
        if isinstance(s, If):
            t = self.block(s.then, nxt) or self.end()
            e = self.block(s.orelse, nxt) or self.end()
            return self.cond(s.cond, t, e)
        if isinstance(s, Choice):
            targets = [self.block(b, nxt) or self.end() for _, b in s.options]
            nid = self.node("MultipleChoiceNode", availableChoices=[{"statement": {"_text": t}} for t, _ in s.options])
            for tg in targets:
                self.link(nid, tg)
            return nid
        if isinstance(s, Act) and s.kind == "input":
            title, var = s.args
            vid = self.bb_var(var)
            task = {"startingString": {}, "textInputVariable": {"_value": self.ref("stringvar", var, s.tok)},
                    "textInputDefaultText": {}, "titleText": {"_value": self.ref("title", title, s.tok)},
                    "allowedCharacters": {}, "maxCharacters": 40, "longTextBox": True, "customFormat": "",
                    "profanityVar": {}, "stringVar": {"_name": var, "_targetVariableID": vid}, "profanityFlag": {},
                    "$type": "ShowInputUI"}
            nid = self.node("ActionNode", _action=task)
            if nxt:
                self.link(nid, nxt)
            return nid
        raise SSModError(f"internal: can't compile {s!r}")

    def actions(self, acts, nxt):
        tasks = [self.action(a) for a in acts]
        nid = self.node("ActionNode", _action={"actions": tasks, "$type": "NodeCanvas.Framework.ActionList"})
        if nxt:
            self.link(nid, nxt)
        return nid

    def action(self, a):
        k, args, tok = a.kind, a.args, a.tok
        if k in ("set", "clear"):
            return {"flag": self.ref("flag", args[0], tok), "flagParameter": {},
                    "mode": "SetTrue" if k == "set" else "SetFalse", "reevaluateConditionActivators": True,
                    "$type": "SetFlag"}
        if k in ("give_coins", "take_coins"):
            q = args[0]
            if isinstance(q, tuple):                         # give coins n;  (a whole-number variable)
                v = self.var(q[1])
                if v is None or v[0] != "System.Int32":
                    raise SSModError(f"'{q[1]}' must be a whole-number variable", tok, self.path)
                q = dict(v[1])
            else:
                q = {"_value": q}
            return {"quantity": q, "$type": "GiveCoins" if k == "give_coins" else "TakeCoins"}
        if k == "give_disguise":
            return {"disguise": {"_value": self.ref("disguise", args[0], tok)}, "$type": "GiveDisguise"}
        if k == "give_item":
            return {"item": self.ref("item", args[0], tok), "itemParam": {}, "itemList": {}, "spawnTableParam": {},
                    "quantity": args[1], "quantityParam": {"_value": args[1]}, "saveAs": {"_name": ""},
                    "saveListAs": {"_value": []}, "saveNumGivenAs": {}, "$type": "GiveItem"}
        if k == "log":
            text = calls.log_prefix(self.path) + args[0][1]
            return calls.log_task(None, {"_type": "System.Object", "_value": {"$content": text, "$type": "System.String"}})
        if k in ("setfield", "getfield"):
            cls, objpath, fld, x = args
            if k == "setfield":
                return calls.field_task(self, cls, objpath, fld, x, None, tok, self.path)
            return calls.field_task(self, cls, objpath, fld, None, x, tok, self.path)
        if k == "play":
            kind, name, loop = args
            ref = self.ref("sound", name, tok) if kind == "sound" else self.ref("asset", ("AudioAsset", name), tok)
            return {"sound": {"_value": ref}, "target": {}, "loop": loop, "delay": 0.0, "fadeInDuration": 0.0,
                    "setDoNotDestroy": False, "$type": "PlaySound"}
        if k == "call":
            cls, method, cargs, out, objpath = args
            return calls.call_task(self, cls, method, cargs, out, objpath, tok, self.path)
        if k == "take_item":
            return {"item": self.ref("item", args[0], tok), "itemParam": {}, "itemFilter": {}, "quantity": args[1],
                    "quantityParam": {"_value": args[1]}, "$type": "TakeItem"}
        raise SSModError(f"internal: unknown action {k}")

    # -- conditions
    def cond(self, c, t, f):
        if isinstance(c, CNot):
            return self.cond(c.inner, f, t)
        if isinstance(c, CAnd):
            return self.cond(c.a, self.cond(c.b, t, f), f)
        if isinstance(c, COr):
            return self.cond(c.a, t, self.cond(c.b, t, f))
        if isinstance(c, CFlag):
            task = {"flag": self.ref("flag", c.name, c.tok), "flagParameter": {}, "$type": "CheckFlag"}
        elif isinstance(c, CHas):
            task = {"item": self.ref("item", c.item, c.tok), "itemParam": {}, "minimumQuantity": c.count,
                    "minimumQuantityParam": {"_value": c.count}, "saveQuantity": {"_name": ""}, "$type": "HasItem"}
        elif isinstance(c, CCoins):
            # NOTE: no "intDataValue" key. It is a plain IntData object field, and writing {} for it makes
            # FullSerializer throw (it wants an index into _objectReferences), which kills the whole graph.
            task = {"value": {"_value": c.value}, "checkType": COMPARE[c.op], "$type": "CheckCoins"}
        elif isinstance(c, CCall):
            task = calls.check_task(self, c, COMPARE, self.path)
        elif isinstance(c, CEvent):
            raise SSModError("events can only be waited for in scripts: waitUntil (event ...);", c.tok, self.path)
        elif extra_condition(c, COMPARE, self.path, self.ref) is not None:
            task = extra_condition(c, COMPARE, self.path, self.ref)
        else:
            raise SSModError(f"internal: unknown condition {c!r}")
        nid = self.node("ConditionNode", _condition=task)
        self.link(nid, t)   # first connection = true
        self.link(nid, f)   # second = false
        return nid

    def declare_vars(self, stmts):
        """Variables made by `call ... -> x` and `input ... -> x`, known before anything is compiled (statements
        are compiled last to first, so a later line can use a variable an earlier line sets)."""
        for st in stmts:
            if isinstance(st, Act) and st.kind == "call" and st.args[3]:
                cls, method, cargs, out, objpath = st.args
                ret = calls.result_type(self, cls, method, cargs, objpath, st.tok, self.path)
                if ret != "System.Void":
                    self.bb_var(out, ret, st.tok)
            elif isinstance(st, Act) and st.kind == "getfield":
                cls, objpath, fld, out = st.args
                self.bb_var(out, calls.field_type(self, cls, objpath, fld, st.tok, self.path), st.tok)
            elif isinstance(st, Act) and st.kind == "input":
                self.bb_var(st.args[1], "System.String", st.tok)
            elif isinstance(st, If):
                self.declare_vars(st.then)
                self.declare_vars(st.orelse)
            elif isinstance(st, Choice):
                for _, b in st.options:
                    self.declare_vars(b)
            elif isinstance(st, RandomBlock):
                for b in st.options:
                    self.declare_vars(b)

    # -- output
    def compile(self, stmts):
        if not stmts:
            raise SSModError("empty dialogue", None, self.path)
        self.declare_vars(stmts)
        entry = self.block(stmts, None)
        # the start node must come first
        self.nodes.sort(key=lambda d: d["$id"] != entry)
        variables = {n: {"_name": n, "_id": i, "$type": STRING_VAR_TYPE if self.bb_types[n] == "System.String"
                         else calls.variable_type(self.bb_types[n])} for n, i in self.bb.items()}
        graph = {"version": 2.9, "type": "NodeCanvas.DialogueTrees.DialogueTree", "nodes": self.nodes,
                 "connections": self.conns, "localBlackboard": {"_name": "Local Blackboard", "_variables": variables},
                 "derivedData": {"actorParameters": [],
                                 "$type": "NodeCanvas.DialogueTrees.DialogueTree+DerivedSerializationData"}}
        return json.dumps(graph), self.refs

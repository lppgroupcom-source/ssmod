""".ssmod lexer + parser -> AST (plain dataclasses).

The language is C#-flavoured: braces, semicolons, // and /* */ comments, if/else, &&, ||, !.
See ../SSMOD.md for the reference.
"""
import os
import re
from dataclasses import dataclass, field, replace as dc_replace
from typing import List, Optional, Tuple, Union

from .meshes import MeshError, build_parts, load_svg, bounds as mesh_bounds, rect as mesh_rect, circle as mesh_circle


class SSModError(Exception):
    def __init__(self, msg, tok=None, path=None):
        where = f"{path or ''}:{tok.line}:{tok.col}: " if tok is not None else (f"{path}: " if path else "")
        super().__init__(where + msg)


# ---------------------------------------------------------------- lexer
@dataclass
class Tok:
    kind: str      # ident, string, number, color, sym, eof
    value: object
    line: int
    col: int

    def __repr__(self):
        return f"{self.kind}:{self.value!r}"


SYMS2 = ("=>", ">=", "<=", "==", "!=", "&&", "||", "->")
SYMS1 = "{}();,=<>!+-.:*/[]"


def lex(src, path=None):
    toks, i, line, col = [], 0, 1, 1
    n = len(src)

    def adv(k=1):
        nonlocal i, line, col
        for _ in range(k):
            if src[i] == "\n":
                line, col = line + 1, 1
            else:
                col += 1
            i += 1

    while i < n:
        c = src[i]
        if c in " \t\r\n":
            adv(); continue
        if src.startswith("//", i):
            while i < n and src[i] != "\n":
                adv()
            continue
        if src.startswith("/*", i):
            start = Tok("sym", "/*", line, col)
            while i < n and not src.startswith("*/", i):
                adv()
            if i >= n:
                raise SSModError("unclosed /* comment", start, path)
            adv(2); continue
        tline, tcol = line, col
        if c == '"':
            adv()
            out = []
            while True:
                if i >= n or src[i] == "\n":
                    raise SSModError("unclosed string (missing \")", Tok("string", "", tline, tcol), path)
                ch = src[i]
                if ch == "\\" and i + 1 < n:
                    nxt = src[i + 1]
                    out.append({"n": "\n", "t": "\t", '"': '"', "\\": "\\"}.get(nxt, "\\" + nxt))
                    adv(2); continue
                if ch == '"':
                    adv(); break
                out.append(ch); adv()
            toks.append(Tok("string", "".join(out), tline, tcol)); continue
        if c == "#" and i + 7 <= n and all(x in "0123456789abcdefABCDEF" for x in src[i + 1:i + 7]):
            toks.append(Tok("color", src[i + 1:i + 7], tline, tcol)); adv(7); continue
        if c.isdigit():
            j = i
            while j < n and (src[j].isdigit() or src[j] == "."):
                j += 1
            text = src[i:j]
            try:
                val = float(text) if "." in text else int(text)
            except ValueError:
                raise SSModError(f"bad number {text!r}", Tok("number", text, tline, tcol), path)
            toks.append(Tok("number", val, tline, tcol)); adv(j - i); continue
        if c.isalpha() or c == "_":
            j = i
            while j < n and (src[j].isalnum() or src[j] == "_"):
                j += 1
            toks.append(Tok("ident", src[i:j], tline, tcol)); adv(j - i); continue
        two = src[i:i + 2]
        if two in SYMS2:
            toks.append(Tok("sym", two, tline, tcol)); adv(2); continue
        if c in SYMS1:
            toks.append(Tok("sym", c, tline, tcol)); adv(); continue
        raise SSModError(f"unexpected character {c!r}", Tok("sym", c, tline, tcol), path)
    toks.append(Tok("eof", None, line, col))
    return toks


# ---------------------------------------------------------------- AST
# the standard building blocks the shorthands (box, floor, label, sign, wall) are made of: (scene, object path)
BLOCKS = {
    "box": ("Stripmall", "cardiocontroller/ecg machine/screenmask"),          # white 10x10, centred
    "floor": ("Seaport", "gate area/toll booth/floor"),                        # 1x1 floor tile, bottom-left pivot
    "text": ("Racetrack_Entrance", "entrance area/trackstart/entrance text"),  # TextMeshPro 148x50
    "wall_h": ("TownHall_Floor_B1", "Town Hall B1/InteriorWall_4x1"),          # 669 long, pivot at the left end
    "wall_v": ("TownHall_Floor_B1", "Town Hall B1/InteriorWall_1x36"),         # 693 tall, pivot at the bottom
}


@dataclass
class Loc:
    x: float = 0.0
    y: float = 0.0
    landmark: Optional[str] = None      # "Doctor Duck" (+ x, y as offset)
    tok: Optional[Tok] = None


@dataclass
class Say:
    text: str
    tok: Tok


@dataclass
class Act:
    kind: str                            # set, clear, give_item, take_item, give_coins, take_coins, give_disguise, input
    args: tuple
    tok: Tok


@dataclass
class If:
    cond: object
    then: list
    orelse: list
    tok: Tok


@dataclass
class Choice:
    options: List[Tuple[str, list]]
    tok: Tok
    prompt: Optional[str] = None       # choice "What'll it be?" { ... }: the line the menu is shown on


@dataclass
class End:
    tok: Tok


# conditions
@dataclass
class CFlag:
    name: str
    tok: Tok


@dataclass
class CHas:
    item: str
    count: int
    tok: Tok


@dataclass
class CCoins:
    op: str
    value: int
    tok: Tok


@dataclass
class CNot:
    inner: object


@dataclass
class CAnd:
    a: object
    b: object


@dataclass
class COr:
    a: object
    b: object


@dataclass
class CEvent:
    """event player.OnVehicleChange: true the moment the game raises that C# event (scripts only)"""
    cls: Optional[str]
    objpath: Optional[str]
    name: str
    tok: Tok


@dataclass
class CChance:
    """chance(30): true 30% of the time"""
    percent: float
    tok: Tok


@dataclass
class CHour:
    """hour >= 20: the time of day in game hours (0-24)"""
    op: str
    value: float
    tok: Tok


@dataclass
class CWeather:
    """weather == Rainy / weather != Clear"""
    op: str
    name: str
    tok: Tok


@dataclass
class RandomBlock:
    """random { "Hi!"; "Hello!"; { say "Hey"; give coins 1; } }: one option per line or { block }.
    daily: the same option all day (a new one each day); repeats are avoided."""
    options: list
    daily: bool
    tok: Tok


@dataclass
class Parallel:
    """parallel { { ... } { ... } }: run every branch at the same time; done when all are done."""
    branches: list
    tok: Tok


@dataclass
class ListCmd:
    """lists in scripts: add / remove / clear / set (names[i] = x)"""
    kind: str
    name: str
    args: tuple
    tok: Tok


@dataclass
class CListHas:
    """names contains "Bob" """
    name: str
    value: object
    tok: Tok


@dataclass
class ActorCmd:
    """npc behaviour (in a script that has an npc: `behavior { }` or `script ... by Npc`):
    goto, wander, face, look, sit, suspicious, alert, leave."""
    kind: str
    args: dict
    tok: Tok


@dataclass
class CCall:
    """call Fire_GetFireCount() > 0   /   call Xmas_IsActive()"""
    cls: Optional[str]
    method: str
    args: list                       # [(kind, value, tok)]: num, str, bool, ident, item, asset, flag, disguise
    op: Optional[str]
    value: object                    # (kind, value) or None (= true)
    tok: Tok
    objpath: Optional[str] = None    # GateController("Seaport Gate").IsOpen(): the object it runs on


@dataclass
class ModInfo:
    name: str
    author: str = ""
    version: str = "1.0"


@dataclass
class FlagDecl:
    name: str
    tok: Tok


@dataclass
class ItemDecl:
    name: str
    props: dict
    tok: Tok


@dataclass
class ThingDecl:                        # npc / spot
    kind: str
    name: str
    scene: str
    loc: Loc
    props: dict
    dialogue: list
    tok: Tok


@dataclass
class PickupDecl:
    item: str
    count: int
    scene: str
    locs: List[Loc]
    tok: Tok


# script statements / conditions
@dataclass
class VarDecl:
    name: str
    value: object          # int, float or bool
    tok: Tok


@dataclass
class Assign:
    name: str
    op: str                # = += -= *= /=
    value: object
    tok: Tok


@dataclass
class Wait:
    seconds: float
    tok: Tok


@dataclass
class WaitUntil:
    cond: object
    tok: Tok


@dataclass
class While:
    cond: object           # None = forever
    body: list
    tok: Tok


@dataclass
class Speak:
    text: str
    tok: Tok


@dataclass
class Weather:
    kind: str
    tok: Tok


@dataclass
class CVar:
    name: str
    op: str                # == != > < >= <=  (or "bool")
    value: object
    tok: Tok


@dataclass
class CNear:
    target: str            # landmark / npc name
    distance: float
    tok: Tok


@dataclass
class EngineCall:
    kind: str              # move, scale, timescale
    args: tuple
    tok: Tok


@dataclass
class CallCmd:
    type_name: str         # e.g. UIDebugModule or UnityEngine.Time
    method: str
    args: list             # python literals: bool / int / float / str
    tok: Tok


@dataclass
class CKey:
    key: str
    tok: Tok


@dataclass
class ScriptDecl:
    name: str
    scene: str
    loc: Optional[Loc]
    speaker: Optional[str]
    body: list
    tok: Tok


@dataclass
class RouteStep:
    kind: str              # goto, wait, speak
    value: object          # Loc / seconds / text
    tok: Tok


@dataclass
class PlaceDecl:
    name: str              # object name in the source scene
    source: str            # source scene
    scene: str             # target scene
    loc: Loc
    scale: Tuple[float, float]
    show_if: Optional[str]
    tok: Tok
    hide_if: Optional[str] = None
    flip: bool = False
    size: Optional[Tuple[float, float]] = None     # absolute size in world units (replaces scale)
    color: Optional[str] = None                    # RRGGBB tint for every sprite of the object
    rotate: float = 0.0                            # degrees, counter-clockwise
    layer: int = 0                                 # added to the sprites' sorting order (draw above/below)
    text: Optional[str] = None                     # new words for a sign (TextMeshPro) object
    front: float = 0.0                             # nudge towards the camera (draw in front of things at the same y)
    mesh: Optional[tuple] = None                   # custom geometry: (mesh name, part number, vertices, indices, centre)
    image: Optional[tuple] = None                  # a picture: (image name, png path, world width, world height)
    bob: Optional[tuple] = None                    # (dx, dy, seconds): bob back and forth (the game's AutoMoverSine)
    hud: Optional[tuple] = None                    # (name, x, y): stuck to the screen (the game's AnchorIntoCamera)
    as_name: Optional[str] = None                  # place ... as Name: `call` can reach it by that name
    anim: Optional[object] = None                  # place ... animate Name: an AnimDecl (keyframes)


@dataclass
class MeshDecl:
    name: str
    parts: list            # [(colour, vertices, indices)] in drawing order (see meshes.build_parts)
    tok: Tok


@dataclass
class ImageDecl:
    name: str
    path: str              # the .png (or .jpg) file
    size: Tuple[float, float]   # world units (1 pixel = 1 unit unless scale/size say otherwise)
    tok: Tok


@dataclass
class SoundDecl:
    name: str
    path: str              # a .wav (or mp3/ogg/m4a when ffmpeg is installed)
    volume: float
    tok: Tok


@dataclass
class OverrideDecl:
    """override "Doctor Duck" in "Campground_Hub" { dialogue { ... } }: a game character says your lines."""
    name: str              # the object (name or path) whose talk object(s) get the new dialogue
    scene: str
    dialogue: list
    tok: Tok


@dataclass
class HudDecl:
    """hud Score "Score: 0" in "Scene" at (x, y): text stuck to the screen while you're in that scene."""
    name: str
    text: str
    scene: str
    x: float
    y: float
    color: Optional[str]
    scale: float
    show_if: Optional[str]
    hide_if: Optional[str]
    tok: Tok


@dataclass
class AnimDecl:
    """animation Name [once] { at 0 { rotate 0; move (0, 0); scale 1; show Picture; } at 2 { ... } }"""
    name: str
    loop: bool
    keys: list             # [(time, {"rotate": deg, "move": (dx, dy), "scale": (sx, sy), "show": image name})]
    tok: Tok
    frames: dict = field(default_factory=dict)     # image name -> (name, png, w, h), filled in at the end


@dataclass
class HideDecl:
    name: str
    scene: str
    tok: Tok


@dataclass
class RouteDecl:
    name: str
    scene: str
    owner: str             # a named object in the scene (its GameActor walks the route)
    steps: list
    tok: Tok


@dataclass
class PatrolCmd:
    who: str               # npc of this mod or named scene object (for the record only)
    route: str             # route of this mod or a named scene object with a PatrolRoute
    tok: Tok


EXIT_IDS = {"Main": 0, "North": 1, "South": 2, "East": 3, "West": 4, "NorthAlt": 11, "SouthAlt": 12,
            "EastAlt": 13, "WestAlt": 14}


@dataclass
class AreaDecl:
    name: str              # new scene name, e.g. LPP_Debug
    source: str            # scene it's copied from
    display: str           # name shown in game
    connects: list         # (my_exit, other_scene, other_exit, tok)
    closes: list           # exit names
    tok: Tok
    room: Optional[tuple] = None   # (x0, y0, x1, y1): resize a Town Hall basement style room
    doors: list = field(default_factory=list)   # DoorDecl


@dataclass
class DoorDecl:
    exit: str              # exit name (its id)
    loc: "Loc"
    facing: str            # North / South / East / West: the way you walk to leave through it
    show_if: Optional[str]
    hide_if: Optional[str]
    tok: Tok
    frame: Optional[bool] = None   # True: a real door (frame + open door); False: just the exit zone; None: decide


@dataclass
class ElevatorDecl:
    name: str
    floors: list           # (scene, Loc, label, tok)
    tok: Tok


@dataclass
class ModFile:
    path: str
    info: Optional[ModInfo] = None
    flags: List[FlagDecl] = field(default_factory=list)
    items: List[ItemDecl] = field(default_factory=list)
    things: List[ThingDecl] = field(default_factory=list)
    pickups: List[PickupDecl] = field(default_factory=list)
    scripts: List[ScriptDecl] = field(default_factory=list)
    places: List[PlaceDecl] = field(default_factory=list)
    hides: List[HideDecl] = field(default_factory=list)
    overrides: List[OverrideDecl] = field(default_factory=list)
    huds: List[HudDecl] = field(default_factory=list)
    routes: List[RouteDecl] = field(default_factory=list)
    areas: List[AreaDecl] = field(default_factory=list)
    elevators: List[ElevatorDecl] = field(default_factory=list)
    meshes: List[MeshDecl] = field(default_factory=list)
    images: List[ImageDecl] = field(default_factory=list)
    sounds: List[SoundDecl] = field(default_factory=list)
    animations: List[AnimDecl] = field(default_factory=list)
    world: dict = field(default_factory=dict)       # world { physics off; gravity (x, y); }: engine settings


# ---------------------------------------------------------------- parser
class Parser:
    def __init__(self, toks, path):
        self.t, self.i, self.path = toks, 0, path

    # helpers
    @property
    def cur(self):
        return self.t[self.i]

    def peek(self, k=1):
        return self.t[min(self.i + k, len(self.t) - 1)]

    def err(self, msg, tok=None):
        return SSModError(msg, tok or self.cur, self.path)

    def at(self, kind, value=None):
        c = self.cur
        return c.kind == kind and (value is None or c.value == value)

    def at_word(self, *words):
        return self.cur.kind == "ident" and self.cur.value in words

    def take(self, kind, value=None, what=None):
        c = self.cur
        if not self.at(kind, value):
            want = what or (repr(value) if value is not None else kind)
            got = "end of file" if c.kind == "eof" else repr(c.value)
            raise self.err(f"expected {want}, found {got}")
        self.i += 1
        return c

    def sym(self, s):
        return self.take("sym", s)

    def word(self, w):
        return self.take("ident", w, what=f"'{w}'")

    def ident(self, what="a name"):
        return self.take("ident", what=what).value

    def string(self, what="a \"text\""):
        return self.take("string", what=what).value

    def number(self):
        neg = False
        if self.at("sym", "-"):
            self.i += 1
            neg = True
        v = self.take("number", what="a number").value
        return -v if neg else v

    def semi(self):
        if not self.at("sym", ";"):
            raise self.err("missing ';'", self.t[self.i - 1] if self.i else self.cur)
        self.i += 1

    # file
    # ---- functions (new "methods") and templates (new "classes"): kept as tokens, expanded where used
    def scan_definitions(self):
        """Top-level `function Name(a, b) { ... }` and `template Name { ... }`."""
        self.functions, self.templates = {}, {}
        depth, i = 0, 0
        t = self.t
        while t[i].kind != "eof":
            k = t[i]
            if k.kind == "sym" and k.value == "{":
                depth += 1
            elif k.kind == "sym" and k.value == "}":
                depth -= 1
            elif depth == 0 and k.kind == "ident" and k.value in ("function", "template") and t[i + 1].kind == "ident":
                name, j, params = t[i + 1].value, i + 2, []
                if k.value == "function" and t[j].kind == "sym" and t[j].value == "(":
                    j += 1
                    while not (t[j].kind == "sym" and t[j].value == ")"):
                        if t[j].kind == "ident":
                            params.append(t[j].value)
                        elif not (t[j].kind == "sym" and t[j].value == ","):
                            raise SSModError("function parameters are names separated by commas", t[j], self.path)
                        j += 1
                    j += 1
                if not (t[j].kind == "sym" and t[j].value == "{"):
                    raise SSModError(f"expected '{{' to start {k.value} {name}", t[j], self.path)
                start, d = j, 0
                while True:
                    if t[j].kind == "eof":
                        raise SSModError(f"{k.value} {name} is missing its closing '}}'", k, self.path)
                    if t[j].kind == "sym" and t[j].value == "{":
                        d += 1
                    elif t[j].kind == "sym" and t[j].value == "}":
                        d -= 1
                        if d == 0:
                            break
                    j += 1
                table = self.functions if k.value == "function" else self.templates
                if name in table:
                    raise SSModError(f"{k.value} {name} is defined twice", k, self.path)
                table[name] = (params, t[start:j + 1], k, j + 1)     # body tokens include the braces
                i = j
            i += 1

    def with_tokens(self, toks, fn):
        """Parse toks (plus an end marker) with fn, then carry on where we were."""
        saved = (self.t, self.i)
        self.t, self.i = list(toks) + [Tok("eof", None, toks[-1].line if toks else 0, 0)], 0
        try:
            return fn()
        finally:
            self.t, self.i = saved

    def inline_function(self, kind):
        tok = self.cur
        name = self.ident()
        params, body, _, _ = self.functions[name]
        self.sym("(")
        args = []
        while not self.at("sym", ")"):
            arg = []
            if self.at("sym", "-"):
                arg.append(self.cur)
                self.i += 1
            if self.cur.kind not in ("number", "string", "ident", "color"):
                raise self.err("a function value is a number, \"text\", a name or a colour")
            arg.append(self.cur)
            self.i += 1
            args.append(arg)
            if self.at("sym", ","):
                self.i += 1
        self.sym(")")
        self.semi()
        if len(args) != len(params):
            raise self.err(f"{name} takes {len(params)} value(s) ({', '.join(params) or 'none'}), not {len(args)}", tok)
        stack = self.__dict__.setdefault("_inlining", [])
        if name in stack:
            raise self.err(f"{name} calls itself ({' -> '.join(stack + [name])}); functions can't be recursive", tok)
        sub = dict(zip(params, args))
        toks = []
        for b in body:
            if b.kind == "ident" and b.value in sub:
                toks.extend(Tok(a.kind, a.value, tok.line, tok.col) for a in sub[b.value])
            elif b.kind == "string" and sub:
                v = b.value
                for p_, a in sub.items():
                    v = v.replace("{" + p_ + "}", "".join(str(x.value) if x.kind != "color" else "#" + x.value for x in a))
                toks.append(Tok("string", v, b.line, b.col))
            else:
                toks.append(b)
        stack.append(name)
        try:
            return self.with_tokens(toks, self.block if kind == "dialogue" else self.sblock)
        finally:
            stack.pop()

    def parse(self):
        mf = ModFile(self.path)
        self.scan_definitions()
        pending_meshes = []        # `place mesh X ...` statements, resolved at the end (the mesh may be declared later)
        pending_images = []        # the same for `place image X ...`
        while not self.at("eof"):
            tok = self.cur
            if self.at_word("mod"):
                self.i += 1
                info = ModInfo(self.string("the mod's name in quotes"))
                while not self.at("sym", ";"):
                    if self.at_word("by"):
                        self.i += 1; info.author = self.string()
                    elif self.at_word("version"):
                        self.i += 1
                        info.version = str(self.number()) if self.at("number") else self.string()
                    else:
                        raise self.err("expected 'by', 'version' or ';'")
                self.semi()
                mf.info = info
            elif self.at_word("flag"):
                self.i += 1
                mf.flags.append(FlagDecl(self.ident("a flag name"), tok))
                while self.at("sym", ","):
                    self.i += 1
                    mf.flags.append(FlagDecl(self.ident("a flag name"), self.t[self.i - 1]))
                self.semi()
            elif self.at_word("item"):
                self.i += 1
                name = self.ident("an item name")
                mf.items.append(ItemDecl(name, self.props_block(allow_dialogue=False)[0], tok))
            elif self.at_word("function", "template") and self.peek().kind == "ident":
                self.i = (self.functions if self.cur.value == "function" else self.templates)[self.peek().value][3]
            elif self.at_word("on") and self.peek().kind == "ident" and self.peek().value == "key":
                self.i += 2
                key = self.string('a key in quotes, like "e" or "space"')
                self.word("in")
                scene = self.string("a scene name")
                speaker = None
                if self.at_word("by"):
                    self.i += 1
                    speaker = self.ident("an npc of this mod")
                self.vars = {}
                body = self.sblock()
                # a new control: wait for the key, run the body, a short pause so one press runs it once
                loop = While(None, [WaitUntil(CKey(key.lower(), tok), tok)] + body + [Wait(0.3, tok)], tok)
                mf.scripts.append(ScriptDecl(f"key_{key}_{tok.line}", scene, None, speaker, [loop], tok))
            elif self.at_word("npc", "spot"):
                kind = self.cur.value
                self.i += 1
                name = self.ident(f"a name for the {kind}")
                base = None
                if self.at_word("from"):
                    self.i += 1
                    btok = self.cur
                    base = self.ident("a template name")
                    if base not in self.templates:
                        raise self.err(f"there is no template called {base} (define it with  template {base} {{ ... }})", btok)
                self.word("in")
                scene = self.string("a scene name like \"Campground_Hub\"")
                self.word("at")
                loc = self.loc()
                if base and self.at("sym", ";"):
                    self.i += 1
                    props, dialogue = {}, None
                else:
                    props, dialogue = self.props_block(allow_dialogue=True)
                if base:                     # the npc's own parts win; look { } colours are merged
                    tprops, tdialogue = self.with_tokens(self.templates[base][1], lambda: self.props_block(allow_dialogue=True))
                    merged = dict(tprops)
                    for k_, v_ in props.items():
                        merged[k_] = dict(tprops[k_], **v_) if isinstance(v_, dict) and isinstance(tprops.get(k_), dict) else v_
                    props = merged
                    if dialogue is None:
                        dialogue = tdialogue
                if dialogue is None and kind == "spot":
                    raise self.err(f"spot {name} needs a dialogue {{ ... }} block", tok)
                dialogue = dialogue or []
                if "__behavior" in props:
                    body, btok = props.pop("__behavior")
                    if kind != "npc":
                        raise self.err("only an npc can have a behavior (a spot has no body to move)", btok)
                    mf.scripts.append(ScriptDecl(f"{name}_behavior", scene, None, name, body, btok))
                mf.things.append(ThingDecl(kind, name, scene, loc, props, dialogue, tok))
            elif self.at_word("pickup"):
                self.i += 1
                item = self.string() if self.at("string") else self.ident("an item name")
                count = 1
                if self.at_word("x"):
                    self.i += 1
                    count = int(self.number())
                self.word("in")
                scene = self.string("a scene name")
                self.word("at")
                locs = [self.loc()]
                while self.at("sym", ","):
                    self.i += 1
                    locs.append(self.loc())
                self.semi()
                mf.pickups.append(PickupDecl(item, count, scene, locs, tok))
            elif self.at_word("elevator"):
                self.i += 1
                name = self.ident("an elevator name")
                self.sym("{")
                floors = []
                while not self.at("sym", "}"):
                    t0 = self.cur
                    scene = self.string("a scene for this floor")
                    self.word("at")
                    loc = self.loc()
                    label = f"{len(floors) + 1}F"
                    if self.at_word("named"):
                        self.i += 1
                        label = self.string()
                    self.semi()
                    floors.append((scene, loc, label, t0))
                self.sym("}")
                if not 2 <= len(floors) <= 6:
                    raise self.err("an elevator needs 2 to 6 floors", tok)
                mf.elevators.append(ElevatorDecl(name, floors, tok))
            elif self.at_word("area"):
                self.i += 1
                name = self.ident("the new area's name (letters, digits, _)")
                self.word("from")
                source = self.string("the scene to copy the ground from")
                display = name.replace("_", " ")
                if self.at_word("named"):
                    self.i += 1
                    display = self.string()
                self.sym("{")
                connects, closes, doors, room = [], [], [], None
                while not self.at("sym", "}"):
                    t0 = self.cur
                    if self.at_word("room"):
                        self.i += 1
                        self.sym("("); x0 = self.number(); self.sym(","); y0 = self.number(); self.sym(")")
                        self.word("to")
                        self.sym("("); x1 = self.number(); self.sym(","); y1 = self.number(); self.sym(")")
                        if x1 - x0 < 300 or y1 - y0 < 300:
                            raise self.err("a room must be at least 300 x 300", t0)
                        room = (float(x0), float(y0), float(x1), float(y1))
                    elif self.at_word("door"):
                        self.i += 1
                        ex = self.exit_name()
                        self.word("at")
                        dloc = self.loc()
                        facing = {"North": "North", "South": "South", "East": "East", "West": "West"}.get(
                            ex.replace("Alt", ""), "South")
                        show_if = hide_if = None
                        frame = None
                        while self.at_word("facing", "showIf", "hideIf", "framed", "plain", "narrow"):
                            w = self.cur.value
                            self.i += 1
                            if w == "narrow":                 # the doorway-sized exit zone, but no door art
                                frame = "narrow"
                            elif w in ("framed", "plain"):
                                frame = w == "framed"
                            elif w == "facing":
                                facing = self.ident("North, South, East or West")
                                if facing not in ("North", "South", "East", "West"):
                                    raise self.err("facing must be North, South, East or West", self.t[self.i - 1])
                            elif w == "showIf":
                                show_if = self.ident("a flag")
                            else:
                                hide_if = self.ident("a flag")
                        doors.append(DoorDecl(ex, dloc, facing, show_if, hide_if, t0, frame))
                    elif self.at_word("connect"):
                        self.i += 1
                        mine = self.exit_name()
                        self.word("to")
                        other = self.string("the neighbouring scene")
                        theirs = self.exit_name()
                        connects.append((mine, other, theirs, t0))
                    elif self.at_word("close"):
                        self.i += 1
                        closes.append(self.exit_name())
                        while self.at("sym", ","):
                            self.i += 1
                            closes.append(self.exit_name())
                    else:
                        raise self.err("expected connect, close, door or room")
                    self.semi()
                self.sym("}")
                mf.areas.append(AreaDecl(name, source, display, connects, closes, tok, room, doors))
            elif self.at_word("box", "floor", "label", "sign", "wall") and self.peek().kind in ("ident", "string"):
                mf.places.extend(self.shape())
            elif self.at_word("shop") and self.peek().kind == "ident":
                mf.things.append(self.shop())
            elif self.at_word("mesh") and self.peek().kind == "ident":
                md = self.mesh()
                if any(x.name == md.name for x in mf.meshes):
                    raise self.err(f"mesh {md.name} is declared twice", md.tok)
                mf.meshes.append(md)
            elif self.at_word("world") and self.peek().kind == "sym" and self.peek().value == "{":
                self.i += 2
                while not self.at("sym", "}"):
                    ktok = self.cur
                    k_ = self.ident("physics or gravity")
                    if k_ == "physics":
                        v_ = self.ident("on or off")
                        if v_ not in ("on", "off"):
                            raise self.err("physics is on or off", ktok)
                        mf.world["physics"] = (v_ == "on", ktok)
                    elif k_ == "gravity":
                        mf.world["gravity"] = (self.pair(), ktok)
                    else:
                        raise self.err(f"world has physics and gravity (not '{k_}')", ktok)
                    self.semi()
                self.sym("}")
            elif self.at_word("animation") and self.peek().kind == "ident":
                self.i += 1
                name = self.ident("a name for the animation")
                loop = True
                if self.at_word("once"):
                    self.i += 1
                    loop = False
                self.sym("{")
                keys = []
                while not self.at("sym", "}"):
                    ktok = self.cur
                    self.word("at")
                    t_ = float(self.number())
                    self.sym("{")
                    key = {}
                    while not self.at("sym", "}"):
                        w_ = self.ident("rotate, move, scale or show")
                        if w_ == "rotate":
                            key["rotate"] = float(self.number())
                        elif w_ == "move":
                            key["move"] = self.pair()
                        elif w_ == "scale":
                            if self.at("sym", "("):
                                key["scale"] = self.pair()
                            else:
                                k_ = float(self.number())
                                key["scale"] = (k_, k_)
                        elif w_ == "show":
                            key["show"] = self.ident("an image declared with  image Name from \"x.png\";")
                        else:
                            raise self.err(f"an animation key has rotate, move, scale and show (not '{w_}')")
                        self.semi()
                    self.sym("}")
                    if keys and t_ <= keys[-1][0]:
                        raise self.err("keys must be in order of time", ktok)
                    keys.append((t_, key))
                self.sym("}")
                if not keys:
                    raise self.err("an animation needs at least one  at TIME { ... }", tok)
                if any(x.name == name for x in mf.animations):
                    raise self.err(f"animation {name} is declared twice", tok)
                mf.animations.append(AnimDecl(name, loop, keys, tok))
            elif self.at_word("sound") and self.peek().kind == "ident":
                self.i += 1
                name = self.ident("a name for the sound")
                self.word("from")
                ftok = self.cur
                fname = self.string("a .wav file name in quotes")
                volume = 1.0
                if self.at_word("volume"):
                    self.i += 1
                    volume = float(self.number())
                self.semi()
                path = fname if os.path.isabs(fname) else os.path.join(os.path.dirname(os.path.abspath(self.path or ".")), fname)
                if not os.path.exists(path):
                    raise self.err(f"can't find {fname} (looked in {os.path.dirname(path)})", ftok)
                if any(x.name == name for x in mf.sounds):
                    raise self.err(f"sound {name} is declared twice", tok)
                mf.sounds.append(SoundDecl(name, path, volume, tok))
            elif self.at_word("image") and self.peek().kind == "ident":
                im = self.image()
                if any(x.name == im.name for x in mf.images):
                    raise self.err(f"image {im.name} is declared twice", im.tok)
                mf.images.append(im)
            elif self.at_word("place"):
                self.i += 1
                mesh_name = image_name = None
                if self.at_word("mesh") and self.peek().kind == "ident":
                    self.i += 1
                    mesh_name = self.ident("a mesh name")
                    name = BLOCKS["box"][1]
                elif self.at_word("image") and self.peek().kind == "ident":
                    self.i += 1
                    image_name = self.ident("an image name")
                    name = BLOCKS["box"][1]
                else:
                    name = self.string("the object's name in quotes")
                source = None
                if mesh_name or image_name:
                    source = BLOCKS["box"][0]
                elif self.at_word("from"):
                    self.i += 1
                    source = self.string("the scene to copy it from")
                self.word("in")
                scene = self.string("the scene to put it in")
                self.word("at")
                loc = self.loc()
                scale, show_if, hide_if, flip = (1.0, 1.0), None, None, False
                size = color = None
                rotate, layer = 0.0, 0
                text = None
                front = 0.0
                bob = as_name = anim_name = None
                while self.at_word("scale", "showIf", "hideIf", "flip", "size", "color", "rotate", "layer", "text", "front", "bob", "as",
                                   "animate"):
                    if self.cur.value == "animate":
                        self.i += 1
                        anim_name = (self.ident("an animation name"), self.t[self.i - 1])
                    elif self.cur.value == "as":
                        self.i += 1
                        as_name = self.ident("a name to call it by")
                    elif self.cur.value == "bob":
                        self.i += 1
                        if self.at("sym", "("):
                            dx, dy = self.pair()
                        else:
                            dx, dy = 0.0, float(self.number())
                        secs = 2.0
                        if self.at_word("every"):
                            self.i += 1
                            secs = float(self.number())
                        bob = (dx, dy, secs)
                    elif self.cur.value == "front":
                        self.i += 1
                        front = float(self.number())
                    elif self.cur.value == "text":
                        self.i += 1
                        text = self.string("the sign's text")
                    elif self.cur.value == "size":
                        self.i += 1
                        self.sym("("); w = self.number(); self.sym(","); h = self.number(); self.sym(")")
                        size = (float(w), float(h))
                    elif self.cur.value == "color":
                        self.i += 1
                        ctok = self.take("color", what="a colour like #FF8800")
                        color = ctok.value
                    elif self.cur.value == "rotate":
                        self.i += 1
                        rotate = float(self.number())
                    elif self.cur.value == "layer":
                        self.i += 1
                        layer = int(self.number())
                    elif self.cur.value == "flip":
                        self.i += 1
                        flip = True
                    elif self.cur.value == "hideIf":
                        self.i += 1
                        hide_if = self.ident("a flag")
                    elif self.cur.value == "scale":
                        self.i += 1
                        if self.at("sym", "("):
                            self.sym("(")
                            sx = float(self.number())
                            sy = sx
                            if self.at("sym", ","):
                                self.i += 1
                                sy = float(self.number())
                            self.sym(")")
                        else:                                # scale 0.5  (same both ways)
                            sx = sy = float(self.number())
                        scale = (sx, sy)
                    else:
                        self.i += 1
                        show_if = self.ident("a flag")
                self.semi()
                if image_name:
                    if text is not None or layer:
                        raise self.err("an image takes scale, size, rotate, flip, color, front, showIf and hideIf", tok)
                    pending_images.append((image_name, size, PlaceDecl(name, source, scene, loc, scale, show_if, tok,
                                                                       hide_if, flip, None, color, rotate, 0, None, front,
                                                                       bob=bob, as_name=as_name, anim=anim_name)))
                    continue
                if mesh_name:
                    if size or text is not None or layer:
                        raise self.err("a mesh takes scale, rotate, flip, color, front, showIf and hideIf (not size, text or layer)", tok)
                    pending_meshes.append((mesh_name, PlaceDecl(name, source, scene, loc, scale, show_if, tok, hide_if, flip,
                                                                None, color, rotate, 0, None, front, bob=bob,
                                                                as_name=as_name, anim=anim_name)))
                    continue
                mf.places.append(PlaceDecl(name, source or scene, scene, loc, scale, show_if, tok, hide_if, flip,
                                           size, color, rotate, layer, text, front, bob=bob, as_name=as_name,
                                           anim=anim_name))
            elif self.at_word("hud") and self.peek().kind == "ident":
                self.i += 1
                name = self.ident("a name for the text (to change it later)")
                text = self.string("the text in quotes")
                self.word("in")
                scene = self.string("a scene name")
                self.word("at")
                x, y = self.pair()
                color, scale, show_if, hide_if = None, 1.0, None, None
                while self.at_word("color", "scale", "showIf", "hideIf"):
                    w_ = self.cur.value
                    self.i += 1
                    if w_ == "color":
                        color = self.take("color", what="a colour like #FFD166").value
                    elif w_ == "scale":
                        scale = float(self.number())
                    elif w_ == "showIf":
                        show_if = self.ident("a flag")
                    else:
                        hide_if = self.ident("a flag")
                self.semi()
                mf.huds.append(HudDecl(name, text, scene, x, y, color, scale, show_if, hide_if, tok))
            elif self.at_word("override") and self.peek().kind == "string":
                self.i += 1
                name = self.string()
                self.word("in")
                scene = self.string("a scene name")
                props, dialogue = self.props_block(allow_dialogue=True)
                if props:
                    raise self.err("override takes a dialogue { } (other parts can't be overridden yet)", tok)
                if not dialogue:
                    raise self.err("override needs a dialogue { ... }", tok)
                mf.overrides.append(OverrideDecl(name, scene, dialogue, tok))
            elif self.at_word("hide"):
                self.i += 1
                name = self.string("the object's name in quotes")
                self.word("in")
                mf.hides.append(HideDecl(name, self.string("a scene"), tok))
                self.semi()
            elif self.at_word("route"):
                self.i += 1
                name = self.ident("a route name")
                self.word("in")
                scene = self.string("a scene")
                self.word("for")
                owner = self.string("the name of the character who walks it")
                mf.routes.append(RouteDecl(name, scene, owner, self.route_steps(), tok))
            elif self.at_word("script"):
                self.i += 1
                name = self.ident("a name for the script")
                self.word("in")
                scene = self.string("a scene name")
                loc = speaker = None
                while self.at_word("at", "by"):
                    if self.cur.value == "at":
                        self.i += 1
                        loc = self.loc()
                    else:
                        self.i += 1
                        speaker = self.ident("the npc who speaks for this script")
                self.vars = {}
                body = self.sblock()
                mf.scripts.append(ScriptDecl(name, scene, loc, speaker, body, tok))
            else:
                raise self.err("expected mod, flag, item, npc, spot, pickup, script, place, hide, route or area")
        mf.flags.extend(getattr(self, "auto_flags", []))
        if mf.info is None:
            raise SSModError('missing the header line, e.g.  mod "My Mod" by "Me";', None, self.path)
        pics = {im.name: im for im in mf.images}
        anims = {a.name: a for a in mf.animations}
        for a in mf.animations:
            for _, key in a.keys:
                if "show" in key:
                    im = pics.get(key["show"])
                    if im is None:
                        raise self.err(f"animation {a.name} shows {key['show']}, but there's no image called that", a.tok)
                    a.frames[im.name] = (im.name, im.path, im.size[0], im.size[1])

        def link_anim(pd):
            if not pd.anim:
                return pd
            nm, ntok = pd.anim
            if nm not in anims:
                raise self.err(f"there is no animation called {nm} (declare it with  animation {nm} {{ ... }})", ntok)
            a = anims[nm]
            if pd.bob and any("move" in k for _, k in a.keys):
                raise self.err("an object can't both bob and have an animation that moves it", ntok)
            return dc_replace(pd, anim=a)
        pending_images = [(n_, sz, link_anim(b_)) for n_, sz, b_ in pending_images]
        pending_meshes = [(n_, link_anim(b_)) for n_, b_ in pending_meshes]
        mf.places = [link_anim(p_) for p_ in mf.places]
        for image_name, size, base in pending_images:
            im = pics.get(image_name)
            if im is None:
                raise self.err(f'there is no image called {image_name} in this mod (declare it with  image {image_name} '
                               f'from "picture.png";)', base.tok)
            w, h = size or im.size                      # `size` on the placement overrides the declared size
            mf.places.append(dc_replace(base, image=(im.name, im.path, w, h)))
        known = {md.name: md for md in mf.meshes}
        for mesh_name, base in pending_meshes:
            md = known.get(mesh_name)
            if md is None:
                raise self.err(f"there is no mesh called {mesh_name} in this mod (declare it with  mesh {mesh_name} {{ ... }})", base.tok)
            x0, y0, x1, y1 = mesh_bounds(md.parts)
            for k, (colour, verts, idx) in enumerate(md.parts):           # one sprite per colour, stacked in order
                mf.places.append(dc_replace(base, color=base.color or colour, front=base.front + 0.02 * k,
                                            mesh=(md.name, k, verts, idx, ((x0 + x1) / 2, (y0 + y1) / 2), (x1 - x0, y1 - y0))))
        return mf

    # building shorthands: box / floor / label / sign / wall. Each one is just one or more `place` statements
    # using the standard building blocks, so mods don't need a generator script for simple shapes.
    def pair(self):
        self.sym("("); a = float(self.number()); self.sym(","); b = float(self.number()); self.sym(")")
        return a, b

    def shape_opts(self, allowed):
        o = {"size": None, "color": None, "textColor": None, "front": None, "layer": None, "scale": None,
             "showIf": None, "hideIf": None}
        while self.at_word(*allowed):
            k = self.cur.value
            self.i += 1
            if k == "size":
                o[k] = self.pair()
            elif k in ("color", "textColor"):
                o[k] = self.take("color", what="a colour like #FF8800").value
            elif k == "front":
                o[k] = float(self.number())
            elif k == "layer":
                o[k] = int(self.number())
            elif k == "scale":
                if self.at("sym", "("):
                    self.sym("("); sx = float(self.number()); sy = sx
                    if self.at("sym", ","):
                        self.i += 1; sy = float(self.number())
                    self.sym(")")
                    o[k] = (sx, sy)
                else:
                    v = float(self.number()); o[k] = (v, v)
            else:
                o[k] = self.ident("a flag")
        return o

    def shape(self):
        tok = self.cur
        kind = self.cur.value
        self.i += 1
        words = self.string("the words in quotes") if kind in ("label", "sign") else None
        self.word("in")
        scene = self.string("the scene to put it in")

        def mk(src, loc, scale=(1.0, 1.0), size=None, color=None, layer=0, text=None, front=0.0, o=None):
            return PlaceDecl(src[1], src[0], scene, loc, scale, o["showIf"] if o else None, tok, o["hideIf"] if o else None,
                             False, size, color, 0.0, layer, text, front)

        def moved(loc, dx, dy):
            return Loc(loc.x + dx, loc.y + dy, loc.landmark, loc.tok)

        if kind == "wall":
            self.word("from"); x0, y0 = self.pair(); self.word("to"); x1, y1 = self.pair()
            o = self.shape_opts(("color", "showIf", "hideIf"))
            self.semi()
            if y0 == y1 and x0 != x1:
                x0, x1 = min(x0, x1), max(x0, x1)
                return [mk(BLOCKS["wall_h"], Loc(x0, y0, None, tok), ((x1 - x0) / 669.2, 1.0), color=o["color"], o=o)]
            if x0 == x1 and y0 != y1:
                y0, y1 = min(y0, y1), max(y0, y1)
                return [mk(BLOCKS["wall_v"], Loc(x0 - 10, y0, None, tok), (1.0, (y1 - y0) / 692.6), color=o["color"], o=o)]
            raise self.err("a wall must be straight: the two points need the same x (up-down) or the same y (left-right)", tok)
        self.word("at")
        loc = self.loc()
        if kind == "box":
            o = self.shape_opts(("size", "color", "front", "showIf", "hideIf"))
            self.semi()
            return [mk(BLOCKS["box"], loc, size=o["size"] or (100.0, 100.0), color=o["color"] or "FFFFFF", front=o["front"] or 0.0, o=o)]
        if kind == "floor":
            o = self.shape_opts(("size", "color", "layer"))
            self.semi()
            return [mk(BLOCKS["floor"], loc, size=o["size"] or (400.0, 400.0), color=o["color"] or "CCCCCC",
                       layer=o["layer"] if o["layer"] is not None else 3)]
        if kind == "label":
            o = self.shape_opts(("color", "scale", "front", "showIf", "hideIf"))
            self.semi()
            return [mk(BLOCKS["text"], loc, o["scale"] or (1.0, 1.0), color=o["color"] or "FFFFFF", text=words,
                       front=o["front"] if o["front"] is not None else 3.0, o=o)]
        # sign: a dark border, a coloured board and the words on it
        o = self.shape_opts(("size", "color", "textColor", "front", "showIf", "hideIf"))
        self.semi()
        wd, ht = o["size"] or (max(160.0, 22.0 * len(words) + 60.0), 56.0)
        fr = o["front"] if o["front"] is not None else 2.0
        return [mk(BLOCKS["box"], loc, size=(wd + 10, ht + 10), color="2B2D42", front=fr, o=o),
                mk(BLOCKS["box"], loc, size=(wd, ht), color=o["color"] or "1D3557", front=fr + 0.5, o=o),
                mk(BLOCKS["text"], moved(loc, 0, -ht * 0.12), (wd / 150 * 0.95, ht / 50 * 0.95), color=o["textColor"] or "FFFFFF",
                   text=words, front=fr + 1, o=o)]

    def mesh(self):
        """mesh Name { color #..; polygon (x,y) (x,y) ...; rect (x,y) (w,h); circle (x,y) r; }   or
        mesh Name from "drawing.svg" [scale 2];   Coordinates are in world units around the mesh's own (0, 0)."""
        tok = self.cur
        self.i += 1
        name = self.ident("a name for the mesh")
        shapes = []
        try:
            if self.at_word("from"):
                self.i += 1
                ftok = self.cur
                fname = self.string("an .svg file name in quotes")
                scale = 1.0
                if self.at_word("scale"):
                    self.i += 1
                    scale = float(self.number())
                self.semi()
                path = fname if os.path.isabs(fname) else os.path.join(os.path.dirname(os.path.abspath(self.path or ".")), fname)
                if not os.path.exists(path):
                    raise self.err(f"can't find {fname} (looked in {os.path.dirname(path)})", ftok)
                shapes = load_svg(path, scale)
            else:
                self.sym("{")
                colour = "FFFFFF"
                while not self.at("sym", "}"):
                    if self.at("eof"):
                        raise self.err("missing '}'")
                    ktok = self.cur
                    kind = self.ident("color, polygon, rect or circle")
                    if kind == "color":
                        colour = self.take("color", what="a colour like #FF8800").value
                        self.semi()
                        continue
                    col = colour
                    if self.at("color"):
                        col = self.take("color").value
                    if kind == "polygon":
                        pts = []
                        while self.at("sym", "("):
                            pts.append(self.pair())
                        if len(pts) < 3:
                            raise self.err("a polygon needs at least 3 points: polygon (0, 0) (50, 0) (25, 40);", ktok)
                        shapes.append((col, pts))
                    elif kind == "rect":
                        (x, y), (w, h) = self.pair(), self.pair()
                        shapes.append((col, mesh_rect(x, y, w, h)))
                    elif kind == "circle":
                        (x, y), r = self.pair(), float(self.number())
                        shapes.append((col, mesh_circle(x, y, r)))
                    else:
                        raise self.err(f"a mesh is made of: color, polygon, rect, circle (not '{kind}')", ktok)
                    if self.at("color"):                        # the colour may also come last
                        shapes[-1] = (self.take("color").value, shapes[-1][1])
                    self.semi()
                self.sym("}")
            return MeshDecl(name, build_parts(shapes), tok)
        except MeshError as e:
            raise self.err(f"mesh {name}: {e}", tok)

    def image(self):
        """image Name from "picture.png" [scale 0.5] [size (w, h)];   1 pixel = 1 world unit unless scaled."""
        tok = self.cur
        self.i += 1
        name = self.ident("a name for the image")
        self.word("from")
        ftok = self.cur
        fname = self.string("a .png file name in quotes")
        scale, size = 1.0, None
        while self.at_word("scale", "size"):
            if self.cur.value == "scale":
                self.i += 1
                scale = float(self.number())
            else:
                self.i += 1
                size = self.pair()
        self.semi()
        path = fname if os.path.isabs(fname) else os.path.join(os.path.dirname(os.path.abspath(self.path or ".")), fname)
        if not os.path.exists(path):
            raise self.err(f"can't find {fname} (looked in {os.path.dirname(path)})", ftok)
        try:
            from PIL import Image
            with Image.open(path) as img:
                pw, ph = img.size
        except Exception as e:
            raise self.err(f"can't read {fname} as a picture ({e})", ftok)
        if size is None:
            size = (pw * scale, ph * scale)
        return ImageDecl(name, path, size, tok)

    def shop(self):
        """shop Name in "Scene" at POS { greeting = "..."; sell Item for 25; ... }  ->  a spot with a buying menu."""
        tok = self.cur
        self.i += 1
        name = self.ident("a name for the shop")
        self.word("in")
        scene = self.string("a scene name")
        self.word("at")
        loc = self.loc()
        self.sym("{")
        text = {"greeting": "What can I get you?", "thanks": "Here you go!", "broke": "You don't have enough coins.",
                "bye": "Come again!"}
        props, goods = {}, []
        while not self.at("sym", "}"):
            if self.at("eof"):
                raise self.err("missing '}'")
            ktok = self.cur
            key = self.ident("sell, greeting, thanks, broke, bye or bubble")
            if key == "sell":
                item = self.string() if self.at("string") else self.ident("an item name")
                self.word("for")
                price = int(self.number())
                label = re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", item)
                if self.at_word("as"):
                    self.i += 1
                    label = self.string("the name shown in the menu")
                self.semi()
                goods.append((item, price, label, ktok))
            elif key in text:
                self.sym("="); text[key] = self.string(); self.semi()
            elif key == "bubble":
                self.sym("="); props[key] = (self.value(), ktok); self.semi()
            else:
                raise self.err(f"a shop can have: sell Item for 25; greeting, thanks, broke, bye = \"...\"; bubble = false; (not '{key}')", ktok)
        self.sym("}")
        if not goods:
            raise self.err(f"shop {name} sells nothing: add  sell ItemName for 25;", tok)

        def page(items):
            opts = []
            for item, price, label, t in items[:3]:
                opts.append((f"{label} ({price})", [If(CCoins(">=", price, t),
                                                       [Act("take_coins", (price,), t), Act("give_item", (item, 1), t), Say(text["thanks"], t)],
                                                       [Say(text["broke"], t)], t)]))
            if len(items) > 3:
                opts.append(("More...", [Choice(page(items[3:]), tok, "There's more:")]))
            else:
                opts.append(("Bye", [Say(text["bye"], tok)]))
            return opts
        return ThingDecl("spot", name, scene, loc, props, [Say(text["greeting"], tok), Choice(page(goods), tok)], tok)

    def loc(self):
        tok = self.cur
        if self.at("sym", "("):
            self.i += 1
            x = self.number(); self.sym(","); y = self.number(); self.sym(")")
            return Loc(float(x), float(y), None, tok)
        if self.at("string"):
            name = self.string()
            dx = dy = 0.0
            if self.at("sym", "+") or self.at("sym", "-"):
                sign = 1 if self.cur.value == "+" else -1
                self.i += 1
                self.sym("("); dx = self.number(); self.sym(","); dy = self.number(); self.sym(")")
                dx, dy = sign * dx, sign * dy
            return Loc(float(dx), float(dy), name, tok)
        raise self.err('expected a position: (x, y) or "Landmark name" + (dx, dy)')

    def value(self):
        tok = self.cur
        if self.at("string"):
            return self.string()
        if self.at("number") or self.at("sym", "-"):
            return self.number()
        if self.at("color"):
            self.i += 1
            return ("color", tok.value)
        if self.at("ident"):
            name = self.ident()
            if name in ("true", "false"):
                return name == "true"
            if self.at("sym", "("):
                self.i += 1
                args = []
                while not self.at("sym", ")"):
                    args.append(self.value())
                    if not self.at("sym", ")"):
                        self.sym(",")
                self.sym(")")
                return ("call", name, args)
            return ("name", name)
        raise self.err("expected a value")

    def props_block(self, allow_dialogue):
        self.sym("{")
        props, dialogue = {}, None
        while not self.at("sym", "}"):
            if self.at("eof"):
                raise self.err("missing '}'")
            if allow_dialogue and self.at_word("dialogue"):
                self.i += 1
                dialogue = self.block()
                continue
            if allow_dialogue and self.at_word("behavior", "behaviour"):
                btok = self.cur
                self.i += 1
                self.vars = {}
                props["__behavior"] = (self.sblock(), btok)
                continue
            key_tok = self.cur
            key = self.ident("a property name")
            if key == "patrol" and self.at("sym", "{"):
                props["patrol"] = (self.route_steps(), key_tok)
                continue
            if self.at("sym", "{"):          # nested block, e.g. look { shirt = #ff0000; }
                sub, _ = self.props_block(False)
                props[key] = sub
                continue
            self.sym("=")
            props[key] = (self.value(), key_tok)
            self.semi()
        self.sym("}")
        return props, dialogue

    # dialogue
    def block(self):
        if not self.at("sym", "{"):
            return _as_list(self.stmt())
        self.sym("{")
        out = []
        while not self.at("sym", "}"):
            if self.at("eof"):
                raise self.err("missing '}'")
            out.extend(_as_list(self.stmt()))
        self.sym("}")
        return out

    def stmt(self):
        tok = self.cur
        if self.field_stmt_ahead():
            return self.field_stmt(tok)
        if self.at("ident") and self.cur.value in getattr(self, "functions", {}) and self.peek().kind == "sym" \
                and self.peek().value == "(":
            return self.inline_function("dialogue")
        if self.at("string"):                      # bare "text"; is shorthand for say
            text = self.string()
            self.semi()
            return Say(text, tok)
        w = self.ident("a dialogue command (say, if, choice, set, give, take, ...)")
        if w == "say":
            if self.at("sym", "("):
                self.i += 1; text = self.string(); self.sym(")")
            else:
                text = self.string()
            self.semi()
            return Say(text, tok)
        if w == "if":
            self.sym("(")
            cond = self.cond()
            self.sym(")")
            then = self.block()
            orelse = []
            if self.at_word("else"):
                self.i += 1
                orelse = self.block()
            return If(cond, then, orelse, tok)
        if w == "choice":
            prompt = self.string() if self.at("string") else None
            self.sym("{")
            opts = []
            while not self.at("sym", "}"):
                text = self.string("an option in quotes")
                self.sym("=>")
                opts.append((text, self.block()))
                if self.at("sym", ",") or self.at("sym", ";"):
                    self.i += 1
            self.sym("}")
            if not opts:
                raise self.err("a choice needs at least one option", tok)
            if len(opts) > 4:
                raise self.err("a choice can have at most 4 options", tok)
            return Choice(opts, tok, prompt)
        if w in ("set", "clear"):
            name = self.ident("a flag name")
            self.semi()
            return Act(w, (name,), tok)
        if w == "give":
            if self.at_word("coins"):
                self.i += 1
                n = ("var", self.ident()) if self.at("ident") else int(self.number())
                self.semi()
                return Act("give_coins", (n,), tok)
            if self.at_word("disguise"):
                self.i += 1; d = self.string("a disguise name"); self.semi()
                return Act("give_disguise", (d,), tok)
            item = self.string() if self.at("string") else self.ident("an item name")
            n = int(self.number()) if self.at("number") else 1; self.semi()
            return Act("give_item", (item, n), tok)
        if w == "take":
            if self.at_word("coins"):
                self.i += 1
                n = ("var", self.ident()) if self.at("ident") else int(self.number())
                self.semi()
                return Act("take_coins", (n,), tok)
            item = self.string() if self.at("string") else self.ident("an item name")
            n = int(self.number()) if self.at("number") else 1; self.semi()
            return Act("take_item", (item, n), tok)
        if w == "input":
            title = self.string("a title for the text box")
            self.sym("->")
            var = self.ident("a variable name")
            self.semi()
            return Act("input", (title, var), tok)
        if w == "end":
            self.semi()
            return End(tok)
        if w == "call":
            return self.call_stmt(tok)
        if w == "play":
            return self.play_stmt(tok)
        if w == "log":
            text = self.string("the text to write to the game's log")
            self.semi()
            return Act("log", (("str", text),), tok)
        if w == "random":
            daily = False
            if self.at_word("daily"):
                self.i += 1
                daily = True
            self.sym("{")
            opts = []
            while not self.at("sym", "}"):
                if self.at("eof"):
                    raise self.err("missing '}'")
                opts.append(self.block() if self.at("sym", "{") else _as_list(self.stmt()))
            self.sym("}")
            if len(opts) < 2:
                raise self.err("random needs at least two options to pick from", tok)
            return RandomBlock(opts, daily, tok)
        if w == "once":
            name = f"once_{tok.line}_{tok.col}"          # a hidden flag: set the first time, so it never runs again
            self.__dict__.setdefault("auto_flags", []).append(FlagDecl(name, tok))
            body = self.block()
            return If(CNot(CFlag(name, tok)), [Act("set", (name,), tok)] + body, [], tok)
        raise self.err(f"unknown dialogue command '{w}'", tok)

    def field_stmt_ahead(self):
        """Is this  Class("obj").field = / ->   or   name.field = / ->  ?"""
        t = lambda k: self.peek(k)                                          # noqa: E731
        if not self.at("ident"):
            return False
        k = 1
        if t(1).kind == "sym" and t(1).value == "(" and t(2).kind == "string" and t(3).kind == "sym" and t(3).value == ")":
            k = 4
        while t(k).kind == "sym" and t(k).value == "." and t(k + 1).kind == "ident":
            k += 2
        return k > 1 and t(k - 2).kind == "sym" and t(k - 2).value == "." and t(k).kind == "sym" and t(k).value in ("=", "->")

    def field_stmt(self, tok):
        parts = [self.ident()]
        objpath = None
        if self.at("sym", "(") and self.peek().kind == "string":
            self.i += 1
            objpath = self.string()
            self.sym(")")
        while self.at("sym", "."):
            self.i += 1
            parts.append(self.ident("a field name"))
        cls, field_ = ".".join(parts[:-1]), parts[-1]
        if self.at("sym", "->"):
            self.i += 1
            out = self.ident("a variable to keep the value in")
            if isinstance(getattr(self, "vars", None), dict):
                self.vars.setdefault(out, None)
            self.semi()
            return Act("getfield", (cls, objpath, field_, out), tok)
        self.sym("=")
        value = self.call_arg()
        self.semi()
        return Act("setfield", (cls, objpath, field_, value), tok)

    def play_stmt(self, tok):
        """play Name [loop];  (a sound of this mod)   /   play asset "sfx_blastOff" [loop];  (one of the game's)"""
        if self.at_word("asset"):
            self.i += 1
            what = ("asset", self.string("the game sound's name in quotes (./ssmod assets AudioAsset)"))
        else:
            what = ("sound", self.ident("a sound declared with  sound Name from \"file.wav\";"))
        loop = False
        if self.at_word("loop"):
            self.i += 1
            loop = True
        self.semi()
        return Act("play", (what[0], what[1], loop), tok)

    def call_stmt(self, tok):
        cls, method, args, objpath = self.call_expr()
        out = None
        if self.at("sym", "->"):
            self.i += 1
            out = self.ident("a variable name to keep the result in")
            if isinstance(getattr(self, "vars", None), dict):
                self.vars.setdefault(out, None)       # a script variable whose type the function decides
        self.semi()
        return Act("call", (cls, method, args, out, objpath), tok)

    def call_expr(self):
        """Name(args), Class.Name(args), thing.Name(args) or Class("object in the scene").Name(args)."""
        parts = [self.ident("a game function name (./ssmod functions lists them)")]
        while self.at("sym", "."):
            self.i += 1
            parts.append(self.ident("a name"))
        objpath = None
        if self.at("sym", "(") and self.peek().kind == "string" and self.peek(2).kind == "sym" \
                and self.peek(2).value == ")" and self.peek(3).kind == "sym" and self.peek(3).value == ".":
            self.i += 1
            objpath = self.string()
            self.sym(")")
            self.sym(".")
            parts.append(self.ident("a function name"))
            cls, name = ".".join(parts[:-1]), parts[-1]
        else:
            cls, name = (".".join(parts[:-1]) or None), parts[-1]
        self.sym("(")
        args = []
        while not self.at("sym", ")"):
            args.append(self.call_arg())
            if self.at("sym", ","):
                self.i += 1
            elif not self.at("sym", ")"):
                raise self.err("expected ',' or ')' between values")
        self.sym(")")
        return cls, name, args, objpath

    def call_arg(self):
        tok = self.cur
        if self.at("number") or self.at("sym", "-"):
            return ("num", self.number(), tok)
        if self.at("color"):
            v = self.cur.value
            self.i += 1
            return ("color", v, tok)
        if self.at("sym", "("):                       # a position: (x, y) or (x, y, z)
            self.i += 1
            xs = [self.number()]
            while self.at("sym", ","):
                self.i += 1
                xs.append(self.number())
            self.sym(")")
            return ("vec", tuple(xs), tok)
        if self.at("string"):
            return ("str", self.string(), tok)
        w = self.ident("a value: a number, \"text\", true/false, an option name, or item/asset/flag/disguise \"Name\"")
        if w in ("true", "false"):
            return ("bool", w == "true", tok)
        if w in ("item", "asset", "flag", "disguise", "object") and (self.at("string") or self.at("ident")):
            return (w, self.string() if self.at("string") else self.ident(), tok)
        return ("ident", w, tok)

    def exit_name(self):
        tok = self.cur
        w = self.ident("an exit: North, South, East, West, NorthAlt, SouthAlt, EastAlt, WestAlt, Main")
        if w not in EXIT_IDS:
            raise self.err(f"unknown exit {w}; use one of {', '.join(EXIT_IDS)}", tok)
        return w

    def route_steps(self):
        """{ (x, y); "Landmark" + (dx, dy); wait 2; speak "text"; }"""
        self.sym("{")
        steps = []
        while not self.at("sym", "}"):
            tok = self.cur
            if self.at_word("wait"):
                self.i += 1
                steps.append(RouteStep("wait", float(self.number()), tok))
            elif self.at_word("speak"):
                self.i += 1
                steps.append(RouteStep("speak", self.string(), tok))
            else:
                steps.append(RouteStep("goto", self.loc(), tok))
            if self.at("sym", ";") or self.at("sym", ","):
                self.i += 1
        self.sym("}")
        if not any(st.kind == "goto" for st in steps):
            raise self.err("a route needs at least one position")
        return steps

    # ---------------- scripts
    def sblock(self):
        if not self.at("sym", "{"):
            return _as_list(self.sstmt())
        self.sym("{")
        out = []
        while not self.at("sym", "}"):
            if self.at("eof"):
                raise self.err("missing '}'")
            out.extend(_as_list(self.sstmt()))
        self.sym("}")
        return out

    def list_literal(self, tok):
        """[1, 2, 3] / ["a", "b"] / [] of text|number|decimal|truefalse  ->  ("list", python type, [values])"""
        self.sym("[")
        vals = []
        while not self.at("sym", "]"):
            vals.append(self.literal())
            if self.at("sym", ","):
                self.i += 1
        self.sym("]")
        kinds = {"text": str, "number": int, "decimal": float, "truefalse": bool}
        if not vals:
            if not self.at_word("of"):
                raise self.err("an empty list needs its kind: [] of text, [] of number or [] of decimal", tok)
            self.i += 1
            k = self.ident("text, number, decimal or truefalse")
            if k not in kinds:
                raise self.err("a list can hold text, number, decimal or truefalse", tok)
            return ("list", kinds[k], [])
        t = type(vals[0])
        if t is int and any(isinstance(v, float) for v in vals):
            t, vals = float, [float(v) for v in vals]
        if any(type(v) is not t for v in vals):
            raise self.err("every item of a list must be the same kind", tok)
        return ("list", t, vals)

    def is_list(self, name):
        v = getattr(self, "vars", {}).get(name)
        return isinstance(v, tuple) and v and v[0] == "list"

    def literal(self):
        if self.at_word("true", "false"):
            v = self.cur.value == "true"
            self.i += 1
            return v
        if self.at("string"):
            return self.string()
        return self.number()

    # script expressions: ("num", v) ("str", s) ("bool", b) ("var", name) ("op", "+", a, b) ("neg", a)
    def expr(self):
        a = self.term()
        while self.at("sym") and self.cur.value in ("+", "-") and not (self.peek().kind == "sym" and self.peek().value == "="):
            op = self.cur.value
            self.i += 1
            a = ("op", op, a, self.term())
        return a

    def term(self):
        a = self.factor()
        while self.at("sym") and self.cur.value in ("*", "/") and not (self.peek().kind == "sym" and self.peek().value == "="):
            op = self.cur.value
            self.i += 1
            a = ("op", op, a, self.factor())
        return a

    def factor(self):
        if self.at("sym", "("):
            self.i += 1
            e = self.expr()
            self.sym(")")
            return e
        if self.at("sym", "-"):
            self.i += 1
            if self.at("number"):
                return ("num", -self.number())
            return ("neg", self.factor())
        if self.at("number"):
            return ("num", self.number())
        if self.at("string"):
            return ("str", self.string())
        if self.at_word("true", "false"):
            v = self.cur.value == "true"
            self.i += 1
            return ("bool", v)
        tok = self.cur
        name = self.ident("a number, \"text\", or a variable")
        if name in ("count", "pick") and self.at("sym", "(") and self.peek().kind == "ident" and self.is_list(self.peek().value):
            self.i += 1
            lst = self.ident()
            self.sym(")")
            return (name, lst, tok)
        if self.is_list(name) and self.at("sym", "["):
            self.i += 1
            idx = self.expr()
            self.sym("]")
            return ("index", name, idx, tok)
        if name in MATH_FUNCS and self.at("sym", "(") and name not in getattr(self, "vars", {}):
            self.i += 1
            args = [self.expr()]
            while self.at("sym", ","):
                self.i += 1
                args.append(self.expr())
            self.sym(")")
            want = MATH_FUNCS[name]
            if len(args) not in want:
                raise self.err(f"{name} takes {' or '.join(map(str, want))} value(s)", tok)
            return ("fn", name, args, tok)
        if name not in getattr(self, "vars", {}):
            raise self.err(f"unknown variable {name} (declare it with  var {name} = 0;)", tok)
        return ("var", name)

    @staticmethod
    def plain(e):
        """An expression that is just a literal -> its python value (the old, simple form); else the expression."""
        return e[1] if e[0] in ("num", "str", "bool") else e

    def sstmt(self):
        tok = self.cur
        if self.at("ident") and self.is_list(self.cur.value) and self.peek().kind == "sym" and self.peek().value == "[":
            lst = self.ident()                                     # names[i] = x;
            self.sym("[")
            idx = self.expr()
            self.sym("]")
            self.sym("=")
            val = self.expr()
            self.semi()
            return ListCmd("set", lst, (idx, val), tok)
        if self.field_stmt_ahead():
            return self.field_stmt(tok)
        if self.at("ident") and self.cur.value in getattr(self, "functions", {}) and self.peek().kind == "sym" \
                and self.peek().value == "(":
            return self.inline_function("script")
        if self.at_word("parallel") and self.peek().kind == "sym" and self.peek().value == "{":
            self.i += 1
            self.sym("{")
            branches = []
            while not self.at("sym", "}"):
                if self.at("eof"):
                    raise self.err("missing '}'")
                branches.append(self.sblock())
            self.sym("}")
            if len(branches) < 2:
                raise self.err("parallel needs at least two { } branches", tok)
            return Parallel(branches, tok)
        if self.at("ident") and self.peek().kind == "sym" and self.peek().value in ("=", "+", "-", "*", "/") \
                and self.cur.value in getattr(self, "vars", {}):
            name = self.ident()
            op = self.cur.value
            self.i += 1
            if op == "=":
                value = self.plain(self.expr())
            elif op in "+-" and self.at("sym", op):          # x++ / x--
                self.i += 1
                value, op = 1, op + "="
            else:
                self.sym("=")
                value, op = self.plain(self.expr()), op + "="
            self.semi()
            kind = type(self.vars[name])
            if op != "=" and kind is bool:
                raise self.err(f"can't do {op} on a true/false variable", tok)
            if op != "=" and kind is str and op != "+=":
                raise self.err(f"text can only be joined with + or +=, not {op}", tok)
            return Assign(name, op, value, tok)
        if self.at_word("player") and self.peek().kind == "sym" and self.peek().value == ".":
            self.i += 2
            what = self.ident("move or scale")
            self.sym("(")
            args = [float(self.number())]
            while self.at("sym", ","):
                self.i += 1
                args.append(float(self.number()))
            self.sym(")")
            self.semi()
            if what == "move" and len(args) == 2:
                return EngineCall("move", tuple(args), tok)
            if what == "scale" and len(args) == 1:
                return EngineCall("scale", tuple(args), tok)
            raise self.err("use player.move(x, y) or player.scale(size)", tok)
        w = self.ident("a script command (var, wait, waitUntil, if, while, forever, speak, set, give, walk, ...)")
        if w == "add":
            e = self.expr()
            self.word("to")
            lst = self.ident("a list")
            if not self.is_list(lst):
                raise self.err(f"{lst} isn't a list (declare one with  var {lst} = [];  of a kind)", tok)
            self.semi()
            return ListCmd("add", lst, (e,), tok)
        if w == "remove":
            e = self.expr()
            self.word("from")
            lst = self.ident("a list")
            if not self.is_list(lst):
                raise self.err(f"{lst} isn't a list", tok)
            self.semi()
            return ListCmd("remove", lst, (e,), tok)
        if w == "clear" and self.at("ident") and self.is_list(self.cur.value):
            lst = self.ident()
            self.semi()
            return ListCmd("clear", lst, (), tok)
        if w == "play":
            return self.play_stmt(tok)
        if w == "log":
            e = self.expr()
            self.semi()
            return Act("log", (e,), tok)
        if w in ("walk", "run", "jog", "sneak"):
            mode = {"walk": "Walk", "run": "Run", "jog": "Jog", "sneak": "Sneak"}[w]
            if self.at_word("by"):
                self.i += 1
                dx, dy = self.pair()
                self.semi()
                return ActorCmd("goto", {"mode": mode, "delta": (dx, dy)}, tok)
            self.word("to")
            a = {"mode": mode, "within": 20.0}
            if self.at("sym", "("):
                a["pos"] = self.pair()
            elif self.at_word("player"):
                self.i += 1
                a["player"] = True
            elif self.at("ident"):                    # a position kept in a variable (a Vector2)
                a["var"] = self.ident("a position variable")
            else:
                a["object"] = self.string("a position (x, y), player, a position variable, or an object's name in quotes")
            if self.at_word("within"):
                self.i += 1
                a["within"] = float(self.number())
            if self.at_word("nowait"):                # start walking and go on with the script (for following)
                self.i += 1
                a["nowait"] = True
            self.semi()
            return ActorCmd("goto", a, tok)
        if w == "wander":
            if self.at_word("within"):
                self.i += 1
            r = float(self.number())
            mode = "Walk"
            if self.at_word("walking", "running", "jogging", "sneaking"):
                mode = {"walking": "Walk", "running": "Run", "jogging": "Jog", "sneaking": "Sneak"}[self.cur.value]
                self.i += 1
            self.semi()
            return ActorCmd("wander", {"radius": r, "mode": mode}, tok)
        if w == "face":
            a = {}
            if self.at_word("player"):
                self.i += 1
                a["player"] = True
            elif self.at("string"):
                a["object"] = self.string()
            else:
                d = self.ident("player, an object name in quotes, or a direction: Up, Down, Left, Right, UpLeft, ...")
                if d not in ("Right", "UpRight", "Up", "UpLeft", "Left", "DownLeft", "Down", "DownRight"):
                    raise self.err("face takes player, \"Object\", or Up, Down, Left, Right, UpLeft, UpRight, DownLeft, DownRight", tok)
                a["dir"] = d
            self.semi()
            return ActorCmd("face", a, tok)
        if w == "look":
            if self.at_word("away"):
                self.i += 1
                self.semi()
                return ActorCmd("look", {}, tok)
            self.word("at")
            self.word("player")
            self.semi()
            return ActorCmd("look", {"player": True}, tok)
        if w == "sit":
            secs = 0.0
            if self.at_word("for"):
                self.i += 1
                secs = float(self.number())
            self.semi()
            return ActorCmd("sit", {"seconds": secs}, tok)
        if w in ("suspicious", "leave"):
            self.semi()
            return ActorCmd(w, {}, tok)
        if w == "alert":
            crime = "Called911"
            if self.at("ident"):
                crime = self.ident()
            self.semi()
            return ActorCmd("alert", {"crime": crime}, tok)
        if w == "var":
            name = self.ident("a variable name")
            self.sym("=")
            if self.at("sym", "["):
                value = self.list_literal(tok)
                self.semi()
                if name in self.vars:
                    raise self.err(f"variable {name} is declared twice", tok)
                self.vars[name] = value
                return VarDecl(name, value, tok)
            value = self.literal()
            self.semi()
            if name in self.vars:
                raise self.err(f"variable {name} is declared twice", tok)
            self.vars[name] = value
            return VarDecl(name, value, tok)
        if w == "wait":
            if self.at_word("random"):
                self.i += 1
                lo = float(self.number())
                self.word("to")
                hi = float(self.number())
                self.semi()
                return ActorCmd("waitrandom", {"min": min(lo, hi), "max": max(lo, hi)}, tok)
            n = float(self.number())
            self.semi()
            return Wait(n, tok)
        if w == "waitUntil":
            self.sym("(")
            c = self.scond()
            self.sym(")")
            self.semi()
            return WaitUntil(c, tok)
        if w == "if":
            self.sym("(")
            c = self.scond()
            self.sym(")")
            then = self.sblock()
            orelse = []
            if self.at_word("else"):
                self.i += 1
                orelse = self.sblock()
            return If(c, then, orelse, tok)
        if w == "while":
            self.sym("(")
            if self.at_word("true") and self.peek().kind == "sym" and self.peek().value == ")":
                self.i += 1
                c = None
            else:
                c = self.scond()
            self.sym(")")
            return While(c, self.sblock(), tok)
        if w == "forever":
            return While(None, self.sblock(), tok)
        if w == "speak":
            text = self.string()
            self.semi()
            return Speak(text, tok)
        if w == "timescale":
            n = float(self.number())
            self.semi()
            if not 0.05 <= n <= 4:
                raise self.err("timescale must be between 0.05 and 4 (1 = normal speed)", tok)
            return EngineCall("timescale", (n,), tok)
        if w == "weather":
            kind = self.ident("Clear, Rainy, Snowy or SnowyHeavy")
            if kind not in ("Clear", "Rainy", "Snowy", "SnowyHeavy"):
                raise self.err("weather must be Clear, Rainy, Snowy or SnowyHeavy", tok)
            self.semi()
            return Weather(kind, tok)
        if w in ("set", "clear", "give", "take"):
            self.i -= 1
            return self.stmt()
        if w == "call":
            return self.call_stmt(tok)
        if w == "patrol":
            who = self.string() if self.at("string") else self.ident("an npc or object name")
            self.word("with")
            route = self.string() if self.at("string") else self.ident("a route name")
            self.semi()
            return PatrolCmd(who, route, tok)
        raise self.err(f"unknown script command '{w}'", tok)

    def scond(self):
        a = self.scand()
        while self.at("sym", "||"):
            self.i += 1
            a = COr(a, self.scand())
        return a

    def scand(self):
        a = self.scnot()
        while self.at("sym", "&&"):
            self.i += 1
            a = CAnd(a, self.scnot())
        return a

    def scnot(self):
        if self.at("sym", "!"):
            self.i += 1
            return CNot(self.scnot())
        if self.at("sym", "("):
            self.i += 1
            c = self.scond()
            self.sym(")")
            return c
        tok = self.cur
        if self.at_word("key"):
            self.i += 1
            self.sym("(")
            k = self.string('a key name like "1", "w", "space", "left shift", "up"')
            self.sym(")")
            return CKey(k.lower(), tok)
        if self.at_word("near"):
            self.i += 1
            self.sym("(")
            target = self.string("an object or npc name in quotes") if self.at("string") else self.ident("an npc name")
            dist = 120.0
            if self.at("sym", ","):
                self.i += 1
                dist = float(self.number())
            self.sym(")")
            return CNear(target, dist, tok)
        if self.at("ident") and self.is_list(self.cur.value) and self.peek().kind == "ident" and self.peek().value == "contains":
            lst = self.ident()
            self.i += 1
            return CListHas(lst, self.expr(), tok)
        if self.at("ident") and self.cur.value in getattr(self, "vars", {}):
            name = self.ident()
            if self.at("sym") and self.cur.value in ("==", "!=", ">", "<", ">=", "<="):
                op = self.cur.value
                self.i += 1
                if self.at("ident") and self.cur.value in self.vars:
                    return CVar(name, op, ("var", self.ident()), tok)
                return CVar(name, op, self.literal(), tok)
            if self.vars[name] is not None and not isinstance(self.vars[name], bool):
                raise self.err(f"compare {name} with something, e.g. {name} > 0", tok)
            return CVar(name, "bool", True, tok)
        return self.cprimary()

    def cond(self):
        a = self.cand()
        while self.at("sym", "||"):
            self.i += 1
            a = COr(a, self.cand())
        return a

    def cand(self):
        a = self.cnot()
        while self.at("sym", "&&"):
            self.i += 1
            a = CAnd(a, self.cnot())
        return a

    def cnot(self):
        if self.at("sym", "!"):
            self.i += 1
            return CNot(self.cnot())
        return self.cprimary()

    def cprimary(self):
        tok = self.cur
        if self.at("sym", "("):
            self.i += 1
            c = self.cond()
            self.sym(")")
            return c
        w = self.ident("a condition (a flag, has(Item), coins >= N)")
        if w == "has":
            if self.at("sym", "("):
                self.i += 1
                item = self.string() if self.at("string") else self.ident("an item name")
                n = 1
                if self.at("sym", ","):
                    self.i += 1; n = int(self.number())
                self.sym(")")
                return CHas(item, n, tok)
            item = self.ident("an item name")
            n = 1
            if self.at("sym", ">="):
                self.i += 1; n = int(self.number())
            return CHas(item, n, tok)
        if w == "event":
            parts = [self.ident("player, a variable, or Class(\"object\")")]
            objpath = None
            if self.at("sym", "(") and self.peek().kind == "string":
                self.i += 1
                objpath = self.string()
                self.sym(")")
            while self.at("sym", "."):
                self.i += 1
                parts.append(self.ident("an event name"))
            if len(parts) < 2:
                raise self.err("write event player.OnVehicleChange (or Class(\"object\").EventName)", tok)
            return CEvent(".".join(parts[:-1]), objpath, parts[-1], tok)
        if w == "chance":
            self.sym("(")
            pct = float(self.number())
            self.sym(")")
            if not 0 <= pct <= 100:
                raise self.err("chance takes a percentage from 0 to 100", tok)
            return CChance(pct, tok)
        if w == "hour" and self.cur.kind == "sym" and self.cur.value in (">=", "<=", ">", "<", "=="):
            op = self.cur.value
            self.i += 1
            return CHour(op, float(self.number()), tok)
        if w == "weather" and self.cur.kind == "sym" and self.cur.value in ("==", "!="):
            op = self.cur.value
            self.i += 1
            return CWeather(op, self.ident("a weather: Clear, Rainy, Snowy or SnowyHeavy"), tok)
        if w == "call":
            cls, method, args, objpath = self.call_expr()
            op = value = None
            if self.cur.kind == "sym" and self.cur.value in (">=", "<=", ">", "<", "==", "!="):
                op = self.cur.value
                self.i += 1
                k, v, _ = self.call_arg()
                value = (k, v)
            return CCall(cls, method, args, op, value, tok, objpath)
        if w == "coins":
            op = self.cur
            if not (op.kind == "sym" and op.value in (">=", "<=", ">", "<", "==")):
                raise self.err("expected >=, <=, >, < or == after coins")
            self.i += 1
            return CCoins(op.value, int(self.number()), tok)
        return CFlag(w, tok)


MATH_FUNCS = {"abs": (1,), "min": (2,), "max": (2,), "clamp": (3,), "round": (1,), "floor": (1,), "ceil": (1,),
              "sqrt": (1,), "pow": (2,), "random": (2,)}


def _as_list(x):
    return x if isinstance(x, list) else [x]


def parse_file(path):
    with open(path, encoding="utf-8") as fh:
        src = fh.read()
    if path.lower().endswith(".cs"):              # a mod written in C#: translated, line for line, into SSMod's language
        from .csharp import translate
        src = translate(src, path)
    return Parser(lex(src, path), path).parse()

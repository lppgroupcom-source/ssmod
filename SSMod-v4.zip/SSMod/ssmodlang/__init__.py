"""SSMod: the .ssmod language for Sneaky Sasquatch 2.1.9 (Hidden Content copy)."""

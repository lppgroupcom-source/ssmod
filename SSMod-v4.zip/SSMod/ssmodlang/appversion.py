"""Read / change the version the game reports (PlayerSettings.bundleVersion in globalgamemanagers).

The game compares this with the "mcv" (minimum compatible version) written into the save by whichever
build last touched it; if the save asks for a newer build, the duck appears and asks you to update.
Only the PlayerSettings object is re-serialized - every other object in globalgamemanagers is written
back byte for byte, the same way ssmod edits BuildSettings.
"""
import os

import UnityPy


def _ggm(data_dir):
    path = os.path.join(data_dir, "globalgamemanagers")
    env = UnityPy.load(path)
    f = [x for _, x in env.files.items()][0]
    ps = next((o for o in f.objects.values() if o.type.name == "PlayerSettings"), None)
    if ps is None:
        raise RuntimeError("no PlayerSettings in globalgamemanagers")
    return path, env, f, ps


def read_version(data_dir):
    _, _, _, ps = _ggm(data_dir)
    return ps.read_typetree()["bundleVersion"]


def set_version(data_dir, version):
    """Set the reported version. Returns the version it replaced, or None if it was already that."""
    path, env, f, ps = _ggm(data_dir)
    t = ps.read_typetree()
    old = t["bundleVersion"]
    if old == version:
        return None
    raws = {pid: o.get_raw_data() for pid, o in f.objects.items()}
    t["bundleVersion"] = version
    ps.save_typetree(t)
    for pid, o in f.objects.items():                 # keep every other object exactly as it was
        if o is not ps:
            o.set_raw_data(raws[pid])
    data = env.file.save()
    with open(path, "wb") as fh:
        fh.write(data)
    return old

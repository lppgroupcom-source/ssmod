"""Compile a .ssmod `script { ... }` into a NodeCanvas BehaviourTree (version 2.9 JSON).

Mapping (all node and task types exist in the game's build and the game itself uses BehaviourTrees):
  block            Sequencer (children in order)
  if / else        BinarySelector(condition) -> [then, else]
  while (c)        Inverter -> Repeater(until Failure) -> Sequencer[ConditionNode(c), body...]
  forever          Repeater(forever) -> Sequencer[body...]
  waitUntil (c)    Repeater(until Success) -> Sequencer[Wait 0.2, ConditionNode(c)]
  wait N           Wait
  x += 1 ...       SetInt / SetFloat / SetBoolean on the owner's Blackboard
  near("X", d)     CheckDistanceToGameObject, agent = Globals/player
  speak "..."      ActorSpeak on the script's speaker npc (a chat bubble)
  weather Rainy    NodeCanvasBridge.Misc_SetWeather(WeatherData, false)
  flags / coins / items   the same tasks the dialogues use
Conditions become one ConditionTask: && / || are ConditionLists (AllTrueRequired / AnyTrueSuffice), ! is _invert.
"""
import copy
import json
import uuid

from .syntax import (Say, Act, If, End, CFlag, CHas, CCoins, CCall, CNot, CAnd, COr, SSModError,
                     VarDecl, Assign, Wait, WaitUntil, While, Speak, Weather, CVar, CNear, EngineCall, CKey, PatrolCmd, CallCmd,
                     ActorCmd, CChance, CHour, CWeather, Parallel, CEvent, ListCmd, CListHas)
from .dialogue import COMPARE, DialogueCompiler, extra_condition
from . import calls

PLAYER = {"_name": "Globals/player", "_targetVariableID": "d897c914-acde-411a-9396-d2fbe91aa53c"}
VAR_TYPES = {int: "System.Int32", float: "System.Single", bool: "System.Boolean", str: "System.String"}
STRING_SET = "NodeCanvas.Tasks.Actions.SetVariable`1[[System.String, mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]"
PY_TYPES = {v: k for k, v in VAR_TYPES.items()}
OPS = {"=": "Set", "+=": "Add", "-=": "Subtract", "*=": "Multiply", "/=": "Divide"}
SCRIPT_COMPARE = dict(COMPARE, **{"!=": "EqualTo"})


MSCORLIB = "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"


def list_of(t):
    """The assembly-qualified List<T> for a list of python type t."""
    return f"System.Collections.Generic.List`1[[{VAR_TYPES[t]}, {MSCORLIB}]], {MSCORLIB}"


def generic(task, t):
    return f"NodeCanvas.Tasks.{task}`1[[{VAR_TYPES[t]}, {MSCORLIB}]]"


def var_type(t):
    """t: a python type (var x = 5;), a C# type name (call ... -> x), or ("list", python type)."""
    if isinstance(t, tuple) and t[0] == "list":
        return f"NodeCanvas.Framework.Variable`1[[{list_of(t[1])}]]"
    return calls.variable_type(VAR_TYPES[t] if t in VAR_TYPES else t)


class ScriptCompiler:
    """resolve(kind, name, tok) -> (file_id, path_id); kinds as for dialogues plus
    'object' (a GameObject in the scene), 'actor' (the speaker's GameActor), 'weather'."""

    def __init__(self, resolve, path=None, has_agent=False):
        self.resolve, self.path, self.has_agent = resolve, path, has_agent
        self.nodes, self.conns = [], []
        self.refs, self.ref_index = [{"m_FileID": 0, "m_PathID": 0}], {}
        self.vars = {}            # name -> (python type, id, initial)
        self.n = 0
        # reuse the dialogue compiler's task builders for flags / items / coins
        self.dc = DialogueCompiler(self._dc_resolve, path)

    def _dc_resolve(self, kind, name, tok):
        return self.resolve(kind, name, tok)

    # ---- the context calls.py needs
    def var(self, name):
        if name not in self.vars:
            return None
        t = self.vars[name][0]
        return (VAR_TYPES.get(t, t), {"_name": name, "_targetVariableID": self.vars[name][1]})

    def declare(self, name, t, tok):
        py = PY_TYPES.get(t, t)
        if name in self.vars and self.vars[name][0] is not None and self.vars[name][0] != py:
            raise SSModError(f"'{name}' already holds a {calls.friendly(VAR_TYPES.get(self.vars[name][0], self.vars[name][0]))}, "
                             f"not a {calls.friendly(t)}", tok, self.path)
        if name not in self.vars or self.vars[name][0] is None:
            self.vars[name] = (py, self.vars.get(name, (None, str(uuid.uuid4())))[1], None)
        return {"_name": name, "_targetVariableID": self.vars[name][1]}

    def object_param(self, t, objpath, tok):
        return {"_type": t, "_value": {"$content": self.ref("component", (t, objpath), tok), "$type": t}}

    def object_agent(self, t, objpath, tok):
        return {"_value": self.ref("component", (t, objpath), tok)}

    def ref(self, kind, name, tok):
        key = (kind, name)
        if key not in self.ref_index:
            fid, pid = self.resolve(kind, name, tok)
            self.refs.append({"m_FileID": fid, "m_PathID": pid})
            self.ref_index[key] = len(self.refs) - 1
        return self.ref_index[key]

    def node(self, t, **kw):
        self.n += 1
        d = dict(kw)
        d["$type"] = "NodeCanvas.BehaviourTrees." + t
        d["$id"] = str(self.n)
        self.nodes.append(d)
        return d["$id"]

    def link(self, a, b):
        self.conns.append({"_sourceNode": {"$ref": a}, "_targetNode": {"$ref": b},
                           "$type": "NodeCanvas.BehaviourTrees.BTConnection"})

    def seq(self, children):
        nid = self.node("Sequencer", dynamic=False, random=False)
        for c in children:
            self.link(nid, c)
        return nid

    def action(self, task):
        return self.node("ActionNode", _action=task)

    # ---- statements
    def block(self, stmts):
        kids = [k for k in (self.stmt(s) for s in stmts) if k]
        return self.seq(kids)

    def stmt(self, s):
        if isinstance(s, VarDecl):
            return None                                   # declared on the blackboard
        if isinstance(s, Assign):
            steps = self.assign(s)
            return self.action(steps) if isinstance(steps, dict) else self.seq([self.action(x) for x in steps])
        if isinstance(s, Wait):
            return self.action({"waitTime": {"_value": float(s.seconds)}, "finishStatus": "Success",
                                "$type": "NodeCanvas.Tasks.Actions.Wait"})
        if isinstance(s, WaitUntil) and self.has_event(s.cond):    # events last one frame: check every frame
            rep = self.node("Repeater", repeaterMode="RepeatUntil", repeatTimes={"_value": 1}, repeatUntilStatus="Success")
            self.link(rep, self.node("ConditionNode", _condition=self.cond(s.cond)))
            return rep
        if isinstance(s, WaitUntil):
            rep = self.node("Repeater", repeaterMode="RepeatUntil", repeatTimes={"_value": 1}, repeatUntilStatus="Success")
            body = self.seq([self.action({"waitTime": {"_value": 0.2}, "finishStatus": "Success",
                                          "$type": "NodeCanvas.Tasks.Actions.Wait"}),
                             self.node("ConditionNode", _condition=self.cond(s.cond))])
            self.link(rep, body)
            return rep
        if isinstance(s, If):
            sel = self.node("BinarySelector", dynamic=False, _condition=self.cond(s.cond))
            self.link(sel, self.block(s.then))
            self.link(sel, self.block(s.orelse))
            return sel
        if isinstance(s, While):
            if s.cond is None:
                rep = self.node("Repeater", repeaterMode="RepeatForever", repeatTimes={"_value": 1}, repeatUntilStatus="Success")
                self.link(rep, self.block(s.body))
                return rep
            inv = self.node("Inverter")
            rep = self.node("Repeater", repeaterMode="RepeatUntil", repeatTimes={"_value": 1}, repeatUntilStatus="Failure")
            body = [self.node("ConditionNode", _condition=self.cond(s.cond))] + [k for k in (self.stmt(x) for x in s.body) if k]
            self.link(inv, rep)
            self.link(rep, self.seq(body))
            return inv
        if isinstance(s, Speak):
            return self.action({"speech": s.text, "locKey": "", "waitUntilComplete": False,
                                "overrideAgent": {"_value": self.ref("actor", "speaker", s.tok)}, "$type": "ActorSpeak"})
        if isinstance(s, Weather):
            ref = self.ref("weather", s.kind, s.tok)
            return self.action({"method": {"_baseInfo": "NodeCanvasBridge|Misc_SetWeather|System.Void",
                                           "_paramsInfo": "WeatherData|System.Boolean"},
                                "parameters": [{"_type": "WeatherData", "_value": {"$content": ref, "$type": "WeatherData"}},
                                               {"_type": "System.Boolean", "_value": {"$content": False, "$type": "System.Boolean"}}],
                                "parameterIsByRef": [False, False], "returnValue": {},
                                "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"})
        if isinstance(s, EngineCall):
            return self.action(self.engine(s))
        if isinstance(s, ActorCmd):
            return self.action(self.actor_task(s))
        if isinstance(s, ListCmd):
            return self.list_cmd(s)
        if isinstance(s, Parallel):            # every branch runs at the same time; done when all are done
            nid = self.node("Parallel", policy="FirstFailure", dynamic=False)
            for b in s.branches:
                self.link(nid, self.block(b))
            return nid
        if isinstance(s, Act) and s.kind == "log":
            steps = []
            e = ("op", "+", ("str", calls.log_prefix(self.path, "script")), s.args[0])
            v = self.str_value(e, steps, s.tok)
            v = dict(v, _type="System.Object")
            if "_value" in v:
                v["_value"] = {"$content": v["_value"]["$content"], "$type": "System.String"}
            steps.append(calls.log_task(None, v))
            return self.seq([self.action(x) for x in steps]) if len(steps) > 1 else self.action(steps[0])
        if isinstance(s, Act) and s.kind in ("setfield", "getfield"):
            cls, objpath, fld, x = s.args
            if s.kind == "setfield":
                return self.action(calls.field_task(self, cls, objpath, fld, x, None, s.tok, self.path))
            return self.action(calls.field_task(self, cls, objpath, fld, None, x, s.tok, self.path))
        if isinstance(s, Act) and s.kind == "call":
            cls, method, args, out, objpath = s.args
            return self.action(calls.call_task(self, cls, method, args, out, objpath, s.tok, self.path))
        if isinstance(s, PatrolCmd):
            return self.action({"patrolRoute": self.ref("route", s.route, s.tok), "patrolRouteParam": {},
                                "setNewOwner": False, "newOwner": {}, "waitUntilComplete": False, "$type": "StartPatrolRoute"})
        if isinstance(s, Act) and s.kind in ("give_coins", "take_coins") and isinstance(s.args[0], tuple):
            name = s.args[0][1]
            if name not in self.vars or self.vars[name][0] is not int:
                raise SSModError(f"'{name}' must be a whole-number variable", s.tok, self.path)
            return self.action({"quantity": self.varref(name, s.tok),
                                "$type": "GiveCoins" if s.kind == "give_coins" else "TakeCoins"})
        if isinstance(s, Act):
            self.dc.refs, self.dc.ref_index = self.refs, self.ref_index    # share one reference table
            return self.action(self.dc.action(s))
        raise SSModError(f"{type(s).__name__} can't be used in a script", getattr(s, "tok", None), self.path)

    # ---- npc behaviour: the game's own actor tasks, run by the script's npc (its agent)
    PLAYER_T = "_playerTransform"           # the player's Transform, fetched once at the start when needed

    def need_actor(self, tok):
        if not self.has_agent:
            raise SSModError("this needs an npc to do it: put it in the npc's behavior { } block, or write "
                             "script Name in \"Scene\" by NpcName { ... }", tok, self.path)

    def transform_ref(self, a, tok):
        if a.get("player"):
            return {"_name": self.PLAYER_T, "_targetVariableID": self.vars[self.PLAYER_T][1]}
        return {"_value": self.ref("component", ("UnityEngine.Transform", a["object"]), tok)}

    def actor_task(self, s):
        a, k = s.args, s.kind
        if k == "waitrandom":
            return {"minWait": a["min"], "maxWait": a["max"], "finishStatus": "Success",
                    "$type": "NodeCanvas.Tasks.Actions.WaitRandom"}
        self.need_actor(s.tok)
        if k == "goto":
            t = {"position": {}, "targetTransform": {}, "proximity": {"_value": a.get("within", 20.0)},
                 "movementMode": a["mode"], "waitForComplete": True, "usePathfinder": True, "$type": "ActorGotoPosition"}
            if "delta" in a:
                t["position"] = {"_value": {"x": float(a["delta"][0]), "y": float(a["delta"][1])}}
                t["deltaPosition"] = True
            elif "pos" in a:
                t["position"] = {"_value": {"x": float(a["pos"][0]), "y": float(a["pos"][1])}}
            else:
                t["targetTransform"] = self.transform_ref(a, s.tok)
            return t
        if k == "wander":
            r = a["radius"]
            return {"position": {}, "targetTransform": {}, "proximity": {"_value": 20.0}, "movementMode": a["mode"],
                    "waitForComplete": True, "usePathfinder": True, "minRadius": r * 0.3, "maxRadius": r,
                    "$type": "ActorGotoPositionRandom"}
        if k == "face":
            if "dir" in a:
                return {"lookDir": {"_value": a["dir"]}, "minimumDuration": {}, "$type": "ActorFaceLookDir"}
            return {"targetTransform": self.transform_ref(a, s.tok), "minimumDuration": {}, "$type": "ActorFaceTarget"}
        if k == "look":
            target = dict(calls.PLAYER_REF) if a.get("player") else {}
            return {"targetActor": target, "targetTransform": {}, "ignoreScaler": True, "$type": "ActorSetLookTarget"}
        if k == "sit":
            return {"customActor": {}, "chair": {}, "autoDetectNearbyChair": True, "autoDetectRadius": 300.0,
                    "sitDuration": a["seconds"], "sitDurationRandom": 0.0, "waitForComplete": a["seconds"] > 0,
                    "standOnStop": True, "$type": "ActorSit"}
        if k == "suspicious":
            return {"max": True, "$type": "ActorSetSuspicion"}
        if k == "alert":
            calls.constant("CrimeType", ("ident", a["crime"]), s.tok, self.path)     # checks the name
            return {"crimeType": a["crime"], "whichPlayer": {}, "$type": "ActorCallRanger"}
        if k == "leave":
            return {"waitForComplete": True, "$type": "ActorExitMap"}
        raise SSModError(f"internal: actor command {k}", s.tok, self.path)

    # ---- Unity engine calls through reflection (ExecuteFunction_Multiplatform)
    @staticmethod
    def prim(t, v):
        return {"_type": t, "_value": {"$content": v, "$type": t}}

    def engine(self, s):
        if s.kind == "move":        # Transform.Translate(x, y, 0) on the player
            x, y = s.args
            return {"method": {"_baseInfo": "UnityEngine.Transform|Translate|System.Void",
                               "_paramsInfo": "System.Single|System.Single|System.Single"},
                    "parameters": [self.prim("System.Single", x), self.prim("System.Single", y), self.prim("System.Single", 0.0)],
                    "parameterIsByRef": [False, False, False], "returnValue": {}, "overrideAgent": dict(PLAYER),
                    "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"}
        if s.kind == "scale":       # Transform.localScale = (s, s, 1) on the player
            k = s.args[0]
            return {"method": {"_baseInfo": "UnityEngine.Transform|set_localScale|System.Void",
                               "_paramsInfo": "UnityEngine.Vector3"},
                    "parameters": [{"_type": "UnityEngine.Vector3", "_value": {"x": k, "y": k, "z": 1.0, "$type": "UnityEngine.Vector3"}}],
                    "parameterIsByRef": [False], "returnValue": {}, "overrideAgent": dict(PLAYER),
                    "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"}
        if s.kind == "timescale":   # static Time.timeScale = n
            return {"method": {"_baseInfo": "UnityEngine.Time|set_timeScale|System.Void", "_paramsInfo": "System.Single"},
                    "parameters": [self.prim("System.Single", s.args[0])], "parameterIsByRef": [False], "returnValue": {},
                    "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"}
        raise SSModError(f"internal: engine call {s.kind}")

    def varref(self, name, tok):
        if name not in self.vars:
            raise SSModError(f"unknown variable {name}", tok, self.path)
        if self.vars[name][0] not in VAR_TYPES:
            raise SSModError(f"'{name}' holds a {calls.friendly(self.vars[name][0])}; only numbers and true/false can be "
                             f"changed or compared", tok, self.path)
        return {"_name": name, "_targetVariableID": self.vars[name][1]}

    # ---- expressions: each operation is one of the game's tasks on a hidden temporary variable
    def temp(self, t):
        self.__dict__.setdefault("_ntemp", 0)
        self._ntemp += 1
        name = f"_t{self._ntemp}"
        self.vars[name] = (t, str(uuid.uuid4()), None)
        return name

    def num_value(self, e, t, steps, tok):
        """A number expression -> a valueB dict, adding the steps that compute it."""
        kind = e[0]
        if kind == "num":
            if t is int and float(e[1]) != int(e[1]):
                raise SSModError("a whole-number variable can't hold a decimal", tok, self.path)
            return {"_value": int(e[1]) if t is int else float(e[1])}
        if kind == "var":
            vt = self.vars[e[1]][0]
            if vt is not t:
                raise SSModError(f"'{e[1]}' is a {calls.friendly(VAR_TYPES.get(vt, str(vt)))}, but this needs a "
                                 f"{calls.friendly(VAR_TYPES[t])} (mixing whole numbers and decimals isn't supported)", tok, self.path)
            return self.varref(e[1], tok)
        if kind in ("op", "neg"):
            tmp = self.temp(t)
            ref = {"_name": tmp, "_targetVariableID": self.vars[tmp][1]}
            first, rest = (e[2], [(e[1], e[3])]) if kind == "op" else (("num", 0), [("-", e[1])])
            steps.append(self.arith(ref, "Set", self.num_value(first, t, steps, tok), t))
            for op, b in rest:
                steps.append(self.arith(ref, {"+": "Add", "-": "Subtract", "*": "Multiply", "/": "Divide"}[op],
                                        self.num_value(b, t, steps, tok), t))
            return dict(ref)
        if kind == "fn":
            return self.math_fn(e, t, steps, tok)
        if kind in ("count", "pick", "index"):
            return self.list_value(e, t, steps, tok)
        raise SSModError("text and true/false can't be used in a calculation", tok, self.path)

    def math_fn(self, e, t, steps, tok):
        """abs/min/max/clamp/round/floor/ceil/sqrt/pow/random: Unity's Mathf and Random, into a temporary."""
        _, name, args, ftok = e
        I, F = "System.Int32", "System.Single"
        T = VAR_TYPES[t]
        if name in ("abs", "min", "max", "clamp"):
            cls, meth, ptypes, ret = "UnityEngine.Mathf", name.capitalize(), [T] * len(args), T
        elif name in ("round", "floor", "ceil"):
            cls, ptypes = "UnityEngine.Mathf", [F]
            meth, ret = ({"round": "RoundToInt", "floor": "FloorToInt", "ceil": "CeilToInt"}[name], I) if t is int else \
                (name.capitalize(), F)
        elif name in ("sqrt", "pow"):
            cls, meth, ptypes, ret = "UnityEngine.Mathf", name.capitalize(), [F] * len(args), F
        else:                                              # random(a, b): both ends included
            cls, meth, ptypes, ret = "UnityEngine.Random", "Range", [T, T], T
            if t is int:                                   # Random.Range(int, int) leaves out the top: add 1
                args = [args[0], ("op", "+", args[1], ("num", 1))]
        if ret != T:
            raise SSModError(f"{name} gives a {calls.friendly(ret)} here, but the variable is a {calls.friendly(T)}",
                             ftok, self.path)
        params = []
        for a, pt in zip(args, ptypes):
            v = self.num_value(a, PY_TYPES[pt], steps, ftok)
            params.append({"_type": pt, "_value": {"$content": v["_value"], "$type": pt}} if "_value" in v
                          else dict({"_type": pt}, **v))
        tmp = self.temp(t)
        steps.append({"method": {"_baseInfo": f"{cls}|{meth}|{ret}", "_paramsInfo": "|".join(ptypes)},
                      "parameters": params, "parameterIsByRef": [False] * len(params),
                      "returnValue": {"_type": ret, "_name": tmp, "_targetVariableID": self.vars[tmp][1]},
                      "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"})
        return {"_name": tmp, "_targetVariableID": self.vars[tmp][1]}

    # ---- lists: the script engine's own list tasks
    def list_ref(self, name):
        return {"_name": name, "_targetVariableID": self.vars[name][1]}

    def elem_value(self, e, t, steps, tok):
        """An element value (BBParameter<T>) for a list of python type t."""
        if t is str:
            v = self.str_value(e, steps, tok)
            return {"_value": v["_value"]["$content"]} if "_value" in v else {k: v[k] for k in ("_name", "_targetVariableID")}
        if t is bool:
            if e[0] == "bool":
                return {"_value": e[1]}
            if e[0] == "var" and self.vars[e[1]][0] is bool:
                return self.varref(e[1], tok)
            raise SSModError("expected true/false", tok, self.path)
        return self.num_value(e, t, steps, tok)

    def list_cmd(self, s):
        t = self.vars[s.name][0][1]
        steps = []
        ref = self.list_ref(s.name)
        if s.kind == "clear":
            steps.append({"targetList": ref, "$type": "NodeCanvas.Tasks.Actions.ClearList"})
        elif s.kind in ("add", "remove"):
            v = self.elem_value(s.args[0], t, steps, s.tok)
            task = "Actions.AddElementToList" if s.kind == "add" else "Actions.RemoveElementFromList"
            steps.append({"targetList": ref, "targetElement": v, "$type": generic(task, t)})
        else:                                                  # set: names[i] = x
            i = self.num_value(s.args[0], int, steps, s.tok)
            v = self.elem_value(s.args[1], t, steps, s.tok)
            steps.append({"targetList": ref, "index": i, "newValue": v, "$type": generic("Actions.SetListElement", t)})
        return self.seq([self.action(x) for x in steps]) if len(steps) > 1 else self.action(steps[0])

    def list_value(self, e, want, steps, tok):
        """count(xs) / pick(xs) / xs[i] -> a temporary of the right type (want: python type of the result)."""
        kind, name = e[0], e[1]
        if name not in self.vars or not (isinstance(self.vars[name][0], tuple) and self.vars[name][0][0] == "list"):
            raise SSModError(f"{name} isn't a list", tok, self.path)
        t = self.vars[name][0][1]
        res = int if kind == "count" else t
        if res is not want:
            raise SSModError(f"{kind}({name}) gives a {calls.friendly(VAR_TYPES[res])}, not a {calls.friendly(VAR_TYPES[want])}",
                             tok, self.path)
        tmp = self.temp(res)
        out = {"_name": tmp, "_targetVariableID": self.vars[tmp][1]}
        if kind == "count":
            steps.append({"targetList": self.list_ref(name), "saveAs": out, "$type": "NodeCanvas.Tasks.Actions.GetListCount"})
        elif kind == "pick":
            steps.append({"targetList": self.list_ref(name), "saveAs": out, "$type": generic("Actions.PickRandomListElement", t)})
        else:
            i = self.num_value(e[2], int, steps, tok)
            steps.append({"targetList": self.list_ref(name), "index": i, "saveAs": out, "failIfBadRange": False,
                          "$type": generic("Actions.PickListElement", t)})
        return dict(out)

    @staticmethod
    def arith(ref, op, b, t):
        if t is int:
            return {"valueA": ref, "Operation": op, "valueB": b, "$type": "NodeCanvas.Tasks.Actions.SetInt"}
        return {"valueA": ref, "Operation": op, "valueB": b, "perSecond": False, "$type": "NodeCanvas.Tasks.Actions.SetFloat"}

    def str_value(self, e, steps, tok):
        """A text expression ("a" + x + "b") -> a String parameter dict, joining with System.String.Concat."""
        parts = []

        def flat(x):
            if x[0] == "op" and x[1] == "+":
                flat(x[2]); flat(x[3])
            elif x[0] == "op":
                raise SSModError("text can only be joined with +", tok, self.path)
            else:
                parts.append(x)
        flat(e)
        vals = []
        for p_ in parts:
            if p_[0] in ("str", "num", "bool"):
                vals.append({"_type": "System.String", "_value": {"$content": str(p_[1]).lower() if p_[0] == "bool" else
                                                                   (str(int(p_[1])) if p_[0] == "num" and float(p_[1]) == int(p_[1]) else str(p_[1])),
                                                                   "$type": "System.String"}})
            elif p_[0] in ("pick", "index") and self.vars[p_[1]][0][1] is str:
                vals.append(dict({"_type": "System.String"}, **self.list_value(p_, str, steps, tok)))
            elif p_[0] in ("count", "pick", "index"):           # a number from a list -> text
                t_ = int if p_[0] == "count" else self.vars[p_[1]][0][1]
                num = self.list_value(p_, t_, steps, tok)
                tmp = self.temp(str)
                steps.append({"variable": num, "toString": {"_name": tmp, "_targetVariableID": self.vars[tmp][1]},
                              "$type": "NodeCanvas.Tasks.Actions.GetToString"})
                vals.append({"_type": "System.String", "_name": tmp, "_targetVariableID": self.vars[tmp][1]})
            elif p_[0] == "var" and self.vars[p_[1]][0] is str:
                vals.append(dict({"_type": "System.String"}, **self.varref(p_[1], tok)))
            elif p_[0] == "var":                       # a number or true/false -> text (GetToString)
                tmp = self.temp(str)
                steps.append({"variable": {"_name": p_[1], "_targetVariableID": self.vars[p_[1]][1]},
                              "toString": {"_name": tmp, "_targetVariableID": self.vars[tmp][1]},
                              "$type": "NodeCanvas.Tasks.Actions.GetToString"})
                vals.append({"_type": "System.String", "_name": tmp, "_targetVariableID": self.vars[tmp][1]})
            else:
                raise SSModError("only text, numbers and variables can be joined", tok, self.path)
        acc = vals[0]
        for v in vals[1:]:
            tmp = self.temp(str)
            out = {"_name": tmp, "_targetVariableID": self.vars[tmp][1]}
            steps.append({"method": {"_baseInfo": "System.String|Concat|System.String", "_paramsInfo": "System.String|System.String"},
                          "parameters": [acc, v], "parameterIsByRef": [False, False],
                          "returnValue": dict({"_type": "System.String"}, **out),
                          "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"})
            acc = dict({"_type": "System.String"}, **out)
        return acc

    def assign(self, s):
        t = self.vars[s.name][0]
        if t is str or isinstance(s.value, str):
            if t is not str:
                raise SSModError(f"'{s.name}' holds a number; it can't be set to text", s.tok, self.path)
            steps = []
            e = ("str", s.value) if isinstance(s.value, str) else s.value
            if s.op == "+=":
                e = ("op", "+", ("var", s.name), e)
            v = self.str_value(e, steps, s.tok)
            vb = {"_value": v["_value"]["$content"]} if "_value" in v else {k: v[k] for k in ("_name", "_targetVariableID")}
            steps.append({"valueA": self.varref(s.name, s.tok), "valueB": vb, "$type": STRING_SET})
            return steps
        if isinstance(s.value, tuple):                 # a calculation
            if t is bool:
                raise SSModError("true/false variables can only be set to true or false", s.tok, self.path)
            steps = []
            b = self.num_value(s.value, t, steps, s.tok)
            steps.append(self.arith(self.varref(s.name, s.tok), OPS[s.op], b, t))
            return steps
        if t is bool:
            return {"boolVariable": self.varref(s.name, s.tok), "setTo": "True" if s.value else "False",
                    "$type": "NodeCanvas.Tasks.Actions.SetBoolean"}
        if t is int:
            return {"valueA": self.varref(s.name, s.tok), "Operation": OPS[s.op], "valueB": {"_value": int(s.value)},
                    "$type": "NodeCanvas.Tasks.Actions.SetInt"}
        return {"valueA": self.varref(s.name, s.tok), "Operation": OPS[s.op], "valueB": {"_value": float(s.value)},
                "perSecond": False, "$type": "NodeCanvas.Tasks.Actions.SetFloat"}

    # ---- conditions: one ConditionTask
    def cond(self, c):
        if isinstance(c, CNot):
            t = copy.deepcopy(self.cond(c.inner))
            t["_invert"] = not t.get("_invert", False)
            return t
        if isinstance(c, (CAnd, COr)):
            mode = "AllTrueRequired" if isinstance(c, CAnd) else "AnyTrueSuffice"
            return {"checkMode": mode, "conditions": [self.cond(c.a), self.cond(c.b)],
                    "$type": "NodeCanvas.Framework.ConditionList"}
        if isinstance(c, CCall):
            return calls.check_task(self, c, SCRIPT_COMPARE, self.path)
        if isinstance(c, CEvent):
            return calls.event_task(self, c, self.path)
        if isinstance(c, CListHas):
            t = self.vars[c.name][0][1]
            steps = []
            v = self.elem_value(c.value, t, steps, c.tok)
            if steps:
                raise SSModError("check a list against a plain value or a variable (work it out first)", c.tok, self.path)
            return {"targetList": self.list_ref(c.name), "checkElement": v, "$type": generic("Conditions.ListContainsElement", t)}
        extra = extra_condition(c, SCRIPT_COMPARE, self.path, self.ref)
        if extra is not None:
            return extra
        if isinstance(c, CVar) and (self.vars[c.name][0] is str or isinstance(c.value, str)):
            if self.vars[c.name][0] is not str or c.op not in ("==", "!="):
                raise SSModError("text can only be compared with == or !=", c.tok, self.path)
            vb = self.varref(c.value[1], c.tok) if isinstance(c.value, tuple) else {"_value": c.value}
            task = {"valueA": self.varref(c.name, c.tok), "valueB": vb, "$type": "NodeCanvas.Tasks.Conditions.CheckString"}
            if c.op == "!=":
                task["_invert"] = True
            return task
        if isinstance(c, CVar) and isinstance(c.value, tuple):        # compare two variables
            t = self.vars[c.name][0]
            if self.vars[c.value[1]][0] is not t:
                raise SSModError(f"{c.name} and {c.value[1]} hold different kinds of value", c.tok, self.path)
            if t is bool:
                task = {"valueA": self.varref(c.name, c.tok), "valueB": self.varref(c.value[1], c.tok),
                        "$type": "NodeCanvas.Tasks.Conditions.CheckBoolean"}
            else:
                task = {"valueA": self.varref(c.name, c.tok), "checkType": SCRIPT_COMPARE[c.op],
                        "valueB": self.varref(c.value[1], c.tok),
                        "$type": f"NodeCanvas.Tasks.Conditions.{'CheckInt' if t is int else 'CheckFloat'}"}
                if t is float:
                    task["differenceThreshold"] = 0.05
            if c.op == "!=":
                task["_invert"] = True
            return task
        if isinstance(c, CVar):
            t = self.vars[c.name][0]
            if c.op == "bool" or t is bool:
                task = {"valueA": self.varref(c.name, c.tok), "valueB": {"_value": bool(c.value)},
                        "$type": "NodeCanvas.Tasks.Conditions.CheckBoolean"}
                if c.op == "!=":
                    task["_invert"] = True
                return task
            kind = "CheckInt" if t is int else "CheckFloat"
            task = {"valueA": self.varref(c.name, c.tok), "checkType": SCRIPT_COMPARE[c.op],
                    "valueB": {"_value": int(c.value) if t is int else float(c.value)},
                    "$type": f"NodeCanvas.Tasks.Conditions.{kind}"}
            if t is float:
                task["differenceThreshold"] = 0.05
            if c.op == "!=":
                task["_invert"] = True
            return task
        if isinstance(c, CKey):     # static Input.GetKey(string) == true
            return {"method": {"_baseInfo": "UnityEngine.Input|GetKey|System.Boolean", "_paramsInfo": "System.String"},
                    "parameters": [self.prim("System.String", c.key)], "parameterIsByRef": [False],
                    "checkValue": self.prim("System.Boolean", True), "comparison": "EqualTo",
                    "$type": "NodeCanvas.Tasks.Conditions.CheckFunction_Multiplatform"}
        if isinstance(c, CNear):
            return {"checkTarget": {"_value": self.ref("object", c.target, c.tok)}, "checkType": "LessOrEqualTo",
                    "distance": {"_value": float(c.distance)}, "floatingPoint": 0.1, "overrideAgent": dict(PLAYER),
                    "$type": "NodeCanvas.Tasks.Conditions.CheckDistanceToGameObject"}
        # flags, has(), coins: reuse the dialogue compiler's leaf tasks
        self.dc.refs, self.dc.ref_index = self.refs, self.ref_index
        if isinstance(c, CFlag):
            return {"flag": self.dc.ref("flag", c.name, c.tok), "flagParameter": {}, "$type": "CheckFlag"}
        if isinstance(c, CHas):
            return {"item": self.dc.ref("item", c.item, c.tok), "itemParam": {}, "minimumQuantity": c.count,
                    "minimumQuantityParam": {"_value": c.count}, "saveQuantity": {"_name": ""}, "$type": "HasItem"}
        if isinstance(c, CCoins):
            # no "intDataValue": see the note in dialogue.py - {} on an object field breaks deserialization
            return {"value": {"_value": c.value}, "checkType": COMPARE[c.op], "$type": "CheckCoins"}
        raise SSModError(f"can't use {type(c).__name__} in a script condition", getattr(c, "tok", None), self.path)

    @staticmethod
    def has_event(c):
        if isinstance(c, CEvent):
            return True
        return any(ScriptCompiler.has_event(x) for x in (getattr(c, "a", None), getattr(c, "b", None), getattr(c, "inner", None)) if x)

    # ---- output
    def compile(self, body):
        def gather(stmts):
            for s in stmts:
                if isinstance(s, VarDecl) and isinstance(s.value, tuple) and s.value[0] == "list":
                    self.vars[s.name] = (("list", s.value[1]), str(uuid.uuid4()), list(s.value[2]))
                elif isinstance(s, VarDecl):
                    self.vars[s.name] = (type(s.value), str(uuid.uuid4()), s.value)
                elif isinstance(s, Act) and s.kind == "getfield":
                    cls, objpath, fld, out = s.args
                    self.declare(out, calls.field_type(self, cls, objpath, fld, s.tok, self.path), s.tok)
                elif isinstance(s, Act) and s.kind == "call" and s.args[3]:
                    cls, method, args, out, objpath = s.args
                    ret = calls.result_type(self, cls, method, args, objpath, s.tok, self.path)
                    if ret == "System.Void":
                        raise SSModError(f"{method} doesn't give anything back, so there's nothing to keep in '{out}'",
                                         s.tok, self.path)
                    self.declare(out, ret, s.tok)
                for sub in ("then", "orelse", "body"):
                    gather(getattr(s, sub, None) or [])
                for b in getattr(s, "branches", None) or []:
                    gather(b)
        def uses_player(stmts):
            for s in stmts:
                if isinstance(s, ActorCmd) and s.args.get("player") and s.kind in ("goto", "face"):
                    return s.tok
                for sub in [getattr(s, x, None) or [] for x in ("then", "orelse", "body")] + \
                        list(getattr(s, "branches", None) or []):
                    t = uses_player(sub)
                    if t:
                        return t
            return None
        ptok = uses_player(body)
        if ptok:
            body = [Act("call", ("player", "get_transform", [], self.PLAYER_T, None), ptok)] + list(body)
        gather(body)
        root = self.block(body)
        self.nodes.sort(key=lambda d: d["$id"] != root)
        graph = {"version": 2.9, "type": "NodeCanvas.BehaviourTrees.BehaviourTree", "nodes": self.nodes,
                 "connections": self.conns, "localBlackboard": {"_name": "Local Blackboard", "_variables": {}},
                 "derivedData": {"repeat": False, "$type": "NodeCanvas.BehaviourTrees.BehaviourTree+DerivedSerializationData"}}
        blackboard = {"_variables": {n: dict(({"_value": v[2]} if v[2] is not None else {}), _name=n, _id=v[1],
                                             **{"$type": var_type(v[0])}) for n, v in self.vars.items()}}
        return json.dumps(graph), json.dumps(blackboard), self.refs

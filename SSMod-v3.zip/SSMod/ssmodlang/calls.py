"""`call`: run the game's own C# functions from a mod (NodeCanvas reflection tasks, the way the game's own
dialogues call NodeCanvasBridge and its scenes' components).

    call Misc_SetWeather(asset "Weather Snowy", true);          static (NodeCanvasBridge is the default class)
    call UnityEngine.Random.Range(1, 7) -> roll;                 any static function, result kept in a variable
    call Actor_GetActor(asset "Doctor Duck") -> duck;           objects can be kept too...
    call duck.SetStinkValue(5.0);                               ...and called on later
    call player.SomeMethod();                                   the player (Globals/player, a GameActor)
    call GateController("Seaport Gate").SetOpen(true);          a component on a named object in the scene

api.json lists the functions with their parameter types, the classes with their base classes and assemblies
(tools/make_api.py). Every call is also checked against the installed game's metadata (il2cpp.py), so a function
that a game update removed, or that IL2CPP stripped from the build, is an error at build time.

The compilers (dialogue.py, bt.py) supply a context object:
    ctx.ref(kind, key, tok) -> index into the graph's _objectReferences (assets, items, flags, disguises)
    ctx.var(name) -> (type, {"_name", "_targetVariableID"}) or None
    ctx.declare(name, type, tok) -> {"_name", "_targetVariableID"} for a result variable
    ctx.object_param(type, path, tok) -> a parameter dict pointing at a scene object's component
    ctx.object_agent(type, path, tok) -> an overrideAgent dict pointing at it
"""
import json
import os
import uuid

from .syntax import SSModError

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CLASS = "NodeCanvasBridge"          # the game's API for its own dialogues: call Misc_SetWeather(...)
PLAYER_TYPE = "GameActor"
PLAYER_REF = {"_name": "Globals/player", "_targetVariableID": "globals_player"}
NUMBER = {"System.Int32": int, "System.Single": float, "System.Double": float, "System.Int64": int}
MSCORLIB = "mscorlib, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"
REF_WORDS = ("item", "asset", "flag", "disguise", "object")
FRIENDLY = {"System.Int32": "whole number", "System.Int64": "whole number", "System.Single": "number",
            "System.Double": "number", "System.Boolean": "true/false", "System.String": "text", "System.Void": "nothing"}
ANY_OBJECT = {"System.Object", "UnityEngine.Object"}

_api = None
_game = None


def api():
    global _api
    if _api is None:
        with open(os.path.join(HERE, "api.json")) as fh:
            _api = json.load(fh)
    return _api


def friendly(t):
    return FRIENDLY.get(t) or t.split("+")[-1].split(".")[-1]


def game_methods():
    """{(class, method, parameter count)} in the installed game. Nested classes are listed by their own name."""
    global _game
    if _game is None:
        from .config import game_app
        from .il2cpp import read
        meta = os.path.join(game_app(), "Contents", "Resources", "Data", "il2cpp_data", "Metadata", "global-metadata.dat")
        _game = {((ns + "." + t) if ns else t, m, n) for ns, t, _decl, m, n, _st in read(meta)}
    return _game


def in_game(cls, method, nargs):
    return (cls.split("+")[-1] if "+" in cls else cls, method, nargs) in game_methods()


def bases(t):
    """t, its base class, its base's base, ... (as far as api.json knows them)."""
    seen = []
    types = api()["types"]
    while t and t not in seen:
        seen.append(t)
        t = types.get(t, [""])[0]
    return seen


def assignable(src, dst):
    """Can a value of type src be passed where dst is wanted?"""
    return dst in ANY_OBJECT or dst in bases(src)


def is_class(name):
    return name in api()["types"]


_short = None


def full_class(name):
    """TMP_Text -> TMPro.TMP_Text, Random -> UnityEngine.Random: the namespace is optional when the name is unique."""
    global _short
    if not name or name in api()["types"]:
        return name
    if _short is None:
        _short = {}
        for t in api()["types"]:
            _short.setdefault(t.rsplit(".", 1)[-1], []).append(t)
    hits = _short.get(name, [])
    return hits[0] if len(hits) == 1 else name


def variable_type(t, tok=None, path=None):
    """The NodeCanvas Variable type that holds a value of C# type t."""
    if t.startswith("System.") and "`" not in t:
        aq = f"{t}, {MSCORLIB}"
    else:
        info = api()["types"].get(t)
        if not info or "`" in t:
            raise SSModError(f"a {friendly(t)} can't be kept in a variable yet", tok, path)
        aq = f"{t}, {info[2]}, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null"
    return f"NodeCanvas.Framework.Variable`1[[{aq}]]"


STRUCTS = {"UnityEngine.Vector2": 2, "UnityEngine.Vector3": 3, "UnityEngine.Color": "color",
           "UnityEngine.Quaternion": "angle", "UnityEngine.Rect": 4, "UnityEngine.Vector4": 4}


def fits(t, arg):
    """How well a written value fits a parameter type (for picking between overloads): 0 = not at all."""
    kind, v = arg[0], arg[1]
    if kind == "num":
        return 3 if t in ("System.Int32", "System.Int64") and float(v) == int(v) else 2 if t in NUMBER else 0
    if kind == "str":
        return 3 if t == "System.String" else 0
    if kind == "bool":
        return 3 if t == "System.Boolean" else 0
    if kind == "color":
        return 3 if t == "UnityEngine.Color" else 0
    if kind == "vec":
        return 3 if STRUCTS.get(t) == len(v) else 2 if STRUCTS.get(t) == 3 and len(v) == 2 else 0
    if kind == "num" and t == "UnityEngine.Quaternion":
        return 1
    return 1


def lookup(cls, method, nargs, tok, path, instance=False, args=None):
    """-> (declaring class, method, signature) for a function of cls (or a base class) taking nargs values.
    With args, overloads with the same number of values are told apart by what was written."""
    funcs = api()["functions"]
    cls = full_class(cls) or DEFAULT_CLASS
    for c in bases(cls) or [cls]:
        sigs = [sig for sig in funcs.get(f"{c}.{method}", []) if len(sig["params"]) == nargs and sig["static"] != instance]
        if sigs:
            if args and len(sigs) > 1:
                score = lambda sg: sum(fits(t, a) for (t, _), a in zip(sg["params"], args)) - \
                    100 * sum(1 for (t, _), a in zip(sg["params"], args) if fits(t, a) == 0)
                sigs.sort(key=score, reverse=True)
            sig = sigs[0]
            if not in_game(c, method, nargs):
                raise SSModError(f"{c}.{method} isn't in this version of the game (an update removed it, or it "
                                 f"was stripped from the build)", tok, path)
            return c, method, sig
    # explain what went wrong
    shown = cls if cls != DEFAULT_CLASS else ""
    same = [(c, s) for c in bases(cls) or [cls] for s in funcs.get(f"{c}.{method}", [])]
    if same:
        right_kind = [s for _, s in same if s["static"] != instance]
        if not right_kind:
            how = ("on an object (call something.%s(...))" % method) if not same[0][1]["static"] else \
                  ("without an object (call %s.%s(...))" % (same[0][0], method))
            raise SSModError(f"{method} has to be called {how}", tok, path)
        counts = " or ".join(str(n) for n in sorted({len(s["params"]) for s in right_kind}))
        sigs = "; ".join(f"{method}({', '.join(friendly(t) + ' ' + n for t, n in s['params'])})" for s in right_kind)
        raise SSModError(f"{method} takes {counts} value(s), not {nargs}: {sigs}", tok, path)
    import difflib
    pool = [k.split(".")[-1] for c in bases(cls) or [cls] for k in funcs if k.startswith(c + ".")]
    near = difflib.get_close_matches(method, pool, n=3, cutoff=0.6)
    hint = f" Did you mean: {', '.join(near)}?" if near else ""
    where = f"{friendly(cls)} has no function" if shown else "no game function"
    raise SSModError(f"{where} '{method}'.{hint} (./ssmod functions {shown or ''} lists them)".replace("  ", " "),
                     tok, path)


def constant(t, arg, tok, path):
    """A literal argument -> its value for parameter type t (enum member names checked)."""
    kind, v = arg
    if t == "System.Boolean":
        if kind == "bool":
            return v
    elif t == "System.String":
        if kind == "str":
            return v
    elif t in NUMBER:
        if kind == "num":
            if NUMBER[t] is int and float(v) != int(v):
                raise SSModError("this value must be a whole number", tok, path)
            return NUMBER[t](v)
    elif t in api()["enums"]:
        names = api()["enums"][t]
        if kind == "ident":
            if v not in names:
                raise SSModError(f"'{v}' isn't a {friendly(t)}; use one of: {', '.join(names)}", tok, path)
            return v
    if t in STRUCTS:
        n = STRUCTS[t]
        if n == "color" and kind == "color":
            return {"r": int(v[0:2], 16) / 255, "g": int(v[2:4], 16) / 255, "b": int(v[4:6], 16) / 255, "a": 1.0, "$type": t}
        if n == "angle" and kind == "num":                    # a turn of that many degrees (like `rotate`)
            import math
            a = math.radians(float(v)) / 2
            return {"x": 0.0, "y": 0.0, "z": math.sin(a), "w": math.cos(a), "$type": t}
        if t == "UnityEngine.Rect" and kind == "vec" and len(v) == 4:
            return dict(zip(("x", "y", "width", "height"), map(float, v)), **{"$type": t})
        if t == "UnityEngine.Vector4" and kind == "vec" and len(v) == 4:
            return dict(zip("xyzw", map(float, v)), **{"$type": t})
        if isinstance(n, int) and n <= 3 and kind == "vec" and len(v) in (2, 3) and len(v) <= n:
            xyz = list(v) + [0.0] * (n - len(v))
            return dict(zip("xyz", map(float, xyz)), **{"$type": t})
        want = {"color": "a colour like #FF8800", "angle": "an angle in degrees, like 45",
                4: "four numbers like (0, 0, 100, 50)"}.get(n) or f"a position like (10, 20{', 0' if n == 3 else ''})"
        raise SSModError(f"expected {want} here", tok, path)
    want = {"System.Boolean": "true or false", "System.String": "a \"text\""}.get(t) or (
        "a number" if t in NUMBER else f"one of: {', '.join(api()['enums'][t])}" if t in api()["enums"] else None)
    if want is None:
        raise SSModError(f"a {friendly(t)} has to be given as an object: asset \"Name\", object \"Name in the scene\", "
                         f"a variable, or player", tok, path)
    raise SSModError(f"expected {want} here (the function wants a {friendly(t)})", tok, path)


def target_of(ctx, cls, objpath, tok, path):
    """What a call runs on: None (static), or (type, overrideAgent dict)."""
    if objpath is not None:
        cls = full_class(cls)
        return cls, ctx.object_agent(cls, objpath, tok)
    if cls == "player":
        return PLAYER_TYPE, dict(PLAYER_REF)
    if cls and "." not in cls:
        v = ctx.var(cls)
        if v is not None:
            if v[0].startswith("System.") or v[0] in api()["enums"]:
                raise SSModError(f"'{cls}' holds a {friendly(v[0])}; functions can only be called on objects", tok, path)
            return v[0], dict(v[1])
    return None


def params_for(ctx, sig, args, tok, path):
    out = []
    for (t, pname), (kind, v, atok) in zip(sig["params"], args):
        if kind in ("item", "flag", "disguise", "asset"):
            key = (t, v) if kind == "asset" else v
            out.append({"_type": t, "_value": {"$content": ctx.ref(kind, key, atok), "$type": t}})
        elif kind == "object":
            out.append(ctx.object_param(t, v, atok))
        elif kind == "ident" and v == "null" and not (t.startswith("System.") and t not in ANY_OBJECT) \
                and t not in api()["enums"] and t not in STRUCTS:
            out.append({"_type": t})                          # nothing (a null object)
        elif kind == "ident" and v == "player" and t not in api()["enums"]:
            if not assignable(PLAYER_TYPE, t):
                raise SSModError(f"{pname} must be a {friendly(t)}, and the player is a GameActor", atok, path)
            out.append(dict({"_type": t}, **PLAYER_REF))
        elif kind == "ident" and t not in api()["enums"] and ctx.var(v) is not None:
            vt, ref = ctx.var(v)
            widening = vt in ("System.Int32", "System.Int64") and t in ("System.Single", "System.Double")
            if vt != t and not assignable(vt, t) and not widening:
                raise SSModError(f"'{v}' holds a {friendly(vt)}, but {pname} must be a {friendly(t)}", atok, path)
            out.append(dict({"_type": t}, **ref))
        elif t in STRUCTS:
            out.append({"_type": t, "_value": constant(t, (kind, v), atok, path)})
        else:
            out.append({"_type": t, "_value": {"$content": constant(t, (kind, v), atok, path), "$type": t}})
    return out


def method_info(cls, method, sig):
    return {"_baseInfo": f"{cls}|{method}|{sig['ret']}", "_paramsInfo": "|".join(t for t, _ in sig["params"])}


def call_task(ctx, cls, method, args, out, objpath, tok, path):
    """An ExecuteFunction_Multiplatform action."""
    tgt = target_of(ctx, cls, objpath, tok, path)
    if tgt:
        dcls, method, sig = lookup(tgt[0], method, len(args), tok, path, instance=True, args=args)
    else:
        dcls, method, sig = lookup(cls, method, len(args), tok, path, args=args)
    task = {"method": method_info(dcls, method, sig), "parameters": params_for(ctx, sig, args, tok, path),
            "parameterIsByRef": [False] * len(args), "returnValue": {},
            "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"}
    if tgt:
        task["overrideAgent"] = tgt[1]
    if out:
        if sig["ret"] == "System.Void":
            raise SSModError(f"{method} doesn't give anything back, so there's nothing to keep in '{out}'", tok, path)
        task["returnValue"] = dict({"_type": sig["ret"]}, **ctx.declare(out, sig["ret"], tok))
    return task


def result_type(ctx, cls, method, args, objpath, tok, path):
    """What a call gives back (to declare `-> x` variables before compiling)."""
    tgt = target_of(ctx, cls, objpath, tok, path)
    if tgt:
        return lookup(tgt[0], method, len(args), tok, path, instance=True, args=args)[2]["ret"]
    return lookup(cls, method, len(args), tok, path, args=args)[2]["ret"]


def check_task(ctx, c, compare, path):
    """A CheckFunction_Multiplatform condition for `call F(...) [op value]` (c is a syntax.CCall)."""
    tgt = target_of(ctx, c.cls, c.objpath, c.tok, path)
    if tgt:
        dcls, method, sig = lookup(tgt[0], c.method, len(c.args), c.tok, path, instance=True, args=c.args)
    else:
        dcls, method, sig = lookup(c.cls, c.method, len(c.args), c.tok, path, args=c.args)
    ret = sig["ret"]
    if ret == "System.Void":
        raise SSModError(f"{method} doesn't give anything back, so it can't be checked", c.tok, path)
    value = c.value if c.value is not None else ("bool", True)
    if c.op is None and ret != "System.Boolean":
        raise SSModError(f"{method} gives a {friendly(ret)}; compare it, e.g. call {method}(...) > 0", c.tok, path)
    op = c.op or "=="
    if op not in ("==", "!=") and ret not in NUMBER:
        raise SSModError(f"only numbers can be compared with {op}", c.tok, path)
    task = {"method": method_info(dcls, method, sig), "parameters": params_for(ctx, sig, c.args, c.tok, path),
            "checkValue": {"_type": ret, "_value": {"$content": constant(ret, value, c.tok, path), "$type": ret}},
            "$type": "NodeCanvas.Tasks.Conditions.CheckFunction_Multiplatform"}
    if ret in NUMBER:
        task["comparison"] = compare["==" if op == "!=" else op]
    if op == "!=":
        task["_invert"] = True
    if tgt:
        task["overrideAgent"] = tgt[1]
    return task


def find_field(cls, name, tok, path):
    """(declaring class, field type) of a public field of cls or a base class."""
    fields = api().get("fields", {})
    for c in bases(cls) or [cls]:
        if name in fields.get(c, {}):
            return c, fields[c][name]
    import difflib
    pool = [f for c in bases(cls) or [cls] for f in fields.get(c, {})]
    near = difflib.get_close_matches(name, pool, n=3, cutoff=0.5)
    hint = f" Did you mean: {', '.join(near)}?" if near else (f" Its public fields: {', '.join(sorted(pool)[:12])}" if pool else "")
    raise SSModError(f"{friendly(cls)} has no public field '{name}'.{hint}", tok, path)


def field_task(ctx, cls, objpath, field, value, out, tok, path):
    """SetField / GetField (the script engine's own reflection tasks) on an object or a class."""
    tgt = target_of(ctx, cls, objpath, tok, path)
    owner = tgt[0] if tgt else full_class(cls)
    if not tgt and not is_class(owner):
        raise SSModError(f"'{cls}' isn't an object or class SSMod knows (use Class(\"name\").field, player.field or "
                         f"a variable holding an object)", tok, path)
    decl, ftype = find_field(owner, field, tok, path)
    if out is not None:
        task = {"targetType": decl, "fieldName": field, "saveAs": dict({"_type": ftype}, **ctx.declare(out, ftype, tok)),
                "$type": "NodeCanvas.Tasks.Actions.GetField"}
    else:
        p = params_for(ctx, {"params": [[ftype, field]]}, [value], tok, path)[0]
        task = {"setValue": p, "targetType": decl, "fieldName": field, "$type": "NodeCanvas.Tasks.Actions.SetField"}
    if tgt:
        task["overrideAgent"] = tgt[1]
    return task


def field_type(ctx, cls, objpath, field, tok, path):
    tgt = target_of(ctx, cls, objpath, tok, path)
    return find_field(tgt[0] if tgt else full_class(cls), field, tok, path)[1]


def event_task(ctx, c, path):
    """CheckCSharpEvent: true the moment the game raises the event (events with no value or one value)."""
    tgt = target_of(ctx, c.cls, c.objpath, c.tok, path)
    owner = tgt[0] if tgt else full_class(c.cls)
    events = api().get("events", {})
    found = next(((cl, events[cl][c.name]) for cl in bases(owner) or [owner] if c.name in events.get(cl, {})), None)
    if not found:
        pool = sorted({e for cl in bases(owner) or [owner] for e in events.get(cl, {})})
        raise SSModError(f"{friendly(owner)} has no event '{c.name}'." + (f" Its events: {', '.join(pool)}" if pool else ""),
                         c.tok, path)
    decl, (handler, static) = found
    if not static and not tgt:
        raise SSModError(f"{c.name} belongs to one {friendly(owner)}: write player.{c.name} or {friendly(owner)}(\"name\").{c.name}",
                         c.tok, path)
    if handler == "System.Action":
        task = {"targetType": decl, "eventName": c.name, "$type": "NodeCanvas.Tasks.Conditions.CheckCSharpEvent"}
    elif handler.startswith("System.Action`1["):
        arg = handler[len("System.Action`1["):-1]
        aq = variable_type(arg, c.tok, path)[len("NodeCanvas.Framework.Variable`1"):]
        task = {"targetType": decl, "eventName": c.name, "saveAs": {},
                "$type": "NodeCanvas.Tasks.Conditions.CheckCSharpEvent`1" + aq}
    else:
        raise SSModError(f"{c.name} passes several values ({handler}); only events with none or one can be waited for",
                         c.tok, path)
    if tgt:
        task["overrideAgent"] = tgt[1]
    return task


def log_task(prefix, value):
    """UnityEngine.Debug.Log: the line ends up in the game's Player.log, where `./ssmod log` shows it."""
    return {"method": {"_baseInfo": "UnityEngine.Debug|Log|System.Void", "_paramsInfo": "System.Object"},
            "parameters": [value], "parameterIsByRef": [False], "returnValue": {},
            "$type": "NodeCanvas.Tasks.Actions.ExecuteFunction_Multiplatform"}


def log_prefix(path, where=""):
    import os
    mod = os.path.splitext(os.path.basename(path or "mod"))[0]
    return f"[SSMod] {mod}{' ' + where if where else ''}: "


def stable_id(*parts):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "ssmod/" + "/".join(str(p) for p in parts)))

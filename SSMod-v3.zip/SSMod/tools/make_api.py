"""Write ssmodlang/api.json: the C# functions mods can `call`, with their parameter types.

Input: method lists made by tools/DumpApi.cs (run with mono on AssetRipper's exported game DLLs and on Unity's
own module DLLs); file names are api_<Assembly>.tsv. Names and signatures only, no code. At build time SSMod also
checks every called function against the installed game (ssmodlang/il2cpp.py reads the game's own metadata), so
a function the game doesn't have (an update removed it, or IL2CPP stripped it) is an error, not a silent no-op.
  python3 tools/make_api.py api_Assembly-CSharp.tsv api_Assembly-CSharp-firstpass.tsv api_UnityEngine.CoreModule.tsv ...
"""
import json
import os
import re
import sys

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "ssmodlang", "api.json")


def main(paths):
    funcs, enums, types, fields, events = {}, {}, {}, {}, {}
    for p in paths:
        asm = re.sub(r"^api_|\.tsv$", "", os.path.basename(p))
        for line in open(p, encoding="utf-8"):
            f = line.rstrip("\n").split("\t")
            if f[0] == "type":
                types[f[1]] = [f[2], f[3], asm]          # base class, kind (component/asset/enum/class), assembly
                continue
            if f[0] == "event":
                events.setdefault(f[1], {})[f[2]] = [f[3], f[4] == "static"]
                continue
            if f[0] == "field":
                if len(f) >= 5 and f[4] == "public" and "`" not in f[1] and "<" not in f[2]:
                    fields.setdefault(f[1], {})[f[2]] = f[3]
                continue
            if f[0] == "enum":
                enums[f[1]] = f[2].split(",") if f[2] else []
                continue
            kind, cls, name, static, ret, params, generic = f + [""] * (7 - len(f))
            if generic or "`" in cls or "<" in name or "<" in cls:
                continue
            ps = [q.rsplit(" ", 1) for q in params.split("|")] if params else []
            if any(len(q) != 2 for q in ps):
                continue
            funcs.setdefault(f"{cls}.{name}", []).append({"ret": ret, "params": ps, "static": static == "static"})
    # TextMeshPro's text class can't be listed by reflection (its UI base class drags in types that don't load),
    # so the few functions mods need for on-screen text are written here. Each is still checked against the game.
    S, F, V, C = "System.String", "System.Single", "System.Void", "UnityEngine.Color"
    for name, ret, params in [("set_text", V, [[S, "value"]]), ("get_text", S, []),
                              ("SetText", V, [[S, "sourceText"]]),
                              ("SetText", V, [[S, "sourceText"], [F, "arg0"]]),
                              ("SetText", V, [[S, "sourceText"], [F, "arg0"], [F, "arg1"]]),
                              ("SetText", V, [[S, "sourceText"], [F, "arg0"], [F, "arg1"], [F, "arg2"]]),
                              ("set_color", V, [[C, "value"]]), ("set_fontSize", V, [[F, "value"]]),
                              ("set_alpha", V, [[F, "value"]])]:
        sigs = funcs.setdefault(f"TMPro.TMP_Text.{name}", [])
        if not any(len(x["params"]) == len(params) and x["params"] == params for x in sigs):
            sigs.append({"ret": ret, "params": params, "static": False})
    types.setdefault("TMPro.TMP_Text", ["UnityEngine.UI.MaskableGraphic", "component", "Unity.TextMeshPro"])
    types.setdefault("TMPro.TextMeshPro", ["TMPro.TMP_Text", "component", "Unity.TextMeshPro"])
    # a few .NET functions from mscorlib (it isn't listed; each is still checked against the game like the rest):
    # joining text, reading and writing files (the bridge's mailbox), turning text into a number
    S_, B_, V_, I_ = "System.String", "System.Boolean", "System.Void", "System.Int32"
    for n in (2, 3, 4):
        funcs.setdefault("System.String.Concat", []).append(
            {"ret": S_, "params": [[S_, f"s{k}"] for k in range(n)], "static": True})
    for key, ret, params in [("System.IO.File.Exists", B_, [[S_, "path"]]), ("System.IO.File.ReadAllText", S_, [[S_, "path"]]),
                             ("System.IO.File.WriteAllText", V_, [[S_, "path"], [S_, "contents"]]),
                             ("System.IO.File.Delete", V_, [[S_, "path"]]),
                             ("System.IO.Directory.Exists", B_, [[S_, "path"]]),
                             ("System.IO.Directory.CreateDirectory", "System.IO.DirectoryInfo", [[S_, "path"]]),
                             ("System.Int32.Parse", I_, [[S_, "s"]])]:
        funcs.setdefault(key, []).append({"ret": ret, "params": params, "static": True})
    json.dump({"functions": funcs, "enums": enums, "types": types, "fields": fields, "events": events}, open(OUT, "w"), separators=(",", ":"))
    n_static = sum(1 for v in funcs.values() for s in v if s["static"])
    print(f"{len(funcs)} functions ({n_static} static), {len(enums)} enums, {len(types)} types -> {OUT} "
          f"({os.path.getsize(OUT) // 1024} KB)")


if __name__ == "__main__":
    main(sys.argv[1:])
